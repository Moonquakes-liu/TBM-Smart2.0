#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.1                                                      *
# * Date:  2024-11-23 20:33:50                                           *
# * Last  update: 2024-08-28 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import os
import threading
import time
import sys
import traceback
from datetime import datetime
import configparser
import tarfile
import joblib
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

#  程序说明部分
if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.abspath(sys.argv[0]))


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class RockMassAnalysis(threading.Thread):
    """岩体破碎概率预测（current_rock, rock_23, rock_45, support_method, risk_state）"""
    Rock_class2 = None  # 初始化围岩二分类预测模型为空
    Rock_class4 = None  # 初始化围岩四分类预测模型为空
    Rock_analysis = None  # 初始化围岩参数分析模型为空
    Rock_weak = None  # 初始化岩体软弱破碎软弱预测模型为空
    Rock_jamming = None  # 初始化岩体卡机概率预测模型为空
    Rock_Support_Measures = None  # 初始化支护措施推荐模型为空

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        global BASE_PATH
        super(RockMassAnalysis, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = BASE_PATH
        self._model_rock_class2 = os.path.join(self._base_path, 'Model', 'Rock-Class2.tar')
        self._model_rock_class2_modification_time = None
        self._model_rock_class4 = os.path.join(self._base_path, 'Model', 'Rock-Class4.tar')
        self._model_rock_class4_modification_time = None
        self._model_rock_analysis= os.path.join(self._base_path, 'Model', 'Rock-Analysis.tar')
        self._model_rock_analysis_modification_time = None
        self._model_rock_weak = os.path.join(self._base_path, 'Model', 'Rock_weak.tar')
        self._model_rock_weak_modification_time = None
        self._model_rock_jamming = os.path.join(self._base_path, 'Model', 'Rock-Jamming.tar')
        self._model_rock_jamming_modification_time = None
        self._model_rock_support_measures = os.path.join(self._base_path, 'Model', 'Rock_Support_Measures.tar')
        self._model_rock_support_measures_modification_time = None
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.rock_class2_timeout = 60  # 执行时间间隔
        self.rock_class4_timeout = 60  # 执行时间间隔
        self.rock_analysis_timeout = 60  # 执行时间间隔
        self.rock_weak_timeout = 60  # 执行时间间隔
        self.rock_jamming_timeout = 60  # 执行时间间隔
        self.rock_support_measures_timeout = 60  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._load_model_()  # 初次加载模型
            while not self._stop_event.is_set():
                try:
                    self.main()  # 运行主程序
                except BaseException as e:
                    self._shared_var.log(message=traceback.format_exc())
                    print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                          f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
                finally:
                    time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        if self._shared_var.get(key='计数时间戳') % self.rock_class2_timeout == 0:  # 指定时间间隔运行一次
            Rock_class2 = self._function_rock_class2_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={'预测围岩类别（二分类）': Rock_class2[0]}, dtype='str')
            self._shared_var.set(value={'Ⅱ类Ⅲ类围岩概率': Rock_class2[1][0]}, dtype='float')
            self._shared_var.set(value={'Ⅳ类Ⅴ类围岩概率': Rock_class2[1][1]}, dtype='float')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
        if self._shared_var.get(key='计数时间戳') % self.rock_class4_timeout == 0:  # 指定时间间隔运行一次
            Rock_class4 = self._function_rock_class4_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={'预测围岩类别（四分类）': Rock_class4[0]}, dtype='str')
            self._shared_var.set(value={'Ⅰ类围岩概率': Rock_class4[1][0]}, dtype='float')
            self._shared_var.set(value={'Ⅱ类围岩概率': Rock_class4[1][1]}, dtype='float')
            self._shared_var.set(value={'Ⅲ类围岩概率': Rock_class4[1][2]}, dtype='float')
            self._shared_var.set(value={'Ⅳ类围岩概率': Rock_class4[1][3]}, dtype='float')
            self._shared_var.set(value={'Ⅴ类围岩概率': Rock_class4[1][4]}, dtype='float')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
        if self._shared_var.get(key='计数时间戳') % self.rock_analysis_timeout == 0:  # 指定时间间隔运行一次
            Rock_analysis = self._function_rock_analysis_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={f'岩性': Rock_analysis['岩性']}, dtype='str')
            self._shared_var.set(value={f'岩体抗压强度': Rock_analysis['岩体抗压强度']}, dtype='float')
            self._shared_var.set(value={f'岩体完整系数': Rock_analysis['岩体完整系数']}, dtype='float')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
        if self._shared_var.get(key='计数时间戳') % self.rock_weak_timeout == 0:  # 指定时间间隔运行一次
            Rock_weak = self._function_rock_weak_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={f'预测塌方风险': Rock_weak[0]}, dtype='str')
            self._shared_var.set(value={f'预测塌方概率': Rock_weak[1]}, dtype='float')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
        if self._shared_var.get(key='计数时间戳') % self.rock_jamming_timeout == 0:  # 指定时间间隔运行一次
            Rock_jamming = self._function_rock_jamming_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={f'预测卡机风险': Rock_jamming[0]}, dtype='str')
            self._shared_var.set(value={f'预测卡机概率': Rock_jamming[1]}, dtype='float')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
        if self._shared_var.get(key='计数时间戳') % self.rock_support_measures_timeout == 0:  # 指定时间间隔运行一次
            Rock_Support_Measures = self._function_rock_support_measures_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={f'锚杆型号': Rock_Support_Measures['锚杆型号']}, dtype='str')
            self._shared_var.set(value={f'锚杆长度': Rock_Support_Measures['锚杆长度']}, dtype='str')
            self._shared_var.set(value={f'锚杆环向间距': Rock_Support_Measures['锚杆环向间距']}, dtype='str')
            self._shared_var.set(value={f'锚杆纵向间距': Rock_Support_Measures['锚杆纵向间距']}, dtype='str')
            self._shared_var.set(value={f'布设范围': Rock_Support_Measures['布设范围']}, dtype='str')
            self._shared_var.set(value={f'拱架型号': Rock_Support_Measures['拱架型号']}, dtype='str')
            self._shared_var.set(value={f'拱架间距': Rock_Support_Measures['拱架间距']}, dtype='str')
            self._shared_var.set(value={f'钢筋网型号': Rock_Support_Measures['钢筋网型号']}, dtype='str')
            self._shared_var.set(value={f'钢筋网范围': Rock_Support_Measures['钢筋网范围']}, dtype='str')
            self._shared_var.set(value={f'喷混凝土强度': Rock_Support_Measures['喷混凝土强度']}, dtype='str')
            self._shared_var.set(value={f'喷混凝土厚度': Rock_Support_Measures['喷混凝土厚度']}, dtype='str')
            self._shared_var.set(value={f'衬砌强度': Rock_Support_Measures['衬砌强度']}, dtype='str')
            self._shared_var.set(value={f'衬砌厚度': Rock_Support_Measures['衬砌厚度']}, dtype='str')
            self._shared_var.set(value={f'风险状态': Rock_Support_Measures['风险状态']}, dtype='str')
            self._shared_var.set(value={f'建议支护方式': Rock_Support_Measures['建议支护方式']}, dtype='str')
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<

    def update(self):
        """更新模型和应用设置"""
        self._get_config_()
        self._load_model_()

    def _load_model_(self):
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_class2):
                model_rock_class2_modification_time = os.path.getmtime(self._model_rock_class2)
                if self._model_rock_class2_modification_time != model_rock_class2_modification_time:
                    rock_class2_program = {}
                    with tarfile.open(self._model_rock_class2, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_class2_code = file.read()
                    exec(rock_class2_code, rock_class2_program)
                    self.Rock_class2 = rock_class2_program['function'](model_path=self._model_rock_class2)
                    self.rock_class2_timeout = self.Rock_class2.timeout
                    self._model_rock_class2_modification_time = model_rock_class2_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_class2)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_class2 = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_class2)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_class4):
                model_rock_class4_modification_time = os.path.getmtime(self._model_rock_class4)
                if self._model_rock_class4_modification_time != model_rock_class4_modification_time:
                    rock_class4_program = {}
                    with tarfile.open(self._model_rock_class4, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_class4_code = file.read()
                    exec(rock_class4_code, rock_class4_program)
                    self.Rock_class4 = rock_class4_program['function'](model_path=self._model_rock_class4)
                    self.rock_class4_timeout = self.Rock_class4.timeout
                    self._model_rock_class4_modification_time = model_rock_class4_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_class4)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_class4 = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_class4)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_analysis):
                model_rock_analysis_modification_time = os.path.getmtime(self._model_rock_analysis)
                if self._model_rock_analysis_modification_time != model_rock_analysis_modification_time:
                    rock_analysis_program = {}
                    with tarfile.open(self._model_rock_analysis, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_analysis_code = file.read()
                    exec(rock_analysis_code, rock_analysis_program)
                    self.Rock_analysis = rock_analysis_program['function'](model_path=self._model_rock_analysis)
                    self.rock_analysis_timeout = self.Rock_analysis.timeout
                    self._model_rock_analysis_modification_time = model_rock_analysis_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_analysis)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_analysis = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_analysis)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_weak):
                model_rock_weak_modification_time = os.path.getmtime(self._model_rock_weak)
                if self._model_rock_weak_modification_time != model_rock_weak_modification_time:
                    rock_weak_program = {}
                    with tarfile.open(self._model_rock_weak, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_weak_code = file.read()
                    exec(rock_weak_code, rock_weak_program)
                    self.Rock_weak = rock_weak_program['function'](model_path=self._model_rock_weak)
                    self.rock_weak_timeout = self.Rock_weak.timeout
                    self._model_rock_weak_modification_time = model_rock_weak_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_weak)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_weak = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_weak)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_jamming):
                model_rock_jamming_modification_time = os.path.getmtime(self._model_rock_jamming)
                if self._model_rock_jamming_modification_time != model_rock_jamming_modification_time:
                    rock_jamming_program = {}
                    with tarfile.open(self._model_rock_jamming, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_jamming_code = file.read()
                    exec(rock_jamming_code, rock_jamming_program)
                    self.Rock_jamming = rock_jamming_program['function'](model_path=self._model_rock_jamming)
                    self.rock_jamming_timeout = self.Rock_jamming.timeout
                    self._model_rock_jamming_modification_time = model_rock_jamming_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_jamming)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_jamming = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_jamming)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_rock_support_measures):
                model_rock_support_measures_modification_time = os.path.getmtime(self._model_rock_support_measures)
                if self._model_rock_support_measures_modification_time != model_rock_support_measures_modification_time:
                    rock_Support_Measures_program = {}
                    with tarfile.open(self._model_rock_support_measures, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            rock_Support_Measures_code = file.read()
                    exec(rock_Support_Measures_code, rock_Support_Measures_program)
                    self.Rock_Support_Measures = rock_Support_Measures_program['function'](model_path=self._model_rock_support_measures)
                    self.rock_support_measures_timeout = self.Rock_Support_Measures.timeout
                    self._model_rock_support_measures_modification_time = model_rock_support_measures_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_rock_support_measures)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Rock_Support_Measures = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_rock_support_measures)} > failure !!!\033[0m')  # 输出相关提示信息

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'Setting', 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self._is_running = config.getboolean('RockMassAnalysis', 'run')  # 程序是否执行
            self._model_rock_class2 = os.path.join(self._base_path, 'Model',
                                                   config.get('RockMassAnalysis', 'rock-class2-model'))
            self._model_rock_class4 = os.path.join(self._base_path, 'Model',
                                                   config.get('RockMassAnalysis', 'rock-class4-model'))
            self._model_rock_analysis = os.path.join(self._base_path, 'Model',
                                                     config.get('RockMassAnalysis', 'rock-analysis-model'))
            self._model_rock_weak = os.path.join(self._base_path, 'Model',
                                                 config.get('RockMassAnalysis', 'rock-weak-model'))
            self._model_rock_jamming = os.path.join(self._base_path, 'Model',
                                                    config.get('RockMassAnalysis', 'rock-jamming-model'))
            self._model_rock_support_measures = os.path.join(self._base_path, 'Model',
                                                             config.get('RockMassAnalysis', 'rock-support-measures-model'))

    def _function_rock_class2_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_class2 is not None:
            return self.Rock_class2.calculate(rock_index=rock_index, key_data=key_data, passed_data=passed_data)
        else:
            return '--', (-1, -1)

    def _function_rock_class4_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_class4 is not None:
            return self.Rock_class4.calculate(rock_index, key_data, passed_data)
        else:
            return '--', (-1, -1, -1, -1, -1)

    def _function_rock_analysis_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_analysis is not None:
            return self.Rock_analysis.calculate(rock_index, key_data, passed_data)
        else:
            return {'岩性': '--', '岩体抗压强度': -1, '岩体完整系数': -1}

    def _function_rock_weak_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_weak is not None:
            return self.Rock_weak.calculate(rock_index, key_data, passed_data)
        else:
            return '--', -1

    def _function_rock_jamming_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_jamming is not None:
            return self.Rock_jamming.calculate(rock_index, key_data, passed_data)
        else:
            return '--', -1

    def _function_rock_support_measures_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Rock_Support_Measures is not None:
            return self.Rock_Support_Measures.calculate(rock_weak=self._shared_var.get(key='预测塌方概率'))
        else:
            return {'锚杆型号': '--', '锚杆长度': '--', '锚杆环向间距': '--', '锚杆纵向间距': '--', '布设范围': '--',
                    '拱架型号': '--', '拱架间距': '--', '钢筋网型号': '--', '钢筋网范围': '--', '喷混凝土强度': '--',
                    '喷混凝土厚度': '--', '衬砌强度': '--', '衬砌厚度': '--', '风险状态': '--', '建议支护方式': '--'}
