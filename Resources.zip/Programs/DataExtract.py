#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-03 16:06:54                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import os
import sys
import pandas as pd
import numpy as np
from pandas import DataFrame
import copy
import joblib
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KernelDensity
from datetime import datetime

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于数据提取
说明：无

===================================================================================
     """


class DataExtract(object):
    """关键数据提取及历史循环段保存"""
    key_name = ['里程', '运行时间', '刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘推力', '刀盘扭矩', '刀盘贯入度',
                '推进位移', '推进压力', '顶护盾压力', '左侧护盾压力', '右侧护盾压力', '顶护盾位移', '左侧护盾位移', '右侧护盾位移',
                '撑紧压力', '左撑靴位移', '右撑靴位移', '冷水泵压力', '主机皮带机速度', '推进泵电机电流', '左小腔撑靴压力',
                '右小腔撑靴压力', '暖水箱液位', '进水温度', '减速机进水压力', '刀盘喷水压力', '减速机冷却水出口流量', '刀盘喷水泵压力',
                'EP2出口压力', 'EP2次数', '内密封前腔压力', '外密封迷宫腔压力', '内密封迷宫腔压力', '齿轮油泵1压力', '齿轮油泵2压力',
                '推进油缸前部铰接', '推进油缸后部铰接', '小轴承润滑', '提升油缸十字铰接次数', '护盾铰接次数', '喷浆泵压力', '刹车释放压力',
                '变频柜进口水压力', '撑靴泵电机电流', '循环冷却泵压力', '撑靴泵压力', '钢拱架泵压力', '主皮带机泵压力', '后配套皮带机速度',
                'C1皮带机泵电机电流', '主皮带机正转压力', '主皮带机反转压力', 'C2皮带机电机电流', '左侧楔形油缸压力', '右侧楔形油缸压力',
                '左扭矩油缸回收压力', '右扭矩油缸伸出压力', '右扭矩油缸回收压力', '左后支撑压力', '右后支撑压力', '左后支撑位移',
                '左扭矩油缸位移', '右扭矩油缸位移', '前部拖拉油缸压力', '后部拖拉油缸压力', '后左拖拉油缸位移', 'T1_L3相电压',
                'T3_L2相电流']  # 待提取的关键数据列

    def __init__(self, _shared_var):
        """初始化各参量，请勿修改"""
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self.passed_data = []  # 保存历史循环段数据
        self.passed_data_mean = []  # 保存历史循环段数据均值
        self.key_data = DataFrame()  # 保存关键数据
        self.key_data_temp = DataFrame()  # 保存关键数据
        self.temp = DataFrame()  # 临时保存关键数据
        self.stage = '停机中'  # 掘进状态
        self._previous_state_(option='get')  # 获取历史状态信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    def stage_judge(self, data: DataFrame) -> str:
        """
        掘进状态判断
        :param data: 每秒实时数据(DataFrame)
        :return: 当前状态 ('停机中', '等待掘进', '空推中', '正在掘进')
        """
        if not data.empty:
            new_data = data[self.key_name]  # 关键数据提取，24列
            if new_data['刀盘转速'][0] >= 0.1:
                if new_data['推进速度'][0] >= 1:
                    if len(self.key_data) >= 30:
                        self.stage = '正在掘进'
                    else:
                        self.stage = '空推中'
                else:
                    self.stage = '等待掘进'
            else:
                self.stage = '停机中'
            self._key_data_extract_(data=new_data)  # 调用关键数据提取模块
            self._passed_data_save_(data=new_data)  # 调用历史数据保存模块
        else:
            self.stage = '停机中'
        return self.stage  # 返回每秒机械状态，请勿修改，数据格式为 str

    def run(self) -> [DataFrame, list, list]:
        """
        :return: 每秒实时破岩数据 [至少30条记录]， 历史掘进段数据 [round1, round2,...,round9, round10]
        """
        if self.stage == '正在掘进':
            return self.key_data, self.passed_data, self.passed_data_mean  # 返回数据，请勿修改
        else:
            return DataFrame(), self.passed_data, self.passed_data_mean  # 返回数据，请勿修改
    
    def _previous_state_(self, option='get') -> None:
        """保存历史索引，便于在下次启动时继续输出"""
        folder_path = os.path.join(self._base_path, 'temp')  # 文件夹路径
        if not os.path.exists(folder_path):  # 判断文件夹是否存在
            os.mkdir(folder_path)  # 创建相关文件夹
        local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_path = os.path.join(folder_path, 'passed-data')  # 保存历史索引
        if option == 'get':  # 获取历史索引
            # noinspection PyBroadException
            try:
                _temp_passed_data = joblib.load(save_path)
                self.passed_data = _temp_passed_data['passed-data']
                self.passed_data_mean = _temp_passed_data['passed-data-mean']
            except Exception:
                print(f'\033[0;33m[{local_time}] {self.__class__.__name__} -> '
                      f'[Warning] Error getting information from < {os.path.basename(save_path)} > '
                      f', The history information will be set to empty !!!\033[0m')
        elif option == 'set':  # 设置历史索引
            _temp_passed_data = {'date': local_time, 'passed-data': self.passed_data,
                                 'passed-data-mean': self.passed_data_mean}  # 保存历史索引的文件
            joblib.dump(_temp_passed_data, save_path)  # 保存历史索引(pkl)

    def _key_data_extract_(self, data: DataFrame) -> None:
        """
        破岩数据提取
        :param data: 每秒实时数据（DataFrame格式）
        """
        if self.stage in ['正在掘进', '空推中']:  # 若设备处于正在掘进状态和空推状态时运行以下数据
            self.key_data_temp = pd.concat([self.key_data_temp, data], ignore_index=True, axis=0)  # 开始保存数据（拼接）
            self.key_data = self._remove_outliers_(self.key_data_temp, option='3sigma')
        else:
            if not self.key_data_temp.empty:
                self.key_data_temp.drop(self.key_data_temp.index, inplace=True)
            if not self.key_data.empty:
                self.key_data.drop(self.key_data.index, inplace=True)  # 清空数据，并重新开始填写数据
                
    def _remove_outliers_(self, data: DataFrame, option='3sigma') -> DataFrame:
        """
        :param data: DataFrame格式数据
        :param option: 此函数包括，3σ方法、4分位法，默认采用3σ
        :return: 去除异常值后的数组
        """
        data = data[(data['刀盘扭矩'] > 100) & (data['刀盘推力'] >= 2000) & 
                    (data['推进速度'] <= 120) & (data['刀盘贯入度'] > 1)]  # 只选取刀刀盘推力 > 3000的数据
        if option == '3sigma':
            for col in ['刀盘扭矩', '刀盘贯入度', '刀盘转速', '推进速度', '刀盘推力']:  # 分别对这五个参数去除异常值
                mean, std = data[col].mean(), data[col].std()  # 计算均值、方差
                lower_limit, upper_limit = mean - 3 * std, mean + 3 * std  # 剔除3sigma范围外的异常值
                data = data[(data[col] >= lower_limit) & (data[col] <= upper_limit)]  # 去除异常值后的数据
        elif option == 'kernel':
            V = data['推进速度'].to_numpy()[:, np.newaxis]  # '推进速度'转换为NumPy数组，并增加一个新的维度
            kde_V = KernelDensity(kernel="gaussian", bandwidth=10.0).fit(V)
            V_MaxDensity_index = np.argmax(np.exp(kde_V.score_samples(V)))  # 找到概率密度最大值时 推进速度的索引
            V_MaxDensity = V[V_MaxDensity_index, 0]
            data = data[0.75 * V_MaxDensity < data['推进速度']]
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] Option < {option} > does not exist, please check !!!\033[0m')  # 输出相关提示信息
        return data.reset_index(drop=True)  # 返回处理后的数据
    
    def _passed_data_save_(self, data: DataFrame) -> None:
        """
        历史掘进段保存
        :param data: 每秒实时数据（DataFrame格式）
        """
        if data['刀盘转速'][0] > 0.1:  # 若刀盘转速大于0，则开始添加数据
            self.temp = pd.concat([self.temp, data], ignore_index=True, axis=0)  # 拼接每秒数据
        else:  # 若刀盘转速小于等于0，则对数据进行进一步操作
            if not self.temp.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                Length = self.temp['推进位移'].max() - self.temp['推进位移'].min()  # 获取该循环段的掘进长度
                V_max = self.temp['推进速度'].max()  # 获取该循环段的推荐速度最小值
                if Length > 10 and V_max > 1 and len(self.temp) >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                    self.passed_data.append(copy.deepcopy(self.temp))  # 将该循环段数据进行保存
                    if len(self.passed_data) > 10:  # 检查历史信息是否大于10个
                        del self.passed_data[0]  # 若大于10个，则删除最先添加进来的数据
                    self.passed_data_mean.append(self._remove_outliers_(self.temp, option='kernel').mean().to_frame().T)
                    if len(self.passed_data_mean) > 10:  # 检查历史信息均值是否大于10个
                        del self.passed_data_mean[0]  # 若大于10个，则删除最先添加进来的数据
                self._previous_state_(option='set')  # 保存历史状态信息
                self.temp.drop(self.temp.index, inplace=True)  # 清空临时数据，用于保存新的数据
