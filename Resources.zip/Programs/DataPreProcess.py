#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-03 17:03:10                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import threading
import time
from pandas import DataFrame
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from datetime import datetime
import os
import sys
import csv
import configparser
from WrapperTools import suppress_errors, retry
from DataGet import DataGet
from DataExtract import DataExtract

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于数据预处理
说明：无

===================================================================================
     """


class RockBreakingIndex(object):
    """破岩关键数据提取"""
    results = {'TPI-mean': 0, "TPI-std": 0, "FPIa-mean": 0, "FPIa-std": 0, "FPIb-mean": 0, "FPIb-std": 0,
               "WR-mean": 0, "WR-std": 0, "F-V-std": 0, "F-V-mean": 0, "T-V-std": 0, "T-V-mean": 0}  # 将结果放入dict中

    def __init__(self):
        self.cols = ['刀盘转速', '推进速度', '刀盘推力', '刀盘扭矩', '刀盘贯入度']
        self.FPI_b = None
        self.count = 0

    def run(self, data: DataFrame) -> DataFrame:
        """破岩指标计算TPI, FPI, WR, F=a*P+b"""
        if not data.empty:  # 若data不为空，则继续执行以下代码
            if self.count % 5 == 0:
                mask = data[self.cols] != 0
                data = data[mask.all(axis=1)]  # 去除含0的行，避免指标计算错误
                if self.FPI_b is None:
                    self.FPI_b = data[self.cols[2]][0]
                TPI = (data[self.cols[3]] / data[self.cols[4]])  # 计算TPI
                FPI_a = ((data[self.cols[2]] - self.FPI_b) / data[self.cols[4]])  # 计算FPI
                F_V_a = ((data[self.cols[2]] - self.FPI_b) / data[self.cols[1]])  # 计算FPI
                T_V = (data[self.cols[3]] / data[self.cols[1]])  # 计算TPI
                WR = (2000 * np.pi * data[self.cols[3]] * data[self.cols[0]]) / (
                        data[self.cols[1]] * data[self.cols[2]])  # 计算WR
                self.results = {'TPI-mean': TPI.mean(), "TPI-std": TPI.std(),
                                "FPIa-mean": FPI_a.mean(), "FPIa-std": FPI_a.std(),
                                "FPIb-mean": self.FPI_b, "FPIb-std": 0,
                                "WR-mean": WR.mean(), "WR-std": WR.std(),
                                "F-V-mean": F_V_a.mean(), "F-V-std": F_V_a.std(),
                                "T-V-mean": T_V.mean(), "T-V-std": T_V.std()}  # 将结果放入dict中
                self.count = 0
            self.count += 1
        else:  # 若data为空，则所有破岩关键数据均为0
            self.FPI_b = None
        return pd.DataFrame([self.results])  # 返回破岩关键参数


class DataPreProcess(threading.Thread):
    """数据预处理"""
    Machine_Info = {'刀盘转速-容许': 10, '推进速度-容许': 100, '刀盘扭矩-容许': 3340, '刀盘推力-容许': 11340, '贯入度-容许': 12,
                    '刀盘转速-脱困': 11.45, '推进速度-脱困': 120, '刀盘扭矩-脱困': 5010, '刀盘推力-脱困': 15877, '贯入度-脱困': 15}

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        super(DataPreProcess, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self.input = DataGet()  # 实例化数据获取模块
        self.extract = DataExtract(self._shared_var)  # 实例化数据提取模块
        self.break_index = RockBreakingIndex()  # 实例化破岩数据提取模块
        self.time_count = -1  # 计数时间戳
        self.PLC_timeout = 0  # PLC超时计数

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._shared_var.set(value={'数据获取方式': self.input.acquire_mode}, dtype='str')  # 数据获取方式上载至共享变量
            self._shared_var.set(value={'刀盘转速-容许': self.Machine_Info['刀盘转速-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'推进速度-容许': self.Machine_Info['推进速度-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘扭矩-容许': self.Machine_Info['刀盘扭矩-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘推力-容许': self.Machine_Info['刀盘推力-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘贯入度-容许': self.Machine_Info['贯入度-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘转速-脱困': self.Machine_Info['刀盘转速-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'推进速度-脱困': self.Machine_Info['推进速度-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘扭矩-脱困': self.Machine_Info['刀盘扭矩-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘推力-脱困': self.Machine_Info['刀盘推力-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘贯入度-脱困': self.Machine_Info['贯入度-脱困']}, dtype='float')  # 上载至共享变量中
            while not self._stop_event.is_set():  # 若未接收到停止指令，则一直循环运行
                self.main()  # 运行主程序
                time.sleep(1)  # 没秒检查一次共享变量内的值，以判断是否满足运行条件

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    @suppress_errors  # 处理异常并继续执行
    def main(self):
        """数据获取和数据处理"""
        real_data, plc_status = self.input.run()  # 调用数据获取模块, 返回实时数据（1行）、plc状态（True/False）
        construct_status = self.extract.stage_judge(data=real_data)  # 调用施工状态判断模块，返回施工状态（停机中、等待掘进、正在掘进）
        self._shared_var.set(value={'施工状态': construct_status}, dtype='str')  # 施工状态上载至共享变量
        self._shared_var.set(value={'real-data': real_data}, dtype='dataframe')  # 实时数据上载至共享变量
        self._shared_var.set(value={'PLC状态': plc_status}, dtype='bool')  # PLC状态上载至共享变量
        if plc_status:  # 若PLC状态为True，则运行以下代码
            real_time = real_data['运行时间'][0]  # 当前时刻时间戳
            start_time = pd.to_datetime(str(real_time.date()) + " 07:00:00")  # 白班/夜班分界时间戳
            end_time = pd.to_datetime(str(real_time.date()) + " 19:00:00")  # 白班/夜班分界时间戳
            group = "白  班" if start_time <= real_time <= end_time else "夜  班"  # 判断当前时刻属于白班/夜班
            self._shared_var.set(value={'班组': group}, dtype='str')  # 班组上载至共享变量
            self._shared_var.set(value={'运行时间': real_data['运行时间'][0]}, dtype='str')  # 运行时间上载至共享变量
            self._shared_var.set(value={'里程': round(real_data['里程'][0], 2)}, dtype='float')  # 里程上载至共享变量
            self._shared_var.set(value={'刀盘转速-当前': round(real_data['刀盘转速'][0], 2)}, dtype='float')  # 刀盘转速上载至共享变量
            self._shared_var.set(value={'推进速度-当前': round(real_data['推进速度'][0], 2)}, dtype='float')  # 推进速度上载至共享变量
            self._shared_var.set(value={'刀盘扭矩-当前': round(real_data['刀盘扭矩'][0], 2)}, dtype='float')  # 刀盘扭矩上载至共享变量
            self._shared_var.set(value={'刀盘推力-当前': round(real_data['刀盘推力'][0], 2)}, dtype='float')  # 刀盘推力上载至共享变量
            self._shared_var.set(value={'刀盘贯入度-当前': round(real_data['刀盘贯入度'][0], 2)}, dtype='float')  # 贯入度上载至共享变量
            self._shared_var.set(value={'推进位移-当前': round(real_data['推进位移'][0], 2)}, dtype='float')  # 推进位移上载至共享变量
            self._shared_var.set(value={'刀盘转速设定值-当前': round(real_data['刀盘转速设定值'][0], 2)}, dtype='float')  # 转速设定值上载至共享变量
            self._shared_var.set(value={'推进速度设定值-当前': round(real_data['推进速度设定值'][0], 2)}, dtype='float')  # 速度设定值上载至共享变量
            # 调用数据提取模块，返回关键掘进参数(≥30s)、历史循环段数据(≤10个)、历史循环段均值, 界面历史信息(≤10个)
            key_data, passed_data, passed_mean = self.extract.run()
            self._shared_var.set(value={'key-data': key_data}, dtype='dataframe')  # 关键掘进参数上载至共享变量
            self._shared_var.set(value={'passed-data': passed_data}, dtype='list')  # 历史循环段数据上载至共享变量
            rock_index = self.break_index.run(data=key_data)  # 调用破岩参数计算模块，返回破岩数据（dataframe 1x9）
            self._shared_var.set(value={'rock-index': rock_index}, dtype='dataframe')  # 破岩参数上载至共享变量
            self._shared_var.set(value={'TPI-平均': round(rock_index['TPI-mean'][0], 2)}, dtype='float')  # TPI上载至共享变量
            self._shared_var.set(value={'FPIa-平均': round(rock_index['FPIa-mean'][0], 2)}, dtype='float')  # FPIa上载至共享变量
            self._shared_var.set(value={'FPIb-平均': round(rock_index['FPIb-mean'][0], 2)}, dtype='float')  # FPIb上载至共享变量
            self.time_count = self.time_count + 1 if construct_status == '正在掘进' else -1  # 若设备处于正在掘进状态，则运行以下代码
            self._shared_var.set(value={'计数时间戳': self.time_count}, dtype='int')  # 计数时间戳上载至共享变量
            if construct_status != '正在掘进' and len(passed_mean) > 0:  # 若设备处于正在掘进状态，则运行以下代码
                self._shared_var.set(value={'刀盘转速-之前': round(passed_mean[-1]['刀盘转速'][0], 2)}, dtype='float')  # 刀盘转速上载
                self._shared_var.set(value={'推进速度-之前': round(passed_mean[-1]['推进速度'][0], 2)}, dtype='float')  # 推进速度上载
                self._shared_var.set(value={'刀盘扭矩-之前': round(passed_mean[-1]['刀盘扭矩'][0], 2)}, dtype='float')  # 刀盘扭矩上载
                self._shared_var.set(value={'刀盘推力-之前': round(passed_mean[-1]['刀盘推力'][0], 2)}, dtype='float')  # 刀盘推力上载
                self._shared_var.set(value={'刀盘贯入度-之前': round(passed_mean[-1]['刀盘贯入度'][0], 2)}, dtype='float')
            self.PLC_timeout = 0  # PLC超时计数
        else:
            self.PLC_timeout += 1  # PLC超时计数
        self._shared_var.set(value={'PLC超时计数': self.PLC_timeout}, dtype='int')  # PLC超时计数上载至共享变量
