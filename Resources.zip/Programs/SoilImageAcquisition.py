#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-06 21:30:20                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import threading
import time
import socket
import pickle
import os
import sys
from datetime import datetime
import configparser
from WrapperTools import suppress_errors, retry

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于碴土图片获取
说明：此模块内部已定义了两个碴土图片获取的接口，即function1、function2。
     若想要继续添加接口，只需要复制一份function，并改名为function3...
     然后在 <self.function = [self.function1, self.function2]> 内部添加新接口的名称，
     例如[self.function1, self.function2, self.function3...]

===================================================================================
     """


class SoilImageAcquisition(threading.Thread):
    """渣土图片获取（analysis_soil）"""
    soil_status, client_socket, soil_image = '连接失败', None, None
    index = 0

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        super(SoilImageAcquisition, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self._temp_path = os.path.join(self._base_path, 'temp')  # 临时文件夹路径
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.server_ip = '192.168.1.110'  # 替换为服务器IP地址
        self.server_port = 8888  # 替换为服务器端口号
        self.timeout = 60  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._creative_dir_()  # 创建相关文件夹
            self._shared_var.set(value={'渣土图片信息-timeout': self.timeout}, dtype='int')  # 将要使用的渣土状况分析选项上载至共享变量
            while not self._stop_event.is_set():  # 若未接收到停止指令，则一直循环运行
                self.main()  # 运行主程序
                time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    @suppress_errors  # 处理异常并继续执行
    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        date = datetime.now()  # 获取当前时间
        weekday, hour, minute, second = date.weekday, date.hour, date.minute, date.second  # 获取当前时间
        if hour == 0 and minute == 0 and second == 0:
            self._get_config_()  # 定时加载配置文件信息（00:00:00）
        # noinspection PyBroadException
        try:
            if self._shared_var.get(key='施工状态') != '停机中':  # 若设备处于正在掘进状态，则运行以下代码
                if self.client_socket is None:  # TCP socket对象是否为None
                    self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建一个TCP socket对象
                    self.client_socket.connect((self.server_ip[self.index], self.server_port))  # 连接TCP socket对象
                    self.soil_status, self.soil_image = '连接成功', None  # 更新状态
                else:  # 若TCP socket对象已创建
                    if self._shared_var.get(key='计数时间戳') % self.timeout == 0:  # 指定时间间隔运行一次
                        self.client_socket.send('get_variable'.encode())  # 向服务端发送'get_variable'并请求获取后端文件中的变量
                        time.sleep(10)  # 等待服务端处理数据，等待时间为10s
                        self.client_socket.settimeout(5)  # 设置接收数据超时时间为5s，若5s没接收到数据则认为没有数据发送
                        image_data = b""  # 初始化接收得图片数据（二进制）
                        try:
                            while True:  # 分多次接收数据
                                received = self.client_socket.recv(1024)  # 每次接收1024 bytes
                                image_data += received  # 将接收到的数据进行拼接
                        except socket.timeout:
                            pass  # 表示已经接收完数据
                        if image_data:  # 若接收到的数据不为空，则执行以下操作
                            with open(os.path.join(self._temp_path, 'temp.jpg'), 'wb') as file:
                                file.write(image_data)  # 保存图片至临时文件夹
                            self.soil_status, self.soil_image = '获取成功', image_data  # 更新状态
                        else:  # 若未收到数据，则表示服务端可能存在问题，需要进行重启
                            raise IOError('failed to get image.')  # 抛出异常，指定类型不支持
            else:  # 若设备处于非掘进状态，则运行以下代码
                if self.client_socket is not None:  # 若TCP socket对象已存在，则运行以下代码
                    self.client_socket.send('close'.encode())  # 向服务端发送close，并请求重启服务端
                    self.client_socket.close()  # 关闭TCP socket对象
                    self.client_socket, self.soil_status, self.soil_image = None, '连接关闭', None  # 更新状态
        except (ConnectionError, ConnectionRefusedError, ConnectionResetError):
            try:
                None if self.client_socket is None else self.client_socket.close()  # 尝试关闭TCP socket对象
            except (socket.error, OSError, AttributeError):
                pass
            finally:
                self.client_socket, self.soil_status, self.soil_image = None, '连接失败', None  # 更新状态
        except (TimeoutError, socket.timeout):
            try:
                None if self.client_socket is None else self.client_socket.close()  # 尝试关闭TCP socket对象
            except (socket.error, OSError, AttributeError):
                pass
            finally:
                self.client_socket, self.soil_status, self.soil_image = None, '连接超时', None  # 更新状态
        except (socket.gaierror, socket.herror):
            try:
                None if self.client_socket is None else self.client_socket.close()  # 尝试关闭TCP socket对象
            except (socket.error, OSError, AttributeError):
                pass
            finally:
                self.client_socket, self.soil_status, self.soil_image = None, '地址错误', None  # 更新状态
        except IOError:
            try:
                None if self.client_socket is None else self.client_socket.close()  # 尝试关闭TCP socket对象
            except (socket.error, OSError, AttributeError):
                pass
            finally:
                self.client_socket, self.soil_status, self.soil_image = None, '获取失败', None  # 更新状态
        except (socket.error, OSError, BlockingIOError, FileNotFoundError, PermissionError, NotImplementedError):
            try:
                None if self.client_socket is None else self.client_socket.close()  # 尝试关闭TCP socket对象
            except (socket.error, OSError, AttributeError):
                pass
            finally:
                self.client_socket, self.soil_status, self.soil_image = None, '其他错误', None  # 更新状态
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The function has a error: {str(e)}!!!\033[0m')
        finally:
            self.index = (self.index + 1) if (self.index + 1) < len(self.server_ip) else 0
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={f'渣片系统状态': self.soil_status}, dtype='str')  # 渣土信息获取上载至共享变量
            self._shared_var.set(value={f'渣土图片信息': self.soil_image}, dtype='bytes')  # 渣土状况分析上载至共享变量
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.timeout = config.getint('SoilImageAcquisition', 'timeout')  # 执行时间间隔
            self.server_ip = config.get('SoilImageAcquisition', 'server-ip').split(',')  # 替换为服务器IP地址
            self.server_port = config.getint('SoilImageAcquisition', 'server-port')  # 替换为服务器端口号
            self._is_running = config.getboolean('SoilImageAcquisition', 'run')  # 程序是否执行

    def _creative_dir_(self) -> None:
        """创建文件夹"""
        if not os.path.exists(self._temp_path):  # 判断文件夹是否存在
            os.mkdir(self._temp_path)  # 创建相关文件夹
