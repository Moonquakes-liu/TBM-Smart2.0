#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-02 23:11:39                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************


class RecommendNV(object):
    def __init__(self, model_path):
        self.power = {'--': 1.0, 'Ⅰ': 1.0, 'Ⅱ': 1.0, 'Ⅲ': 0.9, 'Ⅳ': 0.75, 'Ⅴ': 0.40}
        self.x1_mean, self.x1_std = None, None
        self.model = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = torch.jit.load(tar.extractfile('cnn-nv-model.pkl'), map_location='cpu')  # 读取pkl文件内容并加载模型
            normalize = joblib.load(tar.extractfile('normalize-nv.pkl'))
            self.x1_mean, self.x1_std = normalize['X1_mean'], normalize['X1_std']
        self.model.eval()  # 将模型设置为评估模式
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, data_up, rock_index, admit):
        np.random.seed(111)
        perm_N = np.random.permutation(data_up.shape[0])[:30]
        data_up = data_up.reset_index(drop=True)  # 重建提取数据的行索引
        test_data_x1 = ((np.array([data_up.loc[perm_N, :].values]) - self.x1_mean) / self.x1_std).astype(float)
        with torch.no_grad():
            result_nv = self.model(torch.FloatTensor(test_data_x1))
            recommend_n, recommend_v = round(result_nv[0, 0].item(), 2), round(result_nv[0, 1].item(), 2)
        select = data_up.iloc[-30:, :]
        V_mean_30, V_std_30 = select['推进速度'].mean(), select['推进速度'].std()
        F_mean_30, F_std_30 = select['刀盘推力'].mean(), select['刀盘推力'].std()
        T_mean_30, T_std_30 = select['刀盘扭矩'].mean(), select['刀盘扭矩'].std()
        F_admit = admit['刀盘推力-之前'] if admit['刀盘推力-之前'] > 0 else float('inf')
        T_admit = admit['刀盘扭矩-之前'] if admit['刀盘扭矩-之前'] > 0 else float('inf')
        V_admit = admit['推进速度-之前'] if admit['推进速度-之前'] > 0 else float('inf')
        F_admit = min(self.power[admit['预测围岩分类']] * admit['刀盘推力容许值'], 1.25 * F_admit)
        T_admit = min(self.power[admit['预测围岩分类']] * admit['刀盘扭矩容许值'], 1.50 * T_admit)
        V_admit = min(self.power[admit['预测围岩分类']] * admit['推进速度容许值'], 1.30 * V_admit)
        F_admit_new, T_admit_new, V_admit_new = F_admit - 1 * F_std_30, T_admit - 1 * T_std_30, V_admit - 1 * V_std_30
        F_k = (rock_index['F-V-mean'][0] - rock_index['F-V-std'][0])
        F_k_min = (F_admit_new - rock_index['FPIb-mean'][0]) / V_admit_new
        F_k_min = F_k if F_k >= F_k_min else F_k_min
        recommend_temp = float('inf') if data_up.shape[0] >= 200 else recommend_v
        recommend_v1 = recommend_temp if rock_index['T-V-mean'][0] <= 0 else (T_admit_new / rock_index['T-V-mean'][0])
        recommend_v2 = recommend_temp if F_k_min <= 0 else ((F_admit_new - rock_index['FPIb-mean'][0]) / F_k_min)
        recommend_v3 = V_admit_new if V_mean_30 <= admit['推进速度容许值'] else (V_mean_30 + 1 * V_std_30)
        recommend_v = min(recommend_v1, recommend_v2, recommend_v3)
        return recommend_n, recommend_v


class RecommendTF(object):
    def __init__(self, model_path):
        self.x1_mean, self.x1_std = None, None
        self.x2_mean, self.x2_std = None, None
        self.model = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = torch.jit.load(tar.extractfile('cnn-tf-model.pkl'), map_location='cpu')  # 读取pkl文件内容并加载模型
            normalize = joblib.load(tar.extractfile('normalize-tf.pkl'))
            self.x1_mean, self.x1_std = normalize['X1_mean'], normalize['X1_std']
            self.x2_mean, self.x2_std = normalize['X2_mean'], normalize['X2_std']
        self.model.eval()  # 将模型设置为评估模式
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, data_up, data_steady):
        np.random.seed(111)
        perm_N = np.random.permutation(data_up.shape[0])[:30]
        data_up = data_up.reset_index(drop=True)  # 重建提取数据的行索引
        test_data_x1 = ((np.array([data_up.loc[perm_N, :].values]) - self.x1_mean) / self.x1_std).astype(float)
        test_data_x2 = ((np.array([data_steady.values]) - self.x2_mean) / self.x2_std).astype(float)
        result_TF = pd.DataFrame((self.model(torch.FloatTensor(test_data_x1),
                                             torch.FloatTensor(test_data_x2))).detach().numpy())
        return round(result_TF.iloc[0, 0], 2), round(result_TF.iloc[0, 1], 2)
