#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.1                                                      *
# * Date:  2024-11-23 20:33:50                                           *
# * Last  update: 2024-08-28 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import os
import random
import threading
import time
import sys
import traceback
from datetime import datetime
import configparser
import tarfile
import joblib
import numpy as np
import pandas as pd
import torch
import joblib
import torch

#  程序说明部分
if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.abspath(sys.argv[0]))


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class ParameterOptimization(threading.Thread):
    """岩体破碎概率预测（current_rock, rock_23, rock_45, support_method, risk_state）"""
    Parameter_Predict = None  # 初始化围岩二分类预测模型为空
    Parameter_Recommend = None

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        global BASE_PATH
        super(ParameterOptimization, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = BASE_PATH
        self._model_parameter_predict = os.path.join(self._base_path, 'Model', 'Parameter-Predict.tar')
        self._model_parameter_predict_modification_time = None
        self._model_parameter_recommend = os.path.join(self._base_path, 'Model', 'Parameter-Recommend.tar')
        self._model_parameter_recommend_modification_time = None
        self.predict_max = [0, 0, 0, 0, 0]
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.parameter_predict_timeout = 3  # 执行时间间隔
        self.parameter_recommend_timeout = 30  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._load_model_()  # 初次加载模型
            while not self._stop_event.is_set():
                try:
                    self.main()  # 运行主程序
                except BaseException as e:
                    self._shared_var.log(message=traceback.format_exc())
                    print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                          f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
                finally:
                    time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        if self._shared_var.get(key='计数时间戳') % self.parameter_predict_timeout == 0:  # 指定时间间隔运行一次
            parameter_predict = self._function_parameter_predict_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={'刀盘转速-预测': parameter_predict[0][0]}, dtype='float')
            self._shared_var.set(value={'推进速度-预测': parameter_predict[1][0]}, dtype='float')
            self._shared_var.set(value={'刀盘贯入度-预测': parameter_predict[2][0]}, dtype='float')
            self._shared_var.set(value={'刀盘扭矩-预测': parameter_predict[3][0]}, dtype='float')
            self._shared_var.set(value={'刀盘扭矩最大值-预测': parameter_predict[3][1]}, dtype='float')
            self._shared_var.set(value={'刀盘推力-预测': parameter_predict[4][0]}, dtype='float')
            self._shared_var.set(value={'刀盘推力最大值-预测': parameter_predict[4][1]}, dtype='float')
        if self._shared_var.get(key='计数时间戳') % self.parameter_recommend_timeout == 0:  # 指定时间间隔运行一次
            parameter_recommend = self._function_parameter_recommend_()
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
            self._shared_var.set(value={'推荐刀盘转速-经济': parameter_recommend[0][0]}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-经济': parameter_recommend[0][1]}, dtype='float')
            self._shared_var.set(value={'推荐刀盘转速-均衡': parameter_recommend[1][0]}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-均衡': parameter_recommend[1][1]}, dtype='float')
            self._shared_var.set(value={'推荐刀盘转速-高效': parameter_recommend[2][0]}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-高效': parameter_recommend[2][1]}, dtype='float')
        if self._shared_var.get(key='计数时间戳') == -1:  # 设备处于非掘进状态
            self._shared_var.set(value={'刀盘转速-预测': 0}, dtype='float')
            self._shared_var.set(value={'推进速度-预测': 0}, dtype='float')
            self._shared_var.set(value={'刀盘贯入度-预测': 0}, dtype='float')
            self._shared_var.set(value={'刀盘扭矩-预测': 0}, dtype='float')
            self._shared_var.set(value={'刀盘推力-预测': 0}, dtype='float')
            self._shared_var.set(value={'刀盘扭矩最大值-预测': 0}, dtype='float')
            self._shared_var.set(value={'刀盘推力最大值-预测': 0}, dtype='float')
            self._shared_var.set(value={'推荐刀盘转速-经济': 0}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-经济': 0}, dtype='float')
            self._shared_var.set(value={'推荐刀盘转速-均衡': 0}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-均衡': 0}, dtype='float')
            self._shared_var.set(value={'推荐刀盘转速-高效': 0}, dtype='float')
            self._shared_var.set(value={'推荐推进速度-高效': 0}, dtype='float')
            self.predict_max = [0, 0, 0, 0, 0]
            # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<

    def update(self):
        """更新模型和应用设置"""
        self._get_config_()
        self._load_model_()

    def _load_model_(self):
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_parameter_predict):
                model_parameter_predict_modification_time = os.path.getmtime(self._model_parameter_predict)
                if self._model_parameter_predict_modification_time != model_parameter_predict_modification_time:
                    parameter_predict_program = {}
                    with tarfile.open(self._model_parameter_predict, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            parameter_predict_code = file.read()
                    exec(parameter_predict_code, parameter_predict_program)
                    self.Parameter_Predict = parameter_predict_program['function'](model_path=self._model_parameter_predict)
                    self.parameter_predict_timeout = self.Parameter_Predict.timeout
                    self._model_parameter_predict_modification_time = model_parameter_predict_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_parameter_predict)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.parameter_recommend = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_parameter_predict)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_parameter_recommend):
                model_parameter_recommend_modification_time = os.path.getmtime(self._model_parameter_recommend)
                if self._model_parameter_recommend_modification_time != model_parameter_recommend_modification_time:
                    parameter_recommend_program = {}
                    with tarfile.open(self._model_parameter_recommend, 'r') as tar:
                        with tar.extractfile('Function.py') as file:
                            parameter_recommend_code = file.read()
                    exec(parameter_recommend_code, parameter_recommend_program)
                    self.Parameter_Recommend = parameter_recommend_program['function'](model_path=self._model_parameter_recommend)
                    self.parameter_recommend_timeout = self.Parameter_Recommend.timeout
                    self._model_parameter_recommend_modification_time = model_parameter_recommend_modification_time
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                          f'-> [Info] Loading model < {os.path.basename(self._model_parameter_recommend)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.parameter_recommend = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_parameter_recommend)} > failure !!!\033[0m')  # 输出相关提示信息

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'Setting', 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self._is_running = config.getboolean('ParameterOptimization', 'run')  # 程序是否执行
            self._model_parameter_predict = os.path.join(self._base_path, 'Model',
                                                         config.get('ParameterOptimization', 'parameter-predict-model'))
            self._model_parameter_recommend = os.path.join(self._base_path, 'Model',
                                                           config.get('ParameterOptimization', 'parameter-recommend-model'))

    def _function_parameter_predict_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Parameter_Predict is not None:
            parameter_predict = self.Parameter_Predict.calculate(rock_index, key_data, passed_data)
            for i, pred_value in enumerate(parameter_predict):
                self.predict_max[i] = max(self.predict_max[i], pred_value)
            return tuple((parameter_predict[i], self.predict_max[i]) for i in range(5))
        else:
            return (-1, -1), (-1, -1), (-1, -1), (-1, -1), (-1, -1)

    def _function_parameter_recommend_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Parameter_Recommend is not None:
            return self.Parameter_Recommend.calculate(rock_class=self._shared_var.get(key='预测围岩类别（四分类）'),
                                                      rock_index=rock_index,
                                                      key_data=key_data,
                                                      passed_data=passed_data,
                                                      admin_data={'刀盘扭矩-容许': self._shared_var.get(key='刀盘扭矩-容许'),
                                                                  '刀盘推力-容许': self._shared_var.get(key='刀盘推力-容许'),
                                                                  '推进速度-容许': self._shared_var.get(key='推进速度-容许')},
                                                      predict_data={'刀盘转速-预测': self._shared_var.get(key='刀盘转速-预测'),
                                                                    '推进速度-预测': self._shared_var.get(key='推进速度-预测')})
        else:
            return (-1, -1), (-1, -1), (-1, -1)
