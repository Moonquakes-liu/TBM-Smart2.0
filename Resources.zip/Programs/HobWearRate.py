#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-02 23:11:39                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import os
import sys
import threading
import time
import configparser
from datetime import datetime
from WrapperTools import suppress_errors, retry

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于滚刀磨损速率分析
说明：此模块内部已定义了两个滚刀磨损速率分析的接口，即function1、function2。
     若想要继续添加接口，只需要复制一份function，并改名为function3...
     然后在 <self.function = [self.function1, self.function2]> 内部添加新接口的名称，
     例如[self.function1, self.function2, self.function3...]

===================================================================================
     """


class HobWearRate(threading.Thread):
    """滚刀磨损速率预测（prediction_hob）"""
    Hob_Wear = None  # 初始化滚刀磨损速率预测模型为空

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        super(HobWearRate, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self._model_path = os.path.join(self._base_path, 'Model', 'HobWearRate.tar')
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.function = [self._function1_, self._function2_]  # 有关此功能的几种算法的函数名称
        self.use_function = 'function1'  # 界面展示的结果，如使用function1的结果，则填'function1'
        self.timeout = 3  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self.Hob_Wear = ...  # 初次加载滚刀磨损速率预测模型
            self._shared_var.set(value={'滚刀磨损速率-use': self.use_function}, dtype='str')  # 将要使用的渣土状况分析选项上载至共享变量
            self._shared_var.set(value={'滚刀磨损速率-timeout': self.timeout}, dtype='int')  # 将要使用的渣土状况分析选项上载至共享变量
            while not self._stop_event.is_set():  # 若未接收到停止指令，则一直循环运行
                self.main()  # 运行主程序
                time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    @suppress_errors  # 处理异常并继续执行
    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        date = datetime.now()  # 获取当前时间
        weekday, hour, minute, second = date.weekday, date.hour, date.minute, date.second  # 获取当前时间
        if hour == 0 and minute == 0 and second == 0:
            self._get_config_()  # 定时加载配置文件信息（00:00:00）
        if hour == 0 and minute == 40 and second == 0:  # 判断当前时间是否与预设时间相同
            self.Hob_Wear = ...    # 定时加载滚刀磨损速率预测模型（00:40:00）
        if self._shared_var.get(key='计数时间戳') % self.timeout == 0:  # 指定时间间隔运行一次
            for num, fuc in enumerate(self.function):  # 依次运行几种算法
                predict_hob = fuc()  # 运行相关算法并获取滚刀磨损速率值
                # >>>>>>>>>>>>>>>>>>>> 相关参数上载至共享变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
                self._shared_var.set(value={f'滚刀磨损速率-function{num + 1}': predict_hob}, dtype='str')  # 滚刀磨损速率
                # >>>>>>>>>>>>>>>>>>>> 相关参数上载至共享变量 <<<<<<<<<<<<<<<<<<<<<<<<<<

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.use_function = config.get('HobWearRate', 'use_function')  # 界面展示的结果
            self.timeout = config.getint('HobWearRate', 'timeout')  # 执行时间间隔
            self._is_running = config.getboolean('HobWearRate', 'run')  # 程序是否执行
            HobWearRate_model = config.get('HobWearRate', 'model')  # 模型文件名称
            self._model_path = os.path.join(self._base_path, 'Model', HobWearRate_model)  # 模型文件路径

    def _function1_(self) -> str:
        """
        将滚刀磨损速率预测相关代码放置在这里，也可直接调用相关代码
        :return: 滚刀磨损速率预测（prediction_hob）->-> ('低', '中', '高')
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 运行时间, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        # >>>>>>>>>>>>>>>>>>>>>> 以下代码仅在测试时使用，可将其删除 <<<<<<<<<<<<<<<<<<<<<<<<<<
        # self.Hob_Wear  滚刀磨损速率预测模型
        prediction_hob = '--'
        # >>>>>>>>>>>>>>>>>>>>>> 以上代码仅在测试时使用，可将其删除 <<<<<<<<<<<<<<<<<<<<<<<<<<
        return str(prediction_hob)  # 返回数据，请勿修改，数据格式为 str

    def _function2_(self) -> str:
        """
        将滚刀磨损速率预测相关代码放置在这里，也可直接调用相关代码
        :return: 滚刀磨损速率预测（prediction_hob）->-> ('低', '中', '高')
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 运行时间, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #         #            右侧护盾右撑位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        # >>>>>>>>>>>>>>>>>>>>>> 以下代码仅在测试时使用，可将其删除 <<<<<<<<<<<<<<<<<<<<<<<<<<
        prediction_hob = '--'
        # >>>>>>>>>>>>>>>>>>>>>> 以上代码仅在测试时使用，可将其删除 <<<<<<<<<<<<<<<<<<<<<<<<<<
        return str(prediction_hob)  # 返回数据，请勿修改，数据格式为 str
