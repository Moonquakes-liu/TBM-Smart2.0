#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  1.0.1                                                      *
# * Date:  2024-11-18 22:25:16                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************
import gc
import os
import pickle
import shutil
import csv
import threading
import time
import traceback

import pandas as pd
import sys
import configparser
from datetime import datetime

#  程序说明部分
if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))
with open(os.path.join(BASE_PATH, 'Programs', 'DataSave.py'), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于数据保存
说明：无

===================================================================================
     """


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class DataSave(threading.Thread):
    """数据保存(保存每个循环段数据、保存每天数据、保存界面显示数据）"""
    key_name = ['里程', '日期', '刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘推力', '刀盘扭矩', '刀盘贯入度',
                '推进位移', '推进压力', '顶护盾压力', '左侧护盾压力', '右侧护盾压力', '顶护盾位移', '左侧护盾位移', '右侧护盾位移',
                '撑紧压力', '左撑靴位移', '右撑靴位移', '冷水泵压力', '主机皮带机速度', '推进泵电机电流', '左小腔撑靴压力',
                '右小腔撑靴压力', '暖水箱液位', '进水温度', '减速机进水压力', '刀盘喷水压力', '减速机冷却水出口流量', '刀盘喷水泵压力',
                'EP2出口压力', 'EP2次数', '内密封前腔压力', '外密封迷宫腔压力', '内密封迷宫腔压力', '齿轮油泵1压力', '齿轮油泵2压力',
                '推进油缸前部铰接', '推进油缸后部铰接', '小轴承润滑', '提升油缸十字铰接次数', '护盾铰接次数', '喷浆泵压力', '刹车释放压力',
                '变频柜进口水压力', '撑靴泵电机电流', '循环冷却泵压力', '撑靴泵压力', '钢拱架泵压力', '主皮带机泵压力', '后配套皮带机速度',
                'C1皮带机泵电机电流', '主皮带机正转压力', '主皮带机反转压力', 'C2皮带机电机电流', '左侧楔形油缸压力', '右侧楔形油缸压力',
                '左扭矩油缸回收压力', '右扭矩油缸伸出压力', '右扭矩油缸回收压力', '左后支撑压力', '右后支撑压力', '左后支撑位移',
                '左扭矩油缸位移', '右扭矩油缸位移', '前部拖拉油缸压力', '后部拖拉油缸压力', '后左拖拉油缸位移', 'T1_L3相电压',
                'T3_L2相电流']  # 待提取的关键数据列  # 初始化要保存的关键列

    def __init__(self, _shared_var):
        """初始化各参数"""
        global BASE_PATH
        super(DataSave, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 初始化线程停止事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._last_time = pd.Timestamp('2008-08-08 12:00:00')  # 为了避免保存的数据中存在重复信息，用时间戳作为判断标准
        self._base_path = BASE_PATH
        self._temp_path = os.path.join(self._base_path, 'temp')  # 临时文件夹路径
        self._save_path = os.path.join(self._base_path, 'SaveData')  # 数据保存文件夹
        self.cycle_num = 1  # 循环段保存编号
        self.cycle_name = None
        # >>>>>>>>>>>>>>>>>>>> 保存循环段数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.cycle_path = os.path.join(self._save_path, 'Cycle')  # 保存循环段数据的文件夹路径
        self.temp_cycle = pd.DataFrame()  # 创建空的DataFrame用于保存循环段临时数据
        # >>>>>>>>>>>>>>>>>>>> 保存每天数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.daily_path = os.path.join(self._save_path, 'Daily')  # 保存每天数据的文件夹路径
        self.per_day_csv = None  # 每天数据保存路径
        # >>>>>>>>>>>>>>>>>>>> 保存界面显示数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.display_path = os.path.join(self._save_path, 'Display')  # 保存界面显示数据的文件夹路径
        self.temp_display = pd.DataFrame()  # 创建空的DataFrame用于保存界面显示临时数据
        # >>>>>>>>>>>>>>>>>>>> 保存渣土图片所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.picture_path = os.path.join(self._save_path, 'Picture')  # 保存渣土图片的文件夹路径
        self.picture_path_temp = os.path.join(self.picture_path, '.temp')  # 临时保存渣土图片的文件夹路径
        self.picture_information = {}
        self.last_modification_time = None
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._is_save_cycle = True
        self._is_save_daily = True
        self._is_save_display = True
        self._is_save_picture = True
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._creative_dir_()  # 创建文件夹
            while not self._stop_event.is_set():  # 用于判断是否结束线程
                try:
                    self.main()  # 运行主程序
                except BaseException as e:
                    self._shared_var.log(message=traceback.format_exc())
                    print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                          f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
                finally:
                    time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        real_data = self._shared_var.get(key='real-data')
        if not real_data.empty:
            run_time_values = real_data['日期'][0]
            if run_time_values != self._last_time:  # 避免保存两行相同得值
                self._save_daily_() if self._is_save_daily else None  # 保存每天的数据
                if real_data['刀盘转速'][0] > 0.1:  # 若刀盘转速大于0，则开始添加数据
                    self.temp_cycle = pd.concat([self.temp_cycle, real_data[self.key_name]], ignore_index=True, axis=0)
                    self.temp_display = pd.concat([self.temp_display, pd.DataFrame([self._shared_var.get()])], ignore_index=True, axis=0)
                    if self.cycle_name is None:  # 获取该循环段的文件名称
                        mileage = round(real_data['里程'][0], 2)  # 获取每个掘进段的起始桩号
                        Time = pd.to_datetime(real_data['日期'][0])  # 获取每个掘进段的时间记录
                        self.cycle_name = f'{self.cycle_num:05} {mileage:.2f} {Time:%Y}年{Time:%m}' \
                                          f'月{Time:%d}日 {Time:%H}时{Time:%M}分{Time:%S}秒.csv'  # 文件名
                    self._save_picture_(state='add')  # 保存渣土图片信息
                else:  # 若刀盘转速小于等于0，则对数据进行进一步操作
                    if not self.temp_cycle.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                        length = self.temp_cycle['推进位移'].max() - self.temp_cycle['推进位移'].min()  # 掘进长度
                        v_max = self.temp_cycle['推进速度'].max()  # 获取该循环段的推荐速度最小值
                        if length > 10 and v_max > 1 and self.temp_cycle.shape[0] >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                            start_mileage = round(self.temp_cycle['里程'][0], 2)  # 获取每个掘进段的起始桩号
                            start_time = pd.to_datetime(self.temp_cycle['日期'][0])  # 获取每个掘进段的时间记录
                            end_time = pd.to_datetime(self.temp_cycle['日期'].iloc[-1])  # 获取每个掘进段的时间记录
                            self._save_cycle_(state='save')  # 保存每个循环段数据
                            self._save_display_(state='save') # 保存界面展示的信息
                            self._save_picture_(state='save')  # 保存渣土图片信息
                            index_data = {'name': self.cycle_name, '循环段': self.cycle_num, '里程': start_mileage,
                                '日期': start_time, '结束时间': end_time, '掘进长度': length,
                                '掘进时间': int((end_time - start_time).total_seconds())}
                            index_data.update(self.temp_display.mean(axis=0).to_dict())
                            self._write_index_(index_data)  # 写入索引文件
                            self.cycle_num += 1  # 循环段编号增加1
                            self.cycle_name = None
                        self.temp_cycle.drop(self.temp_cycle.index, inplace=True)  # 清空临时数据，用于保存新的数据
                        self.temp_display.drop(self.temp_display.index, inplace=True)  # 清空临时数据，用于保存新的数据
                        self._save_picture_(state='delete')  # 保存渣土图片信息
                        gc.collect()
            self._last_time = run_time_values

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config', 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self._is_running = config.getboolean('DataSave', 'run')  # 主程序是否执行
            self._is_save_cycle = config.getboolean('DataSave', 'save-cycle-run')  # 循环段数据保存模块是否运行
            self._is_save_daily = config.getboolean('DataSave', 'save-daily-run')  # 每天数据保存模块是否运行
            self._is_save_display = config.getboolean('DataSave', 'save-display-run')  # 界面显示数据保存模块是否运行
            self._is_save_picture = config.getboolean('DataSave', 'save-picture-run')  # 渣土图片保存模块是否运行

    def _creative_dir_(self) -> None:
        """创建文件夹"""
        if not os.path.exists(self._temp_path):  # 判断文件夹是否存在
            os.mkdir(self._temp_path)  # 创建临时数据保存文件夹
        if not os.path.exists(self._save_path):  # 判断文件夹是否存在
            os.mkdir(self._save_path)  # 创建数据保存文件夹
        if not os.path.exists(self.cycle_path):  # 判断文件夹是否存在
            os.mkdir(self.cycle_path)  # 创建循环段数据文件夹
        if not os.path.exists(self.daily_path):  # 判断文件夹是否存在
            os.mkdir(self.daily_path)  # 创建每天数据保存文件夹
        if not os.path.exists(self.display_path):  # 判断文件夹是否存在
            os.mkdir(self.display_path)  # 创建界面展示数据文件夹
        if not os.path.exists(self.picture_path):  # 判断文件夹是否存在
            os.mkdir(self.picture_path)  # 创建渣土图片保存文件夹

    def _write_index_(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息
        """
        index_path = os.path.join(self._save_path, 'index.csv')
        with open(index_path, 'a', newline='') as csv_file:
            writer = csv.writer(csv_file)  # 实例化写入数据功能
            if os.stat(index_path).st_size == 0:  # 如果csv文件是空的，写入列名
                writer_header = csv.DictWriter(csv_file, fieldnames=list(info.keys()))
                writer_header.writeheader()
            writer.writerow(info.values())

    def _save_daily_(self) -> None:
        """
        保存每天的数据
        ->从每天00:00:00-24:00:00,理论上可以最大可以保存86400条数据
        """
        real_data = self._shared_var.get(key='real-data')  # 获取关键列数据
        Time = pd.to_datetime(real_data['日期'][0])  # 获取每个掘进段的时间记录
        if Time.hour == 0 and Time.minute == 0 or not self.per_day_csv:  # 若时间为凌晨或者刚开始运行程序，则运行以下代码
            self.per_day_csv = os.path.join(self.daily_path, f"{Time.year:4d}年{Time.month:02d}月{Time.day:02d}日.csv")
        if self.per_day_csv:  # 若每天数据保存路径不为空，则运行以下代码
            with open(self.per_day_csv, 'a', newline='') as csv_file:
                writer = csv.writer(csv_file)  # 实例化写入数据功能
                if csv_file.tell() == 0:  # 如果csv文件是空的，写入列名
                    writer_header = csv.DictWriter(csv_file, fieldnames=list(real_data))
                    writer_header.writeheader()  # 写入列名
                writer.writerow(real_data.iloc[0])  # 写入数据

    def _save_cycle_(self, state=None) -> None:
        """
        保存每个循环段数据
        ->刀盘转速大于0;
        ->推进速度最小值大于1mm/min;
        ->掘进长度大于10mm;
        ->数据量不少于200s;
        """
        if not self._is_save_cycle:
            return
        if state == 'save':
            csv_path = os.path.join(self.cycle_path, self.cycle_name)  # 当前循环段保存路径
            self.temp_cycle.to_csv(csv_path, index=False, encoding='gb2312')  # 循环段保存为csv文件

    def _save_display_(self, state=None) -> None:
        """
        保存界面显示的数据
        ->当机械处于正在掘进状态时开始保存
        """
        if not self._is_save_display:
            return
        if state == 'save':
            csv_path = os.path.join(self.display_path, self.cycle_name)  # 当前循环段保存路径
            self.temp_display.to_csv(csv_path, index=False, encoding='gb2312')  # 循环段保存为csv文件':

    def _save_picture_(self, state=None) -> None:
        """
        保存渣土图片的数据
        ->当机械处于正在掘进状态时开始保存
        """
        if not self._is_save_picture:
            return
        None if os.path.exists(self.picture_path_temp) else os.mkdir(self.picture_path_temp)  # 创建相关文件夹
        if state == 'add':
            if self._shared_var.get(key=f'渣片系统状态') == '连接成功':
                rock_pic = self._shared_var.get(key=f'渣土系统资源')
                if os.path.exists(rock_pic):
                    modification_time = os.path.getmtime(rock_pic)
                    if modification_time != self.last_modification_time:
                        formatted_time = datetime.fromtimestamp(modification_time).strftime("%Y年%m月%d日 %H时%M分%S秒")
                        shutil.copy(rock_pic, os.path.join(self.picture_path_temp, formatted_time + '.jpg'))
                        self.picture_information.update({formatted_time + '.jpg':
                                                             {'最大粒径': self._shared_var.get(key=f'最大粒径'),
                                                              '全尺寸系数': self._shared_var.get(key=f'全尺寸系数'),
                                                              '均匀系数': self._shared_var.get(key=f'均匀系数'),
                                                              '曲线系数': self._shared_var.get(key=f'曲线系数'),
                                                              '推荐加水量': self._shared_var.get(key=f'推荐加水量'),
                                                              'data': self._shared_var.get(key=f'渣土级配曲线')}})
                        with open(os.path.join(self.picture_path_temp, "data"), "wb") as f:  # 保存围岩分类历史数据为pkl文件
                            pickle.dump(self.picture_information, f)
                        self.last_modification_time = modification_time
        if state == 'save':
            new_folder_path = os.path.join(self.picture_path, os.path.splitext(self.cycle_name)[0])
            shutil.rmtree(new_folder_path) if os.path.exists(new_folder_path) else None  # 若文件夹已存在则删除
            os.rename(self.picture_path_temp, new_folder_path)  # 将.temp文件夹重命名为循环段名称
            self.picture_information.clear()
        if state == 'delete':
            shutil.rmtree(self.picture_path_temp) if os.path.exists(self.picture_path_temp) else None  # 删除.temp
            self.picture_information.clear()
