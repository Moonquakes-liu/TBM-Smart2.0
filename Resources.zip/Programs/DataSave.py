#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-03 16:06:54                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import os
import shutil
import csv
import sys
import threading
import time
from datetime import datetime
import pandas as pd
import numpy as np
from pandas import DataFrame
import sys
from WrapperTools import suppress_errors, retry
import warnings
import joblib
from PIL import Image, UnidentifiedImageError
import configparser
from sklearn.linear_model import LinearRegression
from datetime import datetime
from sklearn.neighbors import KernelDensity

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于数据保存
说明：无

===================================================================================
     """


class DataSave(threading.Thread):
    """数据保存(保存每个循环段数据、保存每天数据、保存界面显示数据）"""
    key_name = ['里程', '运行时间', '刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘推力', '刀盘扭矩', '刀盘贯入度',
                '推进位移', '推进压力', '顶护盾压力', '左侧护盾压力', '右侧护盾压力', '顶护盾位移', '左侧护盾位移', '右侧护盾位移',
                '撑紧压力', '左撑靴位移', '右撑靴位移', '冷水泵压力', '主机皮带机速度', '推进泵电机电流', '左小腔撑靴压力',
                '右小腔撑靴压力', '暖水箱液位', '进水温度', '减速机进水压力', '刀盘喷水压力', '减速机冷却水出口流量', '刀盘喷水泵压力',
                'EP2出口压力', 'EP2次数', '内密封前腔压力', '外密封迷宫腔压力', '内密封迷宫腔压力', '齿轮油泵1压力', '齿轮油泵2压力',
                '推进油缸前部铰接', '推进油缸后部铰接', '小轴承润滑', '提升油缸十字铰接次数', '护盾铰接次数', '喷浆泵压力', '刹车释放压力',
                '变频柜进口水压力', '撑靴泵电机电流', '循环冷却泵压力', '撑靴泵压力', '钢拱架泵压力', '主皮带机泵压力', '后配套皮带机速度',
                'C1皮带机泵电机电流', '主皮带机正转压力', '主皮带机反转压力', 'C2皮带机电机电流', '左侧楔形油缸压力', '右侧楔形油缸压力',
                '左扭矩油缸回收压力', '右扭矩油缸伸出压力', '右扭矩油缸回收压力', '左后支撑压力', '右后支撑压力', '左后支撑位移',
                '左扭矩油缸位移', '右扭矩油缸位移', '前部拖拉油缸压力', '后部拖拉油缸压力', '后左拖拉油缸位移', 'T1_L3相电压',
                'T3_L2相电流']  # 待提取的关键数据列  # 初始化要保存的关键列

    def __init__(self, _shared_var):
        """初始化各参数"""
        super(DataSave, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 初始化线程停止事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._last_time = pd.Timestamp('2008-08-08 12:00:00')  # 为了避免保存的数据中存在重复信息，用时间戳作为判断标准
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self._temp_path = os.path.join(self._base_path, 'temp')  # 临时文件夹路径
        self._save_path = os.path.join(self._base_path, 'SaveData')  # 数据保存文件夹
        self.cycle_num = 1  # 循环段保存编号
        self.cycle_name = None
        # >>>>>>>>>>>>>>>>>>>> 保存循环段数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.cycle_path = os.path.join(self._save_path, 'Cycle')  # 保存循环段数据的文件夹路径
        self.temp_cycle = pd.DataFrame()  # 创建空的DataFrame用于保存循环段临时数据
        # >>>>>>>>>>>>>>>>>>>> 保存每天数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.daily_path = os.path.join(self._save_path, 'Daily')  # 保存每天数据的文件夹路径
        self.per_day_csv = None  # 每天数据保存路径
        # >>>>>>>>>>>>>>>>>>>> 保存界面显示数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.display_path = os.path.join(self._save_path, 'Display')  # 保存界面显示数据的文件夹路径
        self.temp_display = pd.DataFrame()  # 创建空的DataFrame用于保存界面显示临时数据
        # >>>>>>>>>>>>>>>>>>>> 保存渣土图片所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.picture_path = os.path.join(self._save_path, 'Picture')  # 保存渣土图片的文件夹路径
        self.temp_picture = pd.DataFrame()
        self.picture_path_temp = os.path.join(self.picture_path, '.temp')  # 临时保存渣土图片的文件夹路径
        # >>>>>>>>>>>>>>>>>>>> 保存界面显示历史数据所用的变量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.history = []  # 创建空的list用于保存界面显示历史数据
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._is_save_cycle = True
        self._is_save_daily = True
        self._is_save_display = True
        self._is_save_picture = True
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._creative_dir_()  # 创建文件夹
            self._previous_state_(option='get')  # 循环段保存编号
            while not self._stop_event.is_set():  # 用于判断是否结束线程
                self.main()  # 运行主程序
                time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    @suppress_errors  # 处理异常并继续执行
    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        date = datetime.now()  # 获取当前时间
        weekday, hour, minute, second = date.weekday, date.hour, date.minute, date.second  # 获取当前时间
        if hour == 0 and minute == 0 and second == 0:
            self._get_config_()  # 定时加载配置文件信息（00:00:00）
        real_data = self._shared_var.get(key='real-data')
        if not real_data.empty:
            run_time_values = real_data['运行时间'][0]
            if run_time_values != self._last_time:  # 避免保存两行相同得值
                self._save_daily_() if self._is_save_daily else None  # 保存每天的数据
                self._save_cycle_() if self._is_save_cycle else None  # 保存每个循环段数据
                self._save_display_() if self._is_save_display else None  # 保存界面展示的信息
                self._save_picture_() if self._is_save_picture else None  # 保存渣土图片信息
            self._last_time = run_time_values

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self._is_running = config.getboolean('DataSave', 'run')  # 主程序是否执行
            self._is_save_cycle = config.getboolean('DataSave', 'save-cycle-run')  # 循环段数据保存模块是否运行
            self._is_save_daily = config.getboolean('DataSave', 'save-daily-run')  # 每天数据保存模块是否运行
            self._is_save_display = config.getboolean('DataSave', 'save-display-run')  # 界面显示数据保存模块是否运行
            self._is_save_picture = config.getboolean('DataSave', 'save-picture-run')  # 渣土图片保存模块是否运行

    def _previous_state_(self, option='get') -> None:
        """保存历史索引，便于在下次启动时继续输出"""
        local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_path = os.path.join(self._temp_path, 'history-data')  # 保存历史索引
        if option == 'get':  # 获取历史索引
            # noinspection PyBroadException
            try:
                _temp_history = joblib.load(save_path)
                self.cycle_num = _temp_history['number']
                self.history = _temp_history['history']
            except Exception:
                print(f'\033[0;33m[{local_time}] {self.__class__.__name__} -> '
                      f'[Warning] Error getting information from < {os.path.basename(save_path)} > '
                      f', The cycle number will be initialized to 1 !!!\033[0m')
        elif option == 'set':  # 设置历史索引
            _temp_history = {'date': local_time, 'number': self.cycle_num + 1, 'history': self.history}  # 界面显示历史数据
            joblib.dump(_temp_history, save_path)  # 保存历史索引(pkl)

    def _creative_dir_(self) -> None:
        """创建文件夹"""
        if not os.path.exists(self._temp_path):  # 判断文件夹是否存在
            os.mkdir(self._temp_path)  # 创建临时数据保存文件夹
        if not os.path.exists(self._save_path):  # 判断文件夹是否存在
            os.mkdir(self._save_path)  # 创建数据保存文件夹
        if not os.path.exists(self.cycle_path):  # 判断文件夹是否存在
            os.mkdir(self.cycle_path)  # 创建循环段数据文件夹
        if not os.path.exists(self.daily_path):  # 判断文件夹是否存在
            os.mkdir(self.daily_path)  # 创建每天数据保存文件夹
        if not os.path.exists(self.display_path):  # 判断文件夹是否存在
            os.mkdir(self.display_path)  # 创建界面展示数据文件夹
        if not os.path.exists(self.picture_path):  # 判断文件夹是否存在
            os.mkdir(self.picture_path)  # 创建渣土图片保存文件夹

    def _write_index_(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息
        """
        index_path = os.path.join(self._save_path, 'index.csv')
        with open(index_path, 'a', newline='') as csv_file:
            writer = csv.writer(csv_file)  # 实例化写入数据功能
            if os.stat(index_path).st_size == 0:  # 如果csv文件是空的，写入列名
                writer_header = csv.DictWriter(csv_file, fieldnames=list(info.keys()))
                writer_header.writeheader()
            writer.writerow(info.values())

    def _save_daily_(self) -> None:
        """
        保存每天的数据
        ->从每天00:00:00-24:00:00,理论上可以最大可以保存86400条数据
        """
        real_data = self._shared_var.get(key='real-data')  # 获取关键列数据
        Time = pd.to_datetime(real_data['运行时间'][0])  # 获取每个掘进段的时间记录
        if Time.hour == 0 and Time.minute == 0 or not self.per_day_csv:  # 若时间为凌晨或者刚开始运行程序，则运行以下代码
            self.per_day_csv = os.path.join(self.daily_path, f"{Time.year:4d}年{Time.month:02d}月{Time.day:02d}日.csv")
        if self.per_day_csv:  # 若每天数据保存路径不为空，则运行以下代码
            with open(self.per_day_csv, 'a', newline='') as csv_file:
                writer = csv.writer(csv_file)  # 实例化写入数据功能
                if csv_file.tell() == 0:  # 如果csv文件是空的，写入列名
                    writer_header = csv.DictWriter(csv_file, fieldnames=list(real_data))
                    writer_header.writeheader()  # 写入列名
                writer.writerow(real_data.iloc[0])  # 写入数据

    def _save_cycle_(self) -> None:
        """
        保存每个循环段数据
        ->刀盘转速大于0;
        ->推进速度最小值大于1mm/min;
        ->掘进长度大于10mm;
        ->数据量不少于200s;
        """
        real_data = self._shared_var.get(key='real-data')  # 获取关键列数据
        if real_data['刀盘转速'][0] > 0.1:  # 若刀盘转速大于0，则开始添加数据
            self.temp_cycle = pd.concat([self.temp_cycle, real_data[self.key_name]], ignore_index=True, axis=0)
            if self.cycle_name is None:  # 获取该循环段的文件名称
                mileage = round(real_data['里程'][0], 2)  # 获取每个掘进段的起始桩号
                Time = pd.to_datetime(real_data['运行时间'][0])  # 获取每个掘进段的时间记录
                self.cycle_name = f'{self.cycle_num:05} {mileage:.2f} {Time:%Y}年{Time:%m}' \
                                  f'月{Time:%d}日 {Time:%H}时{Time:%M}分{Time:%S}秒.csv'  # 文件名
        else:  # 若刀盘转速小于等于0，则对数据进行进一步操作
            if not self.temp_cycle.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                length = self.temp_cycle['推进位移'].max() - self.temp_cycle['推进位移'].min()  # 掘进长度
                v_max = self.temp_cycle['推进速度'].max()  # 获取该循环段的推荐速度最小值
                if_add = False  # 判断是否为有效循环段
                if length > 10 and v_max > 1 and self.temp_cycle.shape[0] >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                    if_add = True  # 有效循环段
                    start_mileage = round(self.temp_cycle['里程'][0], 2)  # 获取每个掘进段的起始桩号
                    start_time = pd.to_datetime(self.temp_cycle['运行时间'][0])  # 获取每个掘进段的时间记录
                    end_time = pd.to_datetime(self.temp_cycle['运行时间'].iloc[-1])  # 获取每个掘进段的时间记录
                    csv_path = os.path.join(self.cycle_path, self.cycle_name)  # 当前循环段保存路径
                    self.temp_cycle.to_csv(csv_path, index=False, encoding='gb2312')  # 循环段保存为csv文件
                    self._write_index_({'文件名': self.cycle_name, '当前里程': start_mileage, '开始时间': start_time,
                                        '结束时间': end_time, '掘进时间': int((end_time - start_time).total_seconds()),
                                        '掘进长度': length})  # 写入索引文件
                self.temp_cycle.drop(self.temp_cycle.index, inplace=True)  # 清空临时数据，用于保存新的数据
                if self.temp_display.empty and self.temp_picture.empty:
                    self.cycle_num = (self.cycle_num + 1) if if_add else self.cycle_num  # 循环段编号增加1
                    self.cycle_name = None

    def _save_display_(self) -> None:
        """
        保存界面显示的数据
        ->当机械处于正在掘进状态时开始保存
        """
        real_data = self._shared_var.get(key='real-data')  # 获取关键列数据
        if real_data['刀盘转速'][0] > 0.1:  # 若刀盘转速大于0，则开始添加数据
            real_display = self._shared_var.get()
            self.temp_display = pd.concat([self.temp_display, pd.DataFrame([real_display])], ignore_index=True, axis=0)
            if self.cycle_name is None:  # 获取该循环段的文件名称
                mileage = round(real_data['里程'][0], 2)  # 获取每个掘进段的起始桩号
                Time = pd.to_datetime(real_data['运行时间'][0])  # 获取每个掘进段的时间记录
                self.cycle_name = f'{self.cycle_num:05} {mileage:.2f} {Time:%Y}年{Time:%m}' \
                                  f'月{Time:%d}日 {Time:%H}时{Time:%M}分{Time:%S}秒.csv'  # 文件名
        else:  # 如果未处于正在掘进状态，则对数据进行进一步操作
            if not self.temp_display.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                Length = self.temp_display['推进位移-当前'].max() - self.temp_display['推进位移-当前'].min()  # 获取该循环段的掘进长度
                V_max = self.temp_display['推进速度-当前'].max()  # 获取该循环段的推荐速度最小值
                if_add = False  # 判断是否为有效循环段
                if Length > 10 and V_max > 1 and self.temp_display.shape[0] >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                    if_add = True  # 有效循环段
                    csv_path = os.path.join(self.display_path, self.cycle_name)  # 当前循环段保存路径
                    self.temp_display.to_csv(csv_path, index=False, encoding='gb2312')  # 循环段保存为csv文件
                    self._prepare_history_(data=self.temp_display)
                self.temp_display.drop(self.temp_display.index, inplace=True)  # 清空临时数据，用于保存新的数据
                if self.temp_cycle.empty and self.temp_picture.empty:
                    self.cycle_num = (self.cycle_num + 1) if if_add else self.cycle_num  # 循环段编号增加1
                    self.cycle_name = None

    def _save_picture_(self) -> None:
        """
        保存渣土图片的数据
        ->当机械处于正在掘进状态时开始保存
        """
        real_data = self._shared_var.get(key='real-data')  # 获取关键列数据
        if real_data['刀盘转速'][0] > 0.1:  # 若刀盘转速大于0，则开始添加数据
            self.temp_picture = pd.concat([self.temp_picture, real_data[['推进位移', '推进速度']]], ignore_index=True, axis=0)
            if self.cycle_name is None:  # 获取该循环段的文件名称
                mileage = round(real_data['里程'][0], 2)  # 获取每个掘进段的起始桩号
                Time = pd.to_datetime(real_data['运行时间'][0])  # 获取每个掘进段的时间记录
                self.cycle_name = f'{self.cycle_num:05} {mileage:.2f} {Time:%Y}年{Time:%m}' \
                                  f'月{Time:%d}日 {Time:%H}时{Time:%M}分{Time:%S}秒.csv'  # 文件名
            if self._shared_var.get(key='计数时间戳') % self._shared_var.get(key='渣土图片信息-timeout') == 0:
                None if os.path.exists(self.picture_path_temp) else os.mkdir(self.picture_path_temp)  # 创建相关文件夹
                Time = datetime.now()  # 获取当前时间
                Time = f'{Time:%Y}年{Time:%m}月{Time:%d}日 {Time:%H}时{Time:%M}分{Time:%S}秒'  # 将时间转换为指定格式的字符串
                if self._shared_var.get(key=f'渣片系统状态') == '获取成功':
                    rock_pic = self._shared_var.getBytes(key=f'渣土图片信息')
                    if rock_pic is not None:
                        with open(os.path.join(self.picture_path_temp, Time + '.jpg'), 'wb') as file:
                            file.write(rock_pic)
        else:
            if not self.temp_picture.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                length = self.temp_picture['推进位移'].max() - self.temp_picture['推进位移'].min()  # 掘进长度
                v_max = self.temp_picture['推进速度'].max()  # 获取该循环段的推荐速度最小值
                if_add = False  # 判断是否为有效循环段
                if length > 10 and v_max > 1 and self.temp_picture.shape[0] >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                    if_add = True  # 有效循环段
                    new_folder_path = os.path.join(self.picture_path, os.path.splitext(self.cycle_name)[0])
                    shutil.rmtree(new_folder_path) if os.path.exists(new_folder_path) else None  # 若文件夹已存在则删除
                    os.rename(self.picture_path_temp, new_folder_path)  # 将.temp文件夹重命名为循环段名称
                else:
                    shutil.rmtree(self.picture_path_temp) if os.path.exists(self.picture_path_temp) else None  # 删除.temp
                self.temp_picture.drop(self.temp_picture.index, inplace=True)  # 清空临时数据，用于保存新的数据
                if self.temp_cycle.empty and self.temp_display.empty:
                    self.cycle_num = (self.cycle_num + 1) if if_add else self.cycle_num  # 循环段编号增加1
                    self.cycle_name = None

    def _prepare_history_(self, data: DataFrame) -> None:
        history_temp = {}
        Time_start = pd.to_datetime(data['运行时间'][0], format='%Y-%m-%d %H:%M:%S')  # 对时间类型记录进行转换
        Time_end = pd.to_datetime(data['运行时间'].iloc[-1], format='%Y-%m-%d %H:%M:%S')  # 对时间类型记录进行转换
        Length = data['推进位移-当前'].max() - data['推进位移-当前'].min()  # 获取循环段的掘进长度
        target_data = data[['运行时间', '刀盘转速-当前', '推进速度-当前', '刀盘推力-当前', '刀盘扭矩-当前', '刀盘贯入度-当前']]
        target_data.columns = ['运行时间', '刀盘转速', '推进速度', '刀盘推力', '刀盘扭矩', '刀盘贯入度']
        history_temp['data'] = target_data
        history_temp['掘进编号'] = f'{int(self.cycle_num):00005d}'  # 获取循环段计数
        history_temp['当前里程'] = f'{data["里程"][0]:.2f}'  # 获取循环段起始桩号
        history_temp['开始时间'] = f'{Time_start}'  # 获取循环段起始时间
        history_temp['结束时间'] = f'{Time_end}'  # 获取循环段终止时间
        history_temp['掘进时间'] = f'{int((Time_end - Time_start).seconds)}'  # 获取循环段掘进耗时
        history_temp['掘进长度'] = f'{int(Length)}'  # 获取循环段掘进长度
        history_temp['TPI-平均'] = data["TPI-平均"].iloc[-1]
        history_temp['FPIa-平均'] = data["FPIa-平均"].iloc[-1]
        history_temp['FPIb-平均'] = data["FPIb-平均"].iloc[-1]
        data = self._remove_outliers_(data=data, option='kernel')
        history_temp['刀盘转速'] = f'{data["刀盘转速-当前"].mean():.2f}'  # 获取循环段刀盘转速均值
        history_temp['推进速度'] = f'{data["推进速度-当前"].mean():.2f}'  # 获取循环段推进速度均值
        history_temp['刀盘扭矩'] = f'{data["刀盘扭矩-当前"].mean():.2f}'  # 获取循环段刀盘推力均值
        history_temp['刀盘推力'] = f'{data["刀盘推力-当前"].mean():.2f}'  # 获取循环段刀盘扭矩均值
        option_rock = data['岩体破碎概率预测-use'].value_counts().idxmax()  # 岩体破碎概率所使用的算法
        week, rock = data[f'软弱破碎概率-{option_rock}'], data[f'当前围岩类型(四分类)-{option_rock}']
        weak_proba = week.sort_values(ascending=False).iloc[:int(data.shape[0] * 0.7)].mean()  # 从大到小排序，并取前70%数据进行求平均
        risk_state = '风险控制' if weak_proba >= 0.8 else ('预警观察' if 0.5 <= weak_proba < 0.8 else '安全掘进')
        rock = rock.drop(rock[rock == '--'].index)
        _temp_ = rock.value_counts().to_frame()
        _temp_['proportion'] = _temp_ / data.shape[0]
        _temp_['probability'] = [data.loc[data[rock == i].index, f'{i}类围岩概率-{option_rock}'].mean() for i in _temp_.index]
        _temp_['finally'] = _temp_['probability'] * _temp_['proportion']
        rock = _temp_['finally'].idxmax()
        rock_proba = _temp_.loc[rock, 'finally']
        history_temp['当前围岩类型'] = f'{rock} 类 ({rock_proba * 100:.2f}%)' if rock != '--' else '--'
        history_temp['软弱破碎概率'] = f'{weak_proba * 100:.2f}%'  # 当前循环段塌方概率
        history_temp['建议支护方式'] = '--'  # 提取建议支护方式变量
        history_temp['风险状态'] = risk_state
        option_recommend = data['控制参数推荐-use'].value_counts().idxmax()
        history_temp['推荐刀盘转速'] = f'{data[f"推荐刀盘转速-{option_recommend}"].mean():3.1f}rpm'  # 提取推荐刀盘转速变量
        history_temp['推荐推进速度'] = f'{data[f"推荐推进速度-{option_recommend}"].mean():3.1f}%'  # 提取推荐推进速度变量
        history_temp['刀盘扭矩最大值'] = round(data[f'刀盘扭矩最大值-{option_recommend}'].mean(), 2)  # 提取推荐刀盘转速变量
        history_temp['刀盘推力最大值'] = round(data[f'刀盘推力最大值-{option_recommend}'].mean(), 2)  # 提取推荐推进速度变量
        history_temp['刀盘转速-容许'] = data['刀盘转速-容许'].mean()
        history_temp['推进速度-容许'] = data['推进速度-容许'].mean()
        history_temp['刀盘推力-容许'] = data['刀盘推力-容许'].mean()
        history_temp['刀盘扭矩-容许'] = data['刀盘扭矩-容许'].mean()
        history_temp['刀盘贯入度-容许'] = data['刀盘贯入度-容许'].mean()
        history_temp['刀盘转速-脱困'] = data['刀盘转速-脱困'].mean()
        history_temp['推进速度-脱困'] = data['推进速度-脱困'].mean()
        history_temp['刀盘推力-脱困'] = data['刀盘推力-脱困'].mean()
        history_temp['刀盘扭矩-脱困'] = data['刀盘扭矩-脱困'].mean()
        history_temp['刀盘贯入度-脱困'] = data['刀盘贯入度-脱困'].mean()
        self.history.append(history_temp)  # 将界面显示的历史信息进行保存
        if len(self.history) > 10:  # 界面历史信息是否大于10个
            del self.history[0]  # 若大于10个，则删除最先添加进来的数据
        self._previous_state_(option='set')  # 保存循环段编号
        self._shared_var.set(value={'界面历史信息': self.history}, dtype='list')  # 界面历史信息上载至共享变量
        self._shared_var.set(value={f'当前围岩类型(四分类)-{option_rock}': rock}, dtype='str')
        self._shared_var.set(value={f'{rock}类围岩概率-{option_rock}': rock_proba}, dtype='float')
        self._shared_var.set(value={f'风险状态-{option_rock}': risk_state}, dtype='str')
        self._shared_var.set(value={f'软弱破碎概率-{option_rock}': weak_proba}, dtype='float')

    def _remove_outliers_(self, data: DataFrame, option='3sigma') -> DataFrame:
        """
        :param data: DataFrame格式数据
        :param option: 此函数包括，3σ方法、4分位法，默认采用3σ
        :return: 去除异常值后的数组
        """
        data = data[(data['刀盘扭矩-当前'] > 100) & (data['刀盘推力-当前'] >= 2000) &
                    (data['推进速度-当前'] <= 120) & (data['刀盘贯入度-当前'] > 1)]  # 只选取刀刀盘推力 > 3000的数据
        if option == '3sigma':
            for col in ['刀盘扭矩-当前', '刀盘贯入度-当前', '刀盘转速-当前', '推进速度-当前', '刀盘推力-当前']:  # 分别对这五个参数去除异常值
                mean, std = data[col].mean(), data[col].std()  # 计算均值、方差
                lower_limit, upper_limit = mean - 3 * std, mean + 3 * std  # 剔除3sigma范围外的异常值
                data = data[(data[col] >= lower_limit) & (data[col] <= upper_limit)]  # 去除异常值后的数据
        elif option == 'kernel':
            V = data['推进速度-当前'].to_numpy()[:, np.newaxis]  # '推进速度'转换为NumPy数组，并增加一个新的维度
            kde_V = KernelDensity(kernel="gaussian", bandwidth=10.0).fit(V)
            V_MaxDensity_index = np.argmax(np.exp(kde_V.score_samples(V)))  # 找到概率密度最大值时 推进速度的索引
            V_MaxDensity = V[V_MaxDensity_index, 0]
            data = data[0.75 * V_MaxDensity < data['推进速度-当前']]
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] Option < {option} > does not exist, please check !!!\033[0m')  # 输出相关提示信息
        return data.reset_index(drop=True)  # 返回处理后的数据
