#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-07 15:25:14                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************


class Class2_Rock_1(object):
    switch = {0: 'Ⅱ类Ⅲ类', 1: 'Ⅳ类Ⅴ类'}

    def __init__(self, model_path):
        """
        :param key_data:  DataFrame (30,n)
        :param rock_index: DataFrame ()
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.cols = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('rock-class2-lightgbm-1.pkl'))  # 读取pkl文件内容并加载模型
            self.cols = joblib.load(tar.extractfile('rock-class2-lightgbm-cols-1.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data):
        # key_data = key_data[self.cols].astype('float64')
        # Input = key_data.mean().to_frame().T  # 这里列名可能有问题，
        # y_predict, y_probability = self.model.predict(Input), self.model.predict_proba(Input)[0]  # 使用默认的阈值进行类别判断+概率判断
        key_data = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力', '推进位移']].astype('float64')
        Input = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力']].mean()
        Input['刀盘贯入度'] = Input['推进速度'] / Input['刀盘转速']
        Input['TPI'] = Input['刀盘扭矩'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['FPI'] = Input['刀盘推力'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['WR'] = (Input['刀盘扭矩'] / Input['刀盘推力']) / (Input['推进速度'] / Input['刀盘转速'])
        Input['掘进长度'] = key_data['推进位移'].max() - key_data['推进位移'].min()
        Input = Input.to_frame().T
        y_predict, y_probability = self.model.predict(Input), list(self.model.predict_proba(Input)[0])
        y_probability = [random.uniform(0.98, 0.9999) if x > 0.99 else
                         random.uniform(0.0001, 0.02) if x < 0.01 else x for x in y_probability]  # 避免概率过高
        return [self.switch[y_predict[0]], y_probability]


class Class4_Rock_1(object):
    switch = {1: 'Ⅰ', 2: 'Ⅱ', 3: 'Ⅲ', 4: 'Ⅳ', 5: 'Ⅴ'}

    def __init__(self, model_path):
        """
        :param key_data:  DataFrame (30,n)
        :param rock_index: DataFrame ()
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.cols = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('rock-class4-lightgbm-1.pkl'))  # 读取pkl文件内容并加载模型
            self.cols = joblib.load(tar.extractfile('rock-class4-lightgbm-cols-1.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data):
        # key_data = key_data[self.cols].astype('float64')
        # Input = key_data.mean().to_frame().T  # 这里列名可能有问题，
        # y_predict, y_probability = self.model.predict(Input), self.model.predict_proba(Input)[0]  # 使用默认的阈值进行类别判断+概率判断
        key_data = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力', '推进位移']].astype('float64')
        Input = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力']].mean()
        Input['刀盘贯入度'] = Input['推进速度'] / Input['刀盘转速']
        Input['TPI'] = Input['刀盘扭矩'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['FPI'] = Input['刀盘推力'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['WR'] = (Input['刀盘扭矩'] / Input['刀盘推力']) / (Input['推进速度'] / Input['刀盘转速'])
        Input['掘进长度'] = key_data['推进位移'].max() - key_data['推进位移'].min()
        Input = Input.to_frame().T
        y_predict, y_probability = self.model.predict(Input), list(self.model.predict_proba(Input)[0])
        y_probability.insert(0, 0.0)
        y_probability = [random.uniform(0.98, 0.9999) if x > 0.99 else
                         random.uniform(0.0001, 0.02) if x < 0.01 else x for x in y_probability]  # 避免概率过高
        return [self.switch[y_predict[0]], y_probability]


class Weak_Probability_1(object):
    def __init__(self, model_path):
        """
        :param key_data:  DataFrame (30,n)
        :param rock_index: DataFrame ()
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.cols = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('weak-probability-lightgbm-1.pkl'))  # 读取pkl文件内容并加载模型
            self.cols = joblib.load(tar.extractfile('weak-probability-lightgbm-cols-1.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data, rock):
        switch = {'Ⅰ': 1.0, 'Ⅱ': 1.0, 'Ⅲ': 0.6, 'Ⅳ': 0.9, 'Ⅴ': 1.0}
        key_data = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力', '推进位移']].astype('float64')
        Input = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力']].mean()
        Input['刀盘贯入度'] = Input['推进速度'] / Input['刀盘转速']
        Input['TPI'] = Input['刀盘扭矩'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['FPI'] = Input['刀盘推力'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['WR'] = (Input['刀盘扭矩'] / Input['刀盘推力']) / (Input['推进速度'] / Input['刀盘转速'])
        Input['掘进长度'] = key_data['推进位移'].max() - key_data['推进位移'].min()
        _, y_probability = self.model.predict_proba(Input.to_frame().T)[0]  # 使用默认的阈值进行类别判断+概率判
        y_probability = random.uniform(0.0001, 0.01) if y_probability < 0.01 else y_probability
        y_probability = y_probability * switch[rock] if y_probability > switch[rock] else y_probability
        return y_probability


class Weak_Probability_2(object):
    def __init__(self, model_path):
        """
        :param key_data:  DataFrame (30,n)
        :param rock_index: DataFrame ()
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.cols = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('weak-probability-lightgbm-2.pkl'))  # 读取pkl文件内容并加载模型
            self.cols = joblib.load(tar.extractfile('weak-probability-lightgbm-cols-2.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data):
        key_data = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力', '推进位移']].astype('float64')
        Input = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力']].mean()
        Input['刀盘贯入度'] = Input['推进速度'] / Input['刀盘转速']
        Input['TPI'] = Input['刀盘扭矩'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['FPI'] = Input['刀盘推力'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['WR'] = (Input['刀盘扭矩'] / Input['刀盘推力']) / (Input['推进速度'] / Input['刀盘转速'])
        Input['掘进长度'] = key_data['推进位移'].max() - key_data['推进位移'].min()
        _, y_probability = self.model.predict_proba(Input.to_frame().T)[0]  # 使用默认的阈值进行类别判断+概率判
        y_probability = random.uniform(0.0001, 0.01) if y_probability < 0.01 else y_probability
        return y_probability


class Weak_Probability_3(object):
    def __init__(self, model_path):
        """
        :param key_data:  DataFrame (30,n)
        :param rock_index: DataFrame ()
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.cols = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('weak-probability-lightgbm-3.pkl'))  # 读取pkl文件内容并加载模型
            self.cols = joblib.load(tar.extractfile('weak-probability-lightgbm-cols-3.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data):
        key_data = key_data[self.cols].astype('float64')
        Input = key_data.mean().to_frame().T  # 这里列名可能有问题，
        y_probability = self.model.predict_proba(Input)[0][-1]  # 使用默认的阈值进行类别判断+概率判断
        y_probability = random.uniform(0.0001, 0.01) if y_probability < 0.01 else y_probability
        return y_probability


class Weak_Probability_4(object):
    """概率密度计算软弱破碎概率"""
    def __init__(self, model_path):
        """
        :param model_path: 训练好的模型地址
        """
        self.model = None
        self.columns = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = joblib.load(tar.extractfile('weak-probability-bayes-4.pkl'))  # 读取pkl文件内容并加载模型
            self.columns = joblib.load(tar.extractfile('weak-probability-bayes-cols-4.pkl'))  # 读取pkl文件内容并加载模型
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, key_data):
        Input = key_data[['刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值', '刀盘扭矩', '刀盘推力']].mean()
        Input['刀盘贯入度'] = Input['推进速度'] / Input['刀盘转速']
        Input['TPI'] = Input['刀盘扭矩'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['FPI'] = Input['刀盘推力'] / (Input['推进速度'] / Input['刀盘转速'])
        Input['WR'] = 2000 * np.pi * (Input['刀盘扭矩'] / Input['刀盘推力']) / (Input['推进速度'] / Input['刀盘转速'])
        print(self.model['samples'])
        print(self.columns)
        print(Input[self.columns])
        Merge = pd.concat([self.model['samples'][self.columns], Input[self.columns].to_frame().T], ignore_index=True)
        Rank = Merge.rank(axis=0, method='min', ascending=True)
        cdf = (Rank.iloc[-1] - 1) / Rank.shape[0]
        test_ita = ((1 - cdf * cdf) * (self.model['beta'].iloc[0] / self.model['beta'].iloc[0].sum())).sum()
        poly_reg = PolynomialFeatures(degree=3)
        # Fit a polynomial regression model
        lin_reg = LinearRegression()
        x = poly_reg.fit_transform(self.model['ita-R1'].iloc[:, [0]])
        y = self.model['ita-R1'].iloc[:, [1]]
        lin_reg.fit(x, y)
        # Predict new values for "软弱破碎围岩概率"
        test_X = poly_reg.fit_transform(pd.DataFrame([test_ita]))
        y_probability = lin_reg.predict(test_X)
        return y_probability[0][0]
