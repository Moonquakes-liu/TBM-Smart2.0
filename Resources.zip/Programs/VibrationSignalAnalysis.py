#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  1.0.1                                                      *
# * Date:  2024-11-18 22:25:16                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import pickle
import _pickle
import socket
import os
import threading
import time
import sys
import traceback
from datetime import datetime
import configparser
import tarfile

#  程序说明部分
if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))
with open(os.path.join(BASE_PATH, 'Programs', 'VibrationSignalAnalysis.py'), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于围岩分类预测
说明：无

===================================================================================
     """


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class VibrationSignalAnalysis(threading.Thread):
    """岩体破碎概率预测（current_rock, rock_23, rock_45, support_method, risk_state）"""
    Vibration_Analysis = None  # 初始化围岩二分类预测模型为空
    Vibration_Support_Measures = None
    Client_Socket = None

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        global BASE_PATH
        super(VibrationSignalAnalysis, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = BASE_PATH
        self._model_vibration_analysis = os.path.join(self._base_path, 'Model', 'Vibration-Analysis.tar')
        self._model_vibration_support_measures = os.path.join(self._base_path, 'Model', 'Vibration-Support-Measures.tar')
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.server_ip = '0.0.0.0'  # 替换为服务器IP地址
        self.server_port = 8888  # 替换为服务器端口号
        self.vibration_analysis_timeout = 30  # 执行时间间隔
        self.vibration_support_measures_timeout = 30  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    def _load_model_(self):
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_vibration_analysis):
                vibration_analysis_program = {}
                with tarfile.open(self._model_vibration_analysis, 'r') as tar:
                    with tar.extractfile('Function.py') as file:
                        vibration_analysis_code = file.read()
                exec(vibration_analysis_code, vibration_analysis_program)
                self.Vibration_Analysis = vibration_analysis_program['function'](model_path=self._model_vibration_analysis)
                self.vibration_analysis_timeout = self.Vibration_Analysis.timeout
                print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                      f'-> [Info] Loading model < {os.path.basename(self._model_vibration_analysis)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.Vibration_Analysis = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_vibration_analysis)} > failure !!!\033[0m')  # 输出相关提示信息
        # noinspection PyBroadException
        try:
            if os.path.exists(self._model_vibration_support_measures):
                vibration_support_measures_program = {}
                with tarfile.open(self._model_vibration_support_measures, 'r') as tar:
                    with tar.extractfile('Function.py') as file:
                        vibration_support_measures_code = file.read()
                exec(vibration_support_measures_code, vibration_support_measures_program)
                self.Vibration_Support_Measures = vibration_support_measures_program['function'](model_path=self._model_vibration_support_measures)
                self.vibration_support_measures_timeout = self.Vibration_Support_Measures.timeout
                print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                      f'-> [Info] Loading model < {os.path.basename(self._model_vibration_support_measures)} > successful !!!\033[0m')  # 输出相关提示信息
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            self.vibration_support_measures = None
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Loading model < {os.path.basename(self._model_vibration_support_measures)} > failure !!!\033[0m')  # 输出相关提示信息

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._load_model_()  # 初次加载模型
            while not self._stop_event.is_set():
                try:
                    self.main()  # 运行主程序
                except BaseException as e:
                    self._shared_var.log(message=traceback.format_exc())
                    print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                          f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
                finally:
                    time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        # noinspection PyBroadException
        try:
            self.Client_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建服务器套接字
            self.Client_Socket.connect((self.server_ip, self.server_port))  # 连接TCP socket对象
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                  f'[Info] Connect slag collection system successful, IP: {self.server_ip}  Port: {self.server_port}!!!\033[0m')
            timeout_count = 0
            while True:
                bytes_data = b""  # 接收图片数据
                try:
                    bytes_size = int.from_bytes(self.Client_Socket.recv(4), 'big')  # 接收总数居大小（4字节）
                    while len(bytes_data) < bytes_size:
                        bytes_data += self.Client_Socket.recv(1024)
                except _pickle.UnpicklingError:
                    self._shared_var.log(message=traceback.format_exc())
                    bytes_data = b""  # 接收图片数据
                if not bytes_data:
                    if timeout_count > 5:
                        raise ValueError(f'Connect timeout！')  # 若key不在dict中，则抛出错误
                    else:
                        timeout_count += 1
                        time.sleep(1)
                        continue
                if bytes_data:  # 若接收到的数据不为空，则执行以下操作
                    dict_data = pickle.loads(bytes_data)
                    for local in ['顶护盾', '刀盘']:
                        for direct in ['X方向', 'Y方向', 'Z方向']:
                            self._shared_var.set(value={f'{local}-{direct}-系统状态': True}, dtype='bool')
                            self._shared_var.set(value={f'{local}-{direct}-时域': dict_data[f'{local}-{direct}-时域']}, dtype='float')
                            self._shared_var.set(value={f'{local}-{direct}-频域': dict_data[f'{local}-{direct}-频域']}, dtype='float')
                            if self._shared_var.get(key='计数时间戳') % self.vibration_analysis_timeout == 0:  # 指定时间间隔运行一次
                                vibration_analysis = self._function_vibration_analysis_()
                                # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
                                self._shared_var.set(value={f'{local}-{direct}-均方幅值': vibration_analysis[0]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-峰值': vibration_analysis[1]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-有效值': vibration_analysis[2]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-峰峰值': vibration_analysis[3]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-裕度指标': vibration_analysis[4]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-歪度指标': vibration_analysis[5]}, dtype='float')
                                self._shared_var.set(value={f'{local}-{direct}-峭度指标': vibration_analysis[6]}, dtype='float')
                                # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
                            if self._shared_var.get(key='计数时间戳') % self.vibration_support_measures_timeout == 0:  # 指定时间间隔运行一次
                                vibration_support_measures = self._function_vibration_support_measures_()
                                # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
                                self._shared_var.set(value={f'{local}-{direct}-分析结果': vibration_support_measures}, dtype='str')
                                # >>>>>>>>>>>>>>> 将预测结果上载至共享变量 <<<<<<<<<<<<<<<<<<
                timeout_count = 0
        except ConnectionRefusedError:
            for local in ['顶护盾', '刀盘']:
                for direct in ['X方向', 'Y方向', 'Z方向']:
                    self._shared_var.set(value={f'{local}-{direct}-系统状态': False}, dtype='bool')
                    self._shared_var.set(value={f'{local}-{direct}-时域': 0}, dtype='float')
                    self._shared_var.set(value={f'{local}-{direct}-频域': 0}, dtype='float')
        except _pickle.UnpicklingError:
            self._shared_var.log(message=traceback.format_exc())
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            for local in ['顶护盾', '刀盘']:
                for direct in ['X方向', 'Y方向', 'Z方向']:
                    self._shared_var.set(value={f'{local}-{direct}-系统状态': False}, dtype='bool')
                    self._shared_var.set(value={f'{local}-{direct}-时域': 0}, dtype='float')
                    self._shared_var.set(value={f'{local}-{direct}-频域': 0}, dtype='float')
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                  f'[Error] The vibration-signal collection system is abnormal, Retrying in 30 seconds. !!!\033[0m')
        finally:
            # noinspection PyBroadException
            try:
                self.Client_Socket.close()  # 关闭客户端连接
            except Exception:
                pass
            time.sleep(30)

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config', 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.server_ip = config.get('VibrationSignalAnalysis', 'server-ip')
            self.server_port = config.getint('VibrationSignalAnalysis', 'server-port')
            self._model_vibration_analysis = os.path.join(self._base_path, 'Model', config.get('VibrationSignalAnalysis', 'vibration-analysis-model'))
            self._model_vibration_support_measures = os.path.join(self._base_path, 'Model', config.get('VibrationSignalAnalysis', 'vibration-support-measures-model'))

    def _function_vibration_analysis_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Vibration_Analysis is not None:
            return self.Vibration_Analysis.calculate(rock_index, key_data, passed_data)
        else:
            return -1, -1, -1, -1, -1, -1, -1

    def _function_vibration_support_measures_(self):
        """
        将岩体破碎概率预测相关代码放置在这里
        :return: 围岩二分类（rock_two_class） -> [当前围岩类型('Ⅱ类 Ⅲ类', 'Ⅳ类 Ⅴ类'), Ⅱ类Ⅲ类围岩概率, Ⅳ类Ⅴ类围岩概率]
                 围岩四分类（rock_four_class） -> [当前围岩类型('Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ'), Ⅰ类概率， Ⅱ类概率, Ⅲ类概率, Ⅳ类概率, Ⅴ类概率]
                 建议支护方式（support_method）-> ('暂  无', '立  拱')
                 风险状态（risk_state）-> ('安全掘进', '预警观察', '风险控制')
                 软弱破碎概率（weak_probability）->
        """
        # 破岩指标（TPI_mean, TPI_std, FPI_mean, FPI_std, WR_mean, WR_std, a, b, r2}），请勿修改
        rock_index = self._shared_var.get(key='rock-index')  # 数据格式 DataFrame
        # 破岩关键数据(桩号, 日期, 刀盘转速, 刀盘给定转速显示值, 推进速度, 推进给定速度百分比, 总推进力,
        #            刀盘扭矩, 贯入度, 推进位移, 推进压力, 冷水泵压力, 控制泵压力, 撑紧压力, 左撑靴油缸行程检测,
        #            右撑靴油缸行程检测, 主机皮带机转速, 顶护盾压力, 左侧护盾压力, 右侧护盾压力, 左侧护盾位移,
        #            右侧护盾位移, 推进泵电机电流)，请勿修改
        key_data = self._shared_var.get(key='key-data')  # 数据格式 DataFrame
        # 历史掘进段数据，请勿修改
        passed_data = self._shared_var.get(key='passed-data')  # 数据格式 list
        if self.Vibration_Support_Measures is not None:
            return self.Vibration_Support_Measures.calculate(rock_index, key_data, passed_data)
        else:
            return 'No Information!'
