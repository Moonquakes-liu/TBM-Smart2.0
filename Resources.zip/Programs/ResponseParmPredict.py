#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-03 15:55:59                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************


class PredictTF_CNN(object):
    def __init__(self, model_path):
        self.x1_mean, self.x1_std = None, None
        self.x2_mean, self.x2_std = None, None
        self.model = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = torch.jit.load(tar.extractfile('cnn-tf-model.pkl'), map_location='cpu')  # 读取pkl文件内容并加载模型
            normalize = joblib.load(tar.extractfile('normalize-tf.pkl'))  # 读取pkl文件内容并加载模型
            self.x1_mean, self.x1_std = normalize['X1_mean'], normalize['X1_std']
            self.x2_mean, self.x2_std = normalize['X2_mean'], normalize['X2_std']
        self.model.eval()  # 将模型设置为评估模式
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, data_up, data_steady):
        np.random.seed(111)
        perm_N = np.random.permutation(data_up.shape[0])[:30]
        data_up = data_up.reset_index(drop=True)  # 重建提取数据的行索引
        test_data_x1 = ((np.array([data_up.loc[perm_N, :].values]) - self.x1_mean) / self.x1_std).astype(float)
        test_data_x2 = ((np.array([data_steady.values]) - self.x2_mean) / self.x2_std).astype(float)
        result_TF = pd.DataFrame((self.model(torch.FloatTensor(test_data_x1),
                                             torch.FloatTensor(test_data_x2))).detach().numpy())
        return round(result_TF.iloc[0, 0], 2), round(result_TF.iloc[0, 1], 2)


class PredictNV_CNN(object):
    def __init__(self, model_path):
        self.x1_mean, self.x1_std = None, None
        self.model = None
        self.load_model(path=model_path)

    def load_model(self, path):
        with tarfile.open(path, 'r') as tar:
            self.model = torch.jit.load(tar.extractfile('cnn-nv-model.pkl'), map_location='cpu')  # 读取pkl文件内容并加载模型
            normalize = joblib.load(tar.extractfile('normalize-nv.pkl'))  # 读取pkl文件内容并加载模型
            self.x1_mean, self.x1_std = normalize['X1_mean'], normalize['X1_std']
        self.model.eval()  # 将模型设置为评估模式
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Loading model < {os.path.basename(path)} > successful !!!\033[0m')  # 输出相关提示信息

    def calculate(self, data_up):
        np.random.seed(111)
        perm_N = np.random.permutation(data_up.shape[0])[:30]
        data_up = data_up.reset_index(drop=True)  # 重建提取数据的行索引
        test_data_x1 = ((np.array([data_up.loc[perm_N, :].values]) - self.x1_mean) / self.x1_std).astype(float)
        with torch.no_grad():
            result_nv = self.model(torch.FloatTensor(test_data_x1))
        return round(result_nv[0, 0].item(), 2), round(result_nv[0, 1].item(), 2)
