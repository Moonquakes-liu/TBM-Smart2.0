#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-07 15:25:14                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import os
import re
import smtplib
import sys
import time
import random
import threading
import zipfile
import warnings
import psutil
import configparser
import pandas as pd
import numpy as np
from pandas import DataFrame
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
from io import BytesIO
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Table
from reportlab.lib.utils import ImageReader
from sklearn.neighbors import KernelDensity
from WrapperTools import suppress_errors, retry
import matplotlib
from matplotlib import font_manager
import matplotlib.image as mpimg
matplotlib.use('Agg')
from matplotlib import pyplot as plt, pyplot

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于界面显示数据发送及日报周报发送
说明：无

===================================================================================
     """


class CreativePDF(object):
    """创建报表Report"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取程序所在的目录
    back_rock_info = mpimg.imread(os.path.join(base_path, 'Resources', 'rock-info.png'))  # 围岩状况模块背景图片
    back_parm_recommend = mpimg.imread(os.path.join(base_path, 'Resources', 'parm-recommend.png'))  # 控制参数推荐模块背景图片
    pdfmetrics.registerFont(TTFont('微软雅黑', os.path.join(base_path, 'Fonts', '微软雅黑.ttf')))  # 为pdf加载微软雅黑字体
    pdfmetrics.registerFont(TTFont('Times New Roman', os.path.join(base_path, 'Fonts', 'Times New Roman.ttf')))  # 加载字体
    custom_font = font_manager.FontProperties(fname=os.path.join(base_path, 'Fonts', '微软雅黑.ttf'))  # 创建一个字体属性对象
    plt.rcParams['font.family'] = custom_font.get_name()  # 为plt加载微软雅黑字体
    
    def __init__(self):
        """初始化各参量"""
        self.Image_data = BytesIO()  # 开辟一块空间用于保存绘制的画布
        self.PDF = None  # 创建PDF对象，准备向内部添加信息
        self.page = 1  # 初始化页码初始值
        self.title = '引绰济辽工程<水电六局>循环掘进数据表'  # PDF的表格名称

    def creative_PDF(self, info: dict):
        """
        开始向PDF内部添加信息
        :param info: 待添加的信息
                    {'起始桩号': float, '结束桩号': float, '掘进长度': float, '掘进时间': float, '起始时间': str,
                    '结束时间': str, '环号': str, '班组': str, '刀盘转速-实际': float, '速度设定-实际': float,
                    '推进速度-实际': float, '刀盘推力-实际': float, '刀盘扭矩-实际': float, '贯入度-实际': float,
                    '刀盘转速-建议': float, '速度设定-建议': float, '推进速度-建议': float, '刀盘推力-建议': float,
                    '刀盘扭矩-建议': float, '贯入度-建议': float, '预测围岩分类': str, '风险掘进提示': str,
                    '支护建议': str, '塌方概率': float, 'data': DataFrame}
        """
        # >>>>>>>>>>>>>>>>>>> 每个单元格内的信息 <<<<<<<<<<<<<<<<<<<<<<
        values = [[['起始桩号', f'{info["起始桩号"]:.2f}m', '环  号', info['环号'],
                    '掘进长度', f'{int(info["掘进长度"])}mm', '起始时间', info['起始时间']]],
                  [['结束桩号', f'{info["结束桩号"]:.2f}m', '班  组', info['班组'],
                    '掘进时间', f'{int(info["掘进时间"])}s', '结束时间', info['结束时间']]],
                  [['控制参数及其设定值', '响应参数及其预测值']],
                  [['', '']],
                  [['p-F、T关系', '推进速度及其设定值关系']],
                  [['', '']],
                  [['围岩信息评估', '控制参数推荐']],
                  [['', '']],
                  [['渣片信息1', '掘进段均值', '渣片信息2']],
                  [['', '', '']],
                  [['操作设定', '刀盘转速\n(r/min)', '速度设定\n(%)', '推进速度\n(mm/min)',
                    '刀盘推力\n(kN)', '刀盘扭矩\n(kN.m)', '贯入度\n(mm/r)']],
                  [['实际值', f'{info["刀盘转速-实际"]:.2f}', f'{info["速度设定-实际"]:.2f}', f'{info["推进速度-实际"]:.2f}',
                    f'{info["刀盘推力-实际"]:.2f}', f'{info["刀盘扭矩-实际"]:.2f}', f'{info["刀盘贯入度-实际"]:.2f}']],
                  [['建议值', f'{info["刀盘转速-建议"]:.2f}', f'{info["速度设定-建议"]:.2f}', f'{info["推进速度-建议"]:.2f}',
                    f'{info["刀盘推力-建议"]:.2f}', f'{info["刀盘扭矩-建议"]:.2f}', f'{info["刀盘贯入度-建议"]:.2f}']]]
        # >>>>>>>>>>>>>>>>>>> 每列单元格宽度信息 <<<<<<<<<<<<<<<<<<<<<<
        colWidths = [[18 * mm, 21 * mm, 18 * mm, 18 * mm, 18 * mm, 18 * mm, 18 * mm, 39 * mm],
                     [18 * mm, 21 * mm, 18 * mm, 18 * mm, 18 * mm, 18 * mm, 18 * mm, 39 * mm],
                     [84 * mm, 84 * mm],
                     [84 * mm, 84 * mm],
                     [84 * mm, 84 * mm],
                     [84 * mm, 84 * mm],
                     [84 * mm, 84 * mm],
                     [84 * mm, 84 * mm],
                     [59 * mm, 50 * mm, 59 * mm],
                     [59 * mm, 50 * mm, 59 * mm],
                     [24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm],
                     [24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm],
                     [24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm]]
        # >>>>>>>>>>>>>>>>>>> 每行单元格高度信息 <<<<<<<<<<<<<<<<<<<<<<
        rowHeights = [[8 * mm], [8 * mm], [7 * mm],
                      [50 * mm], [7 * mm], [50 * mm], [7 * mm], [50 * mm],
                      [7 * mm], [50 * mm], [10 * mm], [8 * mm], [8 * mm]]
        # >>>>>>>>>>>>>>>>>>> 每行单元格位置坐标（竖向） <<<<<<<<<<<<<<<<<<<<<<
        local_y = [273 * mm, 265 * mm, 258 * mm,
                   208 * mm, 201 * mm, 151 * mm, 144 * mm, 94 * mm,
                   87 * mm, 37 * mm, 27 * mm, 19 * mm, 11 * mm]
        # >>>>>>>>>>>>>>>>>>> 每行单元格颜色填充信息  <<<<<<<<<<<<<<<<<<<<<<
        Colors = ['#FFFFFF', '#FFFFFF', '#F2F7FC', '#FFFFFF',
                  '#F2F7FC', '#FFFFFF', '#F2F7FC', '#FFFFFF', '#F2F7FC',
                  '#FFFFFF', '#F2F7FC', '#FFFFFF', '#F0FFF0', '#FFFFFF']
        # >>>>>>>>>>>>>>>>>>> 向单元格内添加信息 <<<<<<<<<<<<<<<<<<<<<<
        for row, col, value, y, color in zip(rowHeights, colWidths, values, local_y, Colors):
            sheet = Table(data=value, colWidths=col, rowHeights=row,
                          style={("FONT", (0, 0), (-1, 0), '微软雅黑', 10),  # 字体类型
                                 ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),  # 字体颜色为黑色
                                 ('BACKGROUND', (0, 0), (-1, 0), color),
                                 ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                 ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # 左右上下居中
                                 ('INNERGRID', (0, 0), (-1, -1), 0.7, colors.black),  # 显示内部框线
                                 ('BOX', (0, 0), (-1, -1), 0.7, colors.black)})
            sheet.wrapOn(self.PDF, 0, 0)  # 将表格添加到Canvas中
            sheet.drawOn(self.PDF, 30 * mm, y)  # 将表格添加到Canvas中
        # >>>>>>>>>>>>>>>>>>> 向单元格内添加第一列信息 <<<<<<<<<<<<<<<<<<<<<<
        sheet = Table(data=[['基本信息'], ['参数历时\n信息'], ['参数相关\n性信息'], ['掘进操作\n建议']],
                      colWidths=[18 * mm],
                      rowHeights=[16 * mm, 57 * mm, 57 * mm, 140 * mm],
                      style={("FONT", (0, 0), (-1, -1), '微软雅黑', 10),  # 字体类型
                             ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),  # 字体颜色为黑色
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                             ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # 左右上下居中
                             ('INNERGRID', (0, 0), (-1, -1), 0.7, colors.black),  # 显示内部框线
                             ('BOX', (0, 0), (-1, -1), 0.7, colors.black)})
        sheet.wrapOn(self.PDF, 0, 0)  # 将表格添加到Canvas中
        sheet.drawOn(self.PDF, 12 * mm, 11 * mm)  # 将表格添加到Canvas中
        # >>>>>>>>>>>>>>>>>>> 向每页PDF表格添加名称  <<<<<<<<<<<<<<<<<<<<<<
        self.PDF.setFont('微软雅黑', 16)
        self.PDF.drawString(53 * mm, 285 * mm, self.title)
        # >>>>>>>>>>>>>>>>>>> 向每页PDF添加页脚信息  <<<<<<<<<<<<<<<<<<<<<<
        self.PDF.setFont('Times New Roman', 8)
        self.PDF.drawString(13 * mm, 7 * mm, 'Creative by:TBM Smart v2.0')
        self.PDF.drawString(166 * mm, 7 * mm, 'Power by:@IWHE&BJTU')
        # >>>>>>>>>>>>>>>>>>> 向每页PDF添加页码  <<<<<<<<<<<<<<<<<<<<<<
        sheet = Table([[f'Page{self.page}']], colWidths=[15 * mm], rowHeights=[5 * mm],  # 绘制页码框
                      style={("FONT", (0, 0), (-1, -1), 'Times New Roman', 9),  # 设置页码字体类型和大小
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 页码居中
        sheet.wrapOn(self.PDF, 0, 0)  # 将页码框添加到Canvas中
        sheet.drawOn(self.PDF, 97.5 * mm, 3 * mm)  # 将页码框添加到Canvas中
        # >>>>>>>>>>>>>>>>>>> 向每页PDF添加图片  <<<<<<<<<<<<<<<<<<<<<<
        self.add_control_parm(data=info['data'])  # 控制参数及其设定值
        self.add_responsible_parm(data=info['data'])  # 响应参数及其预测值
        self.add_TF_parm(data=info['data'])  # p-F、T关系
        self.add_vset_parm(data=info['data'])  # 推进速度及其设定值关系
        self.add_rock_info(data=info)
        self.add_mean_info(data=info)
        self.add_parm_recommend(data=info)
        self.add_muck1_info(data=info)
        self.add_muck2_info(data=info)
        self.page += 1  # 页码自增
        self.PDF.showPage()  # 正文新增一页

    def add_control_parm(self, data: DataFrame):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            x_time = data['运行时间'].values
            timestamps = (np.array([datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S') for time_str in x_time])
                          - datetime.strptime(x_time[0], '%Y-%m-%d %H:%M:%S'))
            x_timestamp = timestamps.astype('timedelta64[s]').astype(float)
            y_n = data['刀盘转速']  # y1轴刀盘转速
            y_n_set = data['刀盘转速设定值']  # y1轴刀盘转速设定值
            y_n_recommend = data['推荐刀盘转速']  # y1轴刀盘转速推荐值
            y_v = data['推进速度']  # y2轴推进速度
            y_v_set = data['推进速度设定值']  # y2轴推进速度设定值
            y_v_recommend = data['推荐推进速度']  # y2轴推进速度推荐值
            plt.figure(figsize=(8, 4.5), dpi=120, frameon=True, edgecolor='black')  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            plt.scatter(x_timestamp, y_n, label='刀盘转速(r/min) ', color='k', marker='.', s=50)  # 添加散点图n
            plt.scatter(x_timestamp, y_n_set, label='刀盘转速设定值(r/min) ', color='b', marker='.', s=50)  # 添加散点图n_set
            plt.plot(x_timestamp, y_n_recommend, label='建议刀盘转速(r/min) ', color='#00CBCC', lw=3)  # 添加折线图n_recommend
            plt.ylabel("刀盘转速(r/min)", fontsize=19)  # 添加y1轴名称
            plt.yticks(fontsize=15)  # 设置y1轴刻度值字体大小
            plt.ylim(ymin=0, ymax=int(data['刀盘转速-脱困'][0]))  # 设置y1轴范围
            plt.xlabel("时  间(s)", fontsize=19)  # 设置x轴名称
            plt.xticks(fontsize=15)  # 设置x轴刻度值字体大小
            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.21), ncol=3,
                       fontsize=12, markerscale=1.5, frameon=False)
            plt.twinx()  # 添加第二个y轴
            plt.scatter(x_timestamp, y_v, label='推进速度(mm/min)', color='y', marker='.', s=50)  # 添加散点图v
            plt.scatter(x_timestamp, y_v_set, label='推进速度设定值(mm/min)', color='#9B641A', marker='.', s=50)  # 添加散点图v_set
            plt.plot(x_timestamp, y_v_recommend, label='建议推进速度(mm/min)', color='g', lw=3)  # 添加折线图v_recommend
            plt.ylabel("推进速度(mm/min)", fontsize=19)  # 添加y2轴名称
            plt.yticks(fontsize=15)  # 设置y2轴刻度值字体大小
            plt.ylim(ymin=0, ymax=int(data['推进速度-脱困'][0]))  # 设置y2轴范围
            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.13), ncol=3,
                       fontsize=12, markerscale=1.5, frameon=False)
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')  # 保存图片
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=31 * mm, y=209 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')  # 将图片添加至pdf
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_control_parm.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=31 * mm, y=209 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')  # 将图片添加至pdf
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_responsible_parm(self, data: DataFrame):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            x_time = data['运行时间'].values
            timestamps = (np.array([datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S') for time_str in x_time])
                          - datetime.strptime(x_time[0], '%Y-%m-%d %H:%M:%S'))
            x_timestamp = timestamps.astype('timedelta64[s]').astype(float)
            y_T = data['刀盘扭矩']  # y1轴刀盘扭矩
            y_T_pre = data['预测刀盘扭矩']  # y1轴预测刀盘扭矩
            y_F = data['刀盘推力']  # y2轴刀盘推力
            y_F_pre = data['预测刀盘推力']  # y2轴预测刀盘推力
            plt.figure(figsize=(8, 4.5), dpi=120, frameon=True, edgecolor='black')  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            plt.scatter(x_timestamp, y_T, label='刀盘扭矩(kN.m)', color='r', marker='.', s=50)  # 添加散点图T
            plt.scatter(x_timestamp, y_T_pre, label='预测刀盘扭矩(kN.m)', color='#9B641A', marker='.')  # 添加散点图T_pre
            plt.ylabel("刀盘扭矩(kN.m)", fontsize=19)  # 添加y1轴名称
            plt.yticks(fontsize=15)  # 设置y1轴刻度值字体大小
            plt.ylim(ymin=0, ymax=int(data['刀盘扭矩-脱困'][0]))  # 设置y1轴范围
            plt.xlabel("时  间(s)", fontsize=19)  # 设置x轴名称
            plt.xticks(fontsize=15)  # 设置x轴刻度值字体大小
            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.21), ncol=2, fontsize=12,
                       markerscale=1.5, frameon=False, labelspacing=1.05)  # 添加图例
            plt.twinx()  # 添加第二个y轴
            plt.scatter(x_timestamp, y_F, label='刀盘推力(kN)  ', color='b', marker='.', s=50)  # 添加散点图F
            plt.scatter(x_timestamp, y_F_pre, label='预测刀盘推力(kN)  ', color='#00D810', marker='.')  # 添加散点图F_pre
            plt.ylabel("刀盘推力(kN)", fontsize=19)  # 添加y2轴名称
            plt.yticks(fontsize=15)  # 设置y2轴刻度值字体大小
            plt.ylim(ymin=0, ymax=int(data['刀盘推力-脱困'][0]))  # 设置y2轴范围
            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.13), ncol=2, fontsize=12,
                       markerscale=1.5, frameon=False, labelspacing=1.05)  # 添加图例
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')  # 保存图片
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=209 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_responsible_parm.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=209 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_TF_parm(self, data: DataFrame):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            y_p = data['刀盘贯入度']  # x轴刀盘贯入度
            y_T = data['刀盘扭矩']  # y1轴刀盘扭矩
            y_F = data['刀盘推力']  # y2轴刀盘推力
            p_permit, p_max = int(data['刀盘贯入度-容许'][0]), int(data['刀盘贯入度-脱困'][0])
            T_permit, T_max = int(data['刀盘扭矩-容许'][0]), int(data['刀盘扭矩-脱困'][0])
            F_permit, F_max = int(data['刀盘推力-容许'][0]), int(data['刀盘推力-容许'][0] / (T_permit / T_max))
            plt.figure(figsize=(8, 4.5), dpi=120, frameon=True, edgecolor='black')  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            plt.scatter(y_p, y_T, color='r', label='刀盘扭矩(kN.m)', marker='.', s=50)  # 添加散点图T
            plt.plot([0, p_max], [T_permit, T_permit], ls="-.", color='r', dashes=(7, 3, 3, 3))  # 贯入度容许边界线
            plt.plot([p_permit, p_permit], [0, T_max], ls="-.", color='g', dashes=(7, 3, 3, 3))  # 扭矩推力容许值边界线
            plt.plot([0, p_max], [0, p_max * (y_T.mean() / y_p.mean())], ls="--", color='r', dashes=(7, 3))  # 拟扭矩合线
            plt.ylabel("扭  矩(kN.m)", fontsize=19)  # 添加y1轴名称
            plt.ylim(ymin=0, ymax=T_max)  # 设置y1轴范围
            plt.yticks(fontsize=15)  # 设置y1轴刻度值字体大小
            plt.xlabel("贯入度(mm/r)", fontsize=19)  # 设置x轴名称
            plt.xlim(xmin=0, xmax=p_max)  # 设置x轴范围
            plt.xticks(fontsize=15)  # 设置x轴刻度值字体大小
            plt.fill([0, 0, p_permit, p_permit], [0, T_permit, T_permit, 0], c="#CCFFC9", alpha=0.5, zorder=0)  # 设置区域填充
            plt.legend(loc='upper center', bbox_to_anchor=(0.3, 1.14), ncol=3,
                       fontsize=12, markerscale=1.5, frameon=False)
            plt.twinx()  # 添加第二个y轴
            plt.scatter(y_p, y_F, color='b', label='刀盘推力(kN)  ', marker='.', s=50)  # 添加散点图F
            plt.ylabel("推  力(kN)  ", fontsize=19)  # 添加y2轴名称
            k, b = np.polyfit(y_p, y_F, 1)[:2]  # 刀盘推力拟合
            plt.plot([0, p_max], [b, b + p_max * k], ls="--", color='b', dashes=(7, 3))  # 拟合线
            plt.ylim(ymin=0, ymax=F_max)  # 设置y2轴范围
            plt.yticks(fontsize=15)  # 设置y2轴刻度值字体大小
            plt.legend(loc='upper center', bbox_to_anchor=(0.7, 1.14), ncol=3,
                       fontsize=12, markerscale=1.5, frameon=False)
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')  # 保存图片
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=31 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_TF_parm.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=31 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_vset_parm(self, data: DataFrame):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            x_v = data['推进速度']  # 推进速度
            y_v_set = data['推进速度设定值']  # 推进速度设定值
            v_max = int(data['推进速度-脱困'][0])  # 推进速度脱困值
            plt.figure(figsize=(8, 4.5), dpi=120, frameon=True, edgecolor='black')  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            plt.scatter(x_v, y_v_set, label="实际值", color='k', marker='.', s=50)  # 添加散点图v-v_set
            k, b = np.polyfit(x_v.astype(float), y_v_set.astype(float), 1)[:2]  # 数据拟合线
            plt.plot([0, v_max], [b, b + v_max * k], label="线性关系", ls="--", color='b', dashes=(7, 3))  # 拟合线
            plt.ylabel("推进速度设定值(%)", fontsize=19)  # 添加y轴名称
            plt.yticks(fontsize=15)  # 设置y轴刻度值字体大小
            plt.ylim(ymin=0, ymax=100)  # 设置y轴范围
            plt.xlabel("推进速度(mm/min)", fontsize=19)  # 添加x轴名称
            plt.xticks(fontsize=15)  # 设置x轴刻度值字体大小
            plt.xlim(xmin=0, xmax=v_max)  # 设置x轴范围
            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.14), ncol=3,
                       fontsize=12, markerscale=1.5, frameon=False)
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_vset_parm.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_rock_info(self, data: dict):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            fig, ax = plt.subplots(figsize=(8, 4.5))  # 绘制雷达图
            # 将背景图片设置为轴对象的背景
            ax.imshow(self.back_rock_info, extent=[0, 800, 0, 450])
            fig.subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=None, hspace=None)  # 调整边距为0
            ax.axis('off')  # 隐藏坐标轴
            ax.set_xlim(0, 800)  # 设置x和y坐标轴的范围为0到1
            ax.set_ylim(0, 450)  # 设置x和y坐标轴的范围为0到1
            ax.text(290, 275, f'{data["预测围岩分类"]}', ha='center', va='center', fontsize=15, c='#2C66CE')
            ax.text(290, 182, f'{data["塌方概率"]}', ha='center', va='center', fontsize=15, c='#2C66CE')
            ax.text(290, 87, '--', ha='center', va='center', fontsize=15, c='#2C66CE')
            risk = data['风险掘进提示']
            if risk == "安全掘进":
                plt.scatter(520, 275, s=150, facecolors='g')
                plt.scatter(520, 182, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 87, s=150, facecolors='none', edgecolors='k')
            elif risk == "预警观察":
                plt.scatter(520, 275, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 182, s=150, facecolors='y')
                plt.scatter(520, 87, s=150, facecolors='none', edgecolors='k')
            elif risk == "风险控制":
                plt.scatter(520, 275, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 182, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 87, s=150, facecolors='r')
            else:
                plt.scatter(520, 275, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 182, s=150, facecolors='none', edgecolors='k')
                plt.scatter(520, 87, s=150, facecolors='none', edgecolors='k')
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=31 * mm, y=95 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_rock_info.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_parm_recommend(self, data: dict):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            fig, ax = plt.subplots(figsize=(8, 4.5))  # 绘制雷达图
            ax.imshow(self.back_parm_recommend, extent=[0, 800, 0, 450])  # 将背景图片设置为轴对象的背景
            fig.subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=None, hspace=None)  # 调整边距为0
            ax.axis('off')  # 隐藏坐标轴
            ax.set_xlim(0, 800)  # 设置x和y坐标轴的范围为0到1
            ax.set_ylim(0, 450)  # 设置x和y坐标轴的范围为0到1
            ax.text(214, 320, f'{data["刀盘转速-建议"]:.1f}rpm', ha='center', va='center', fontname='Arial',
                    fontweight='bold', fontsize=39, c='#2C66CE')
            ax.text(568, 320, f'{data["速度设定-建议"]:.1f}%', ha='center', va='center', fontname='Arial',
                    fontweight='bold', fontsize=39, c='#2C66CE')
            ax.text(300, 45, f'{data["刀盘扭矩-建议"]:.2f}', ha='center', va='center', fontsize=16)
            ax.text(500, 45, f'{data["刀盘推力-建议"]:.2f}', ha='center', va='center', fontsize=16)
            ax.text(690, 45, '--', ha='center', va='center', fontsize=16)
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=95 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_parm_recommend.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(8, 4.5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=115 * mm, y=152 * mm,
                               width=82 * mm, height=48 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_mean_info(self, data: dict):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            angles = np.linspace(90, 90 - 360, 5, endpoint=False)
            angles = [np.deg2rad(angle) for angle in angles]  # 将角度转换为弧度
            angles += angles[:1]  # 闭合图形
            fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True), facecolor='#F7FBFA')  # 绘制雷达图
            fig.subplots_adjust(left=0.07, bottom=0, right=0.93, top=0.95, wspace=None, hspace=None)  # 调整边距为0
            for angle, label in zip(angles, ['扭矩', '速度', '转速', '贯入度', '推力']):
                ax.plot([angle, angle], [0, 140], color='k', linewidth=1)  # 绘制连线
                plt.text(angle, 155, label, ha='center', va='center', fontsize=15)
            for radius, color, line in zip([40, 60, 80, 100, 120, 140], ['k', 'k', 'k', 'y', 'k', 'r'],
                                           [1, 1, 1, 1.5, 1, 1.5]):
                theta = np.linspace(0, 2 * np.pi, 100)
                if radius not in [100, 140]:
                    plt.polar(theta, np.full_like(theta, radius), c=color, linewidth=line, dashes=(7, 3))
                else:
                    plt.polar(theta, np.full_like(theta, radius), c=color, linewidth=line)
            ax.set_ylim(0, 140.5)  # 设置最大刻度
            plt.axis('off')  # 隐藏坐标轴
            Real = {"刀盘扭矩": 140, "推进速度": 140, "刀盘转速": 140, "刀盘贯入度": 140, "刀盘推力": 140}
            Reco = {"刀盘扭矩": 140, "推进速度": 140, "刀盘转速": 140, "刀盘贯入度": 140, "刀盘推力": 140}
            for key in ['刀盘扭矩', '推进速度', '刀盘转速', '刀盘贯入度', '刀盘推力']:
                if data[f'{key}-实际'] <= data[f'{key}-容许']:
                    Real[key] = data[f'{key}-实际'] / data[f'{key}-容许'] * 100
                if data[f'{key}-建议'] <= data[f'{key}-容许']:
                    Reco[key] = data[f'{key}-建议'] / data[f'{key}-容许'] * 100
                if data[f'{key}-容许'] <= data[f'{key}-实际'] <= data[f'{key}-脱困']:
                    Real[key] = 100 + (data[f'{key}-实际']-data[f'{key}-容许']) / (data[f'{key}-脱困']-data[f'{key}-容许']) * 40
                if data[f'{key}-容许'] <= data[f'{key}-建议'] <= data[f'{key}-脱困']:
                    Reco[key] = 100 + (data[f'{key}-建议']-data[f'{key}-容许']) / (data[f'{key}-脱困']-data[f'{key}-容许']) * 40
            reco_new = list(Reco.values()) + list(Reco.values())[:1]  # 替换为你的具体数据
            interp_reco = np.interp(np.linspace(0, 1, len(angles)), np.linspace(0, 1, len(reco_new)), reco_new)
            ax.fill(angles, interp_reco, '#34E604', alpha=0.25)  # 绘制填充区域
            line1 = ax.plot(angles, interp_reco, color='#34E604', linewidth=1.5)  # 绘制连线
            real_new = list(Real.values()) + list(Real.values())[:1]  # 替换为你的具体数据
            interp_real = np.interp(np.linspace(0, 1, len(angles)), np.linspace(0, 1, len(real_new)), real_new)
            ax.fill(angles, interp_real, '#5672FC', alpha=0.25)  # 绘制填充区域
            line2 = ax.plot(angles, interp_real, color='#5672FC', linewidth=1.5)  # 绘制连线
            legend1 = ax.legend([line1[0]], ['建议值'], bbox_to_anchor=(0.2, 1.08), fontsize=12, frameon=False)  # 添加图例
            legend2 = ax.legend([line2[0]], ['实际值'], bbox_to_anchor=(1.05, 1.08), fontsize=12, frameon=False)  # 添加图例
            ax.add_artist(legend1)  # 添加图例到图形中
            ax.add_artist(legend2)  # 添加图例到图形中
            plt.savefig(self.Image_data, bbox_inches='tight', format='png')
            plt.close()  # 关闭画布
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=89.5 * mm, y=37.5 * mm,
                               width=49 * mm, height=49 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_mean_info.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(6, 5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=89.5 * mm, y=37.5 * mm,
                               width=49 * mm, height=49 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_muck1_info(self, data: dict):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            self.PDF.drawImage(image=data['渣片信息1'], x=30.5 * mm, y=37.5 * mm,
                               width=58 * mm, height=49 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_muck1_info.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(6, 5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=30.5 * mm, y=37.5 * mm,
                               width=58 * mm, height=49 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_muck2_info(self, data: dict):
        """
        绘制控制参数及其设定值图片
        :param data: 绘图所需信息（DataFrame）
        """
        try:
            self.PDF.drawImage(image=data['渣片信息2'], x=139.5 * mm, y=37.5 * mm,
                               width=58 * mm, height=49 * mm, anchor='c')
        except Exception as e:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] function < {self.add_muck2_info.__name__} > has error in: {e}  !!!\033[0m')
            self.add_loss_info(size=(6, 5))
            self.PDF.drawImage(image=ImageReader(self.Image_data), x=139.5 * mm, y=37.5 * mm,
                               width=58 * mm, height=49 * mm, anchor='c')
        finally:
            # 清空字节流内容
            self.Image_data.seek(0)
            self.Image_data.truncate(0)

    def add_loss_info(self, size):
        plt.figure(figsize=size, dpi=120, frameon=True, edgecolor='black')  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
        plt.subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=None, hspace=None)  # 调整边距为0
        plt.text(0.5, 0.5, 'Missing information', fontsize=14, ha='center')
        plt.axis('off')  # 隐藏坐标轴
        plt.savefig(self.Image_data, bbox_inches='tight', format='png')
        plt.close()  # 关闭画布

    def run(self, data: list, path: str):
        """
        开始创建报表PDF
        :param data: 待添加的信息[{}, {} ... {}, {}]
        :param path: pdf保存路径
        """
        plt.rcParams['axes.edgecolor'] = 'black'
        self.PDF = Canvas(filename=path, bottomup=1, pageCompression=1)  # 创建pdf对象
        for page in data:
            self.creative_PDF(info=page)  # 依次创建和添加数据
        self.PDF.save()  # 保存PDF


class DataSend(threading.Thread):
    """数据发送"""
    if_send_display, if_send_daily, if_send_weekly = False, False, False  # 初始化发送信息开关，保证信息准确发送

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param shared_data: 共享变量
        """
        super(DataSend, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self._save_path = os.path.join(self._base_path, 'SaveData')  # 界面显示数据源  # 界面显示数据源
        self._display_path = os.path.join(self._save_path, 'Display')  # 保存界面显示数据的文件夹路径
        self._picture_path = os.path.join(self._save_path, 'Picture')  # 保存渣土图片的文件夹路径
        self._send_path = os.path.join(self._base_path, 'SendData')  # 数据保存文件夹
        self._daily_data_path = os.path.join(self._send_path, 'DailyData')  # 初始化每天界面显示数据临时保存文件夹
        self._daily_report_path = os.path.join(self._send_path, 'DailyReport')  # 初始化每天报表数据临时保存文件夹
        self._week_report_path = os.path.join(self._send_path, 'WeekReport')  # 初始化每周报表数据临时保存文件夹
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.server_address = 'smtp.qq.com'  # SMTP 服务器地址
        self.server_port = 465  # SMTP 服务器端口
        self.sender_email = '2425693503@qq.com'  # 邮件发送者账号
        self.sender_password = 'qeuzerptkdnaecje'  # 邮件发送者授权码
        self._is_send_display = True  # 是否发送界面显示数据
        self._is_send_daily = True  # 是否发送日报
        self._is_send_weekly = True  # 是否发送周报
        self.timer_send_display = datetime.strptime('1:00:00', '%H:%M:%S').hour
        self.timer_send_daily = datetime.strptime('2:00:00', '%H:%M:%S').hour
        self.timer_send_weekly = datetime.strptime('4:00:00', '%H:%M:%S').hour
        self.receiver_daily_paper = ['']  # 文件接收者
        self.receiver_weekly_paper = ['']  # 文件接收者
        self.receiver_display_data = ['']  # 文件接收者
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._creative_dir_()  # 创建文件夹
            while not self._stop_event.is_set():
                self.main()  # 运行主程序
                time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    @suppress_errors  # 处理异常并继续执行
    def main(self) -> None:
        """主程序，调用相关算法进行预测"""
        date = datetime.now()  # 获取当前时间
        weekday, hour, minute, second = date.weekday, date.hour, date.minute, date.second  # 获取当前时间
        if hour == 0 and minute == 0:
            self.if_send_display, self.if_send_daily, self.if_send_weekly = False, False, False
        if hour == 0 and minute == 0 and second == 0:
            self._get_config_()  # 定时加载配置文件信息（00:00:00）
        if self._is_send_display and hour == self.timer_send_display and not self.if_send_display:
            self._prepare_display_data_()  # 定时发送界面显示数据至每位接收者（01:00:00）
            self.if_send_display = True

        a, b = datetime.strptime('13:36:00', '%H:%M:%S').hour, datetime.strptime('13:36:00', '%H:%M:%S').minute
        if self._is_send_daily and hour == a and minute == b and not self.if_send_daily:
        # if self._is_send_daily and hour == self.timer_send_daily and not self.if_send_daily:
            self._prepare_daily_paper_()  # 定时发送日报至每位接收者（02:00:00）
            self.if_send_daily = True
        if self._is_send_weekly and weekday == 0 and hour == self.timer_send_weekly and not self.if_send_weekly:
            self._prepare_weekly_paper_()  # 定时发送周报至每位接收者（03:00:00）
            self.if_send_weekly = True

    def _creative_dir_(self) -> None:
        """创建文件夹"""
        if not os.path.exists(self._send_path):  # 判断文件夹是否存在
            os.mkdir(self._send_path)  # 创建相关文件夹
        if not os.path.exists(self._daily_data_path):  # 判断文件夹是否存在
            os.mkdir(self._daily_data_path)  # 创建相关文件夹
        if not os.path.exists(self._daily_report_path):  # 判断文件夹是否存在
            os.mkdir(self._daily_report_path)  # 创建相关文件夹
        if not os.path.exists(self._week_report_path):  # 判断文件夹是否存在
            os.mkdir(self._week_report_path)  # 创建相关文件夹

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.server_address = config.get('DataSend', 'server-address')  # SMTP 服务器地址
            self.server_port = config.getint('DataSend', 'server-port')  # SMTP 服务器端口
            self.sender_email = config.get('DataSend', 'sender-email')  # 邮件发送者账号
            self.sender_password = config.get('DataSend', 'sender-password')  # 邮件发送者授权码
            self._is_send_display = config.getboolean('DataSend', 'run-send-display')
            self._is_send_daily = config.getboolean('DataSend', 'run-send-daily')
            self._is_send_weekly = config.getboolean('DataSend', 'run-send-weekly')
            self.receiver_daily_paper = config.get('DataSend', 'receiver-email-daily').split(',')  # 文件接收者
            self.receiver_weekly_paper = config.get('DataSend', 'receiver-email-weekly').split(',')  # 文件接收者
            self.receiver_display_data = config.get('DataSend', 'receiver-email-display').split(',')  # 文件接收者
            self.timer_send_display = datetime.strptime(config.get('DataSend', 'timer-send-display'), '%H:%M:%S').hour
            self.timer_send_daily = datetime.strptime(config.get('DataSend', 'timer-send-daily'), '%H:%M:%S').hour
            self.timer_send_weekly = datetime.strptime(config.get('DataSend', 'timer-send-weekly'), '%H:%M:%S').hour
            self._is_running = config.getboolean('DataSend', 'run')  # 程序是否执行

    def _send_email_(self, receivers: list, headline: str, content: str, filename: str = None):
        """
        发送邮件
        :param receivers:
        :param headline: 邮件标题
        :param content: 邮件内容
        :param filename: 邮件附件路径
        """
        for receiver in receivers:  # 遍历每位邮件接收者
            # 构建邮件内容
            msg = MIMEMultipart()  # 构建邮件内容
            msg['From'] = self.sender_email  # 邮件发送者
            msg['To'] = receiver  # 邮件接收者
            msg['Subject'] = headline  # 邮件标题
            msg.attach(MIMEText(content))  # 邮件内容
            # 添加附件
            if filename:  # 判断是否需要添加附件
                attachment = open(filename, 'rb')  # 加载邮件附件
                part = MIMEBase('application', 'octet-stream')  #
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment', filename=os.path.basename(filename))  # 添加附件名称
                msg.attach(part)
            try:
                server = smtplib.SMTP_SSL(self.server_address, self.server_port)
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, [receiver], msg.as_string())
                server.quit()
                print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                      f'-> [Info] Email send to < {receiver} >successfully !!!\033[0m')  # 输出相关提示信息
            except Exception as e:
                print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                      f'-> [Error] Failed to send Email, The error message is as follows: {e} !!!\033[0m')  # 输出相关提示信息

    def _prepare_display_data_(self) -> None:
        """准备每天的界面显示数据"""
        today = datetime.now()
        yesterday = today - timedelta(days=1)  # 获取昨天的日期
        date_start = pd.to_datetime(f'{yesterday.year}-{yesterday.month}-{yesterday.day} {7}:{00}:{00}',
                                    format='%Y-%m-%d %H:%M:%S')
        date_finish = pd.to_datetime(f'{today.year}-{today.month}-{today.day} {7}:{00}:{00}',
                                     format='%Y-%m-%d %H:%M:%S')
        send_file = [file for file in os.listdir(self._display_path) if date_start <= datetime.strptime(
            re.search(r'\d{4}年\d{2}月\d{2}日 \d{2}时\d{2}分\d{2}秒', file).group(0), '%Y年%m月%d日 %H时%M分%S秒') <= date_finish]
        target_path = os.path.join(self._daily_data_path,
                                   f'Data {yesterday.year:04d}年{yesterday.month:02d}月{yesterday.day:02d}日.zip')
        with zipfile.ZipFile(target_path, 'w') as zipf:  # 创建一个ZIP文件对象，以写入模式打开
            for file in send_file:  # 逐个将文件添加到ZIP文件中
                zipf.write(os.path.join(self._display_path, file), arcname=file)  # 向zip中添加文件
        if self.receiver_display_data != ['']:
            if send_file:
                self._send_email_(receivers=self.receiver_display_data, headline='TBM每日界面显示数据',
                                  content=os.path.basename(target_path), filename=target_path)  # 发送邮件，包含附件
            else:
                self._send_email_(receivers=self.receiver_display_data, headline='TBM每日界面显示数据',
                                  content='当天未产生任何掘进数据。', filename=None)  # 发送邮件，未产生任何数据
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The feature < send-display-data > does not define mail recipients !!!\033[0m')

    def _prepare_daily_paper_(self) -> None:
        """准备每天的施工数据报表"""
        yesterday = datetime.now() - timedelta(days=1)  # 获取昨天的日期
        y, m, d = yesterday.year, yesterday.month, yesterday.day
        send_data = [self._cycle_information_(path=os.path.join(self._display_path, file))
                     for file in os.listdir(self._display_path) if
                     datetime.strptime(file.split()[2], '%Y年%m月%d日').date() == yesterday.date()]  # 寻找昨天产生的界面显示数据文件
        target_path = os.path.join(self._daily_report_path, f'Report {y:04d}年{m:02d}月{d:02d}日.pdf')
        CreativePDF().run(data=send_data, path=target_path)  # 创建日报pdf
        if self.receiver_daily_paper != ['']:
            if send_data:  # 判断当天是否产生掘进数据
                self._send_email_(receivers=self.receiver_daily_paper, headline='TBM每日施工数据报表',
                                  content=os.path.basename(target_path), filename=target_path)  # 邮件发送
            else:
                self._send_email_(receivers=self.receiver_daily_paper, headline='TBM每日施工数据报表',
                                  content='当天未产生任何掘进数据。', filename=None)  # 邮件发送
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The feature < send-daily-data > does not define mail recipients !!!\033[0m')

    def _prepare_weekly_paper_(self) -> None:
        """准备每周的施工数据报表"""
        week_start, week_end = datetime.now() - timedelta(days=7), datetime.now() - timedelta(days=1)  # 获取上周时间范围
        send_data = [self._cycle_information_(path=os.path.join(self._display_path, file))
                     for file in os.listdir(self._display_path)
                     if week_start <= datetime.strptime(file.split()[2], '%Y年%m月%d日') <= week_end]
        file_name = f'Report {week_start.year:04d}年{week_start.month:02d}月{week_start.day:02d}日-' \
                    f'{week_end.year:04d}年{week_end.month:02d}月{week_end.day:02d}日.pdf'
        target_path = os.path.join(self._week_report_path, file_name)  # 周报pdf保存
        CreativePDF().run(data=send_data, path=target_path)
        if self.receiver_weekly_paper != ['']:
            if send_data:  # 判断当天是否产生掘进数据
                self._send_email_(receivers=self.receiver_weekly_paper, headline='TBM每周施工数据报表',
                                  content=os.path.basename(target_path), filename=target_path)  # 邮件发送
            else:
                self._send_email_(receivers=self.receiver_weekly_paper, headline='TBM每周施工数据报表',
                                  content='当天未产生任何掘进数据。', filename=None)  # 邮件发送
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The feature < send-weekly-data > does not define mail recipients !!!\033[0m')

    def _remove_outliers_(self, data: DataFrame, option='3sigma') -> DataFrame:
        """
        :param data: DataFrame格式数据
        :param option: 此函数包括，3σ方法、4分位法，默认采用3σ
        :return: 去除异常值后的数组
        """
        data = data[(data['刀盘扭矩-当前'] > 100) & (data['刀盘推力-当前'] >= 2000) &
                    (data['推进速度-当前'] <= 120) & (data['刀盘贯入度-当前'] > 1)]  # 只选取刀刀盘推力 > 3000的数据
        if option == '3sigma':
            for col in ['刀盘扭矩-当前', '刀盘贯入度-当前', '刀盘转速-当前', '推进速度-当前', '刀盘推力-当前']:  # 分别对这五个参数去除异常值
                mean, std = data[col].mean(), data[col].std()  # 计算均值、方差
                lower_limit, upper_limit = mean - 3 * std, mean + 3 * std  # 剔除3sigma范围外的异常值
                data = data[(data[col] >= lower_limit) & (data[col] <= upper_limit)]  # 去除异常值后的数据
        elif option == 'kernel':
            V = data['推进速度-当前'].to_numpy()[:, np.newaxis]  # '推进速度'转换为NumPy数组，并增加一个新的维度
            kde_V = KernelDensity(kernel="gaussian", bandwidth=10.0).fit(V)
            V_MaxDensity_index = np.argmax(np.exp(kde_V.score_samples(V)))  # 找到概率密度最大值时 推进速度的索引
            V_MaxDensity = V[V_MaxDensity_index, 0]
            data = data[0.75 * V_MaxDensity < data['推进速度-当前']]
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] Option < {option} > does not exist, please check !!!\033[0m')  # 输出相关提示信息
        return data.reset_index(drop=True)  # 返回处理后的数据

    def _cycle_information_(self, path: str) -> dict:
        """
        计算每个循环段界面显示相关信息
        :param path: 界面显示数据的路径
        """
        cycle_raw = pd.read_csv(path, encoding='gb2312')  # 读取符合条件的界面显示数据
        # >>>>>>>>>>>>>>>>>>>> 获取基本参量 <<<<<<<<<<<<<<<<<<<<<<<<<<
        Time_start = pd.to_datetime(cycle_raw['运行时间'][0], format='%Y-%m-%d %H:%M:%S')
        Time_end = pd.to_datetime(cycle_raw['运行时间'].iat[-1], format='%Y-%m-%d %H:%M:%S')
        Length = cycle_raw['推进位移-当前'].max() - cycle_raw['推进位移-当前'].min()  # 获取循环段的掘进长度
        Time = (Time_end - Time_start).seconds  # 获取循环段掘进耗时
        Stake_start = cycle_raw['里程'][0]  # 获取循环段起始桩号
        Stake_end = cycle_raw['里程'].iat[-1]  # 获取循环段起始桩号
        cycle = self._remove_outliers_(data=cycle_raw, option='kernel')
        option_rock = cycle['岩体破碎概率预测-use'].value_counts().idxmax()  # 岩体破碎概率所使用的算法
        _temp_ = cycle[f'当前围岩类型(四分类)-{option_rock}'].value_counts()
        _temp_ = _temp_.sort_index()
        # _temp_ = _temp_[_temp_ >= 60].sort_index()
        Predict_rock = _temp_.index[-1] if _temp_.size > 0 else '--'
        if Predict_rock != '--':
            _temp_ = cycle[f'{Predict_rock}类围岩概率-{option_rock}']
            rock_probability = _temp_[_temp_ > 0].mean()
            Predict_rock = f'{Predict_rock} 类 ({rock_probability * 100:.2f}%)'
        Support_method = cycle[f'建议支护方式-{option_rock}'].value_counts().idxmax()  # 当前循环段建议支护方式
        _temp_ = cycle[f'软弱破碎概率-{option_rock}'].value_counts()
        # _temp_ = _temp_[_temp_ >= 50].sort_index()
        _temp_ = _temp_.sort_index()
        _temp_ = _temp_.drop(_temp_.index[-1]).iloc[-5:] if _temp_.size > 0 else _temp_
        Collapse = _temp_.mul(_temp_.index).sum() / _temp_.sum() if _temp_.size > 0 else 0.01
        if Collapse >= 0.8:
            Risk_state = '风险控制'
        elif 0.5 <= Collapse < 0.8:
            Risk_state = '预警观察'
        else:
            Risk_state = '安全掘进'
        Collapse = f'{Collapse * 100:.2f}%'  # 当前循环段塌方概率
        group = cycle['班组'].value_counts().idxmax()  # 当前循环段所属班组
        T_admit, T_max = cycle['刀盘扭矩-容许'][0], cycle['刀盘扭矩-脱困'][0]
        F_admit, F_max = cycle['刀盘推力-容许'][0], cycle['刀盘推力-脱困'][0]
        V_admit, V_max = cycle['推进速度-容许'][0], cycle['推进速度-脱困'][0]
        N_admit, N_max = cycle['刀盘转速-容许'][0], cycle['刀盘转速-脱困'][0]
        P_admit, P_max = cycle['刀盘贯入度-容许'][0], cycle['刀盘贯入度-脱困'][0]
        # >>>>>>>>>>>>>>>>>>>> 获取循环段数据 <<<<<<<<<<<<<<<<<<<<<<<<<<
        out_data = pd.DataFrame()  # 收集界面报表pdf所使用的文件
        option_control = cycle['控制参数推荐-use'].value_counts().idxmax()  # 控制参数推荐所使用的算法
        option_responsible = cycle['响应参数预测-use'].value_counts().idxmax()  # 响应参数预测所使用的算法
        out_data['运行时间'] = cycle_raw['运行时间']  # 添加运行时间数据
        out_data['刀盘转速'] = cycle_raw['刀盘转速-当前']  # 添加刀盘转速数据
        out_data['刀盘转速设定值'] = cycle_raw['刀盘转速设定值-当前']  # 添加刀盘转速设定值数据
        out_data['推荐刀盘转速'] = cycle_raw[f'推荐刀盘转速-{option_control}']  # 添加推荐刀盘转速数据
        out_data['推进速度'] = cycle_raw['推进速度-当前']  # 添加推进速度数据
        out_data['推进速度设定值'] = cycle_raw['推进速度设定值-当前']  # 添加推进速度设定值数据
        out_data['推荐推进速度'] = cycle_raw[f'推荐推进速度-{option_control}']  # 添加推荐推进速度数据
        out_data['刀盘扭矩'] = cycle_raw['刀盘扭矩-当前']  # 添加刀盘扭矩数据
        out_data['预测刀盘扭矩'] = cycle_raw[f'刀盘扭矩-预测-{option_responsible}']  # 添加预测刀盘扭矩数据
        out_data['刀盘推力'] = cycle_raw['刀盘推力-当前']  # 添加刀盘推力数据
        out_data['预测刀盘推力'] = cycle_raw[f'刀盘推力-预测-{option_responsible}']  # 添加预测刀盘推力数据
        out_data['刀盘贯入度'] = cycle_raw['刀盘贯入度-当前']  # 添加刀盘贯入度数据
        out_data['刀盘转速-容许'] = cycle_raw['刀盘转速-容许']  # 添加刀盘转速-容许数据
        out_data['刀盘转速-脱困'] = cycle_raw['刀盘转速-脱困']  # 添加刀盘转速-脱困数据
        out_data['推进速度-容许'] = cycle_raw['推进速度-容许']  # 添加推进速度-容许数据
        out_data['推进速度-脱困'] = cycle_raw['推进速度-脱困']  # 添加推进速度-脱困数据
        out_data['刀盘扭矩-容许'] = cycle_raw['刀盘扭矩-容许']  # 添加刀盘扭矩-容许数据
        out_data['刀盘扭矩-脱困'] = cycle_raw['刀盘扭矩-脱困']  # 添加刀盘扭矩-脱困数据
        out_data['刀盘推力-容许'] = cycle_raw['刀盘推力-容许']  # 添加刀盘推力-容许数据
        out_data['刀盘推力-脱困'] = cycle_raw['刀盘推力-脱困']  # 添加刀盘推力-脱困数据
        out_data['刀盘贯入度-容许'] = cycle_raw['刀盘贯入度-容许']  # 添加刀盘贯入度-容许数据
        out_data['刀盘贯入度-脱困'] = cycle_raw['刀盘贯入度-脱困']  # 添加刀盘贯入度-脱困数据
        out_data = out_data.replace('--', 0)  # 将数据中的‘--’替换为0
        out_data = out_data.reset_index(drop=True)
        # >>>>>>>>>>>>>>>>>>>> 获取参数统计值 <<<<<<<<<<<<<<<<<<<<<<<<<<
        Rotate = cycle['刀盘转速-当前'].mean()  # 当前循环段刀盘转速
        Rate = cycle['推进速度-当前'].mean()  # 当前循环段推进速度
        Rate_set = cycle['推进速度设定值-当前'].mean()  # 当前循环段推进速度设定值
        Torque = cycle['刀盘扭矩-当前'].mean()  # 当前循环段刀盘扭矩
        Trust = cycle['刀盘推力-当前'].mean()  # 当前循环段刀盘推力
        Penetration = cycle['刀盘贯入度-当前'].mean()  # 当前循环段刀盘贯入度
        option_control = cycle['控制参数推荐-use'].value_counts().idxmax()  # 控制参数推荐所使用的算法
        Recommend_Torque = cycle[f'刀盘扭矩最大值-{option_control}'].mean()  # 当前循环段刀盘扭矩预测值
        Recommend_Trust = cycle[f'刀盘推力最大值-{option_control}'].mean()  # 当前循环段刀盘推力预测值
        Recommend_Rate = cycle[f'推荐推进速度-{option_control}'].mean() / 0.58  # 当前循环段推进速度预测值
        Recommend_Rotate = cycle[f'推荐刀盘转速-{option_control}'].mean()  # 当前循环段刀盘转速推荐值
        Recommend_Rate_percent = cycle[f'推荐推进速度-{option_control}'].mean()  # 当前循环段刀推进速度荐值
        Recommend_Penetration = (Recommend_Rate / Recommend_Rotate) if Recommend_Rotate > 0 else 0.0  # 当前循环段刀盘贯入度预测值
        pic_path = os.path.join(self._picture_path, os.path.splitext(os.path.basename(path))[0])
        muck_pic = ['', '']
        if os.path.exists(pic_path):
            pic_sizes = [(pic, os.path.getctime(os.path.join(pic_path, pic))) for pic in os.listdir(pic_path)]
            sorted_pics = sorted(pic_sizes, key=lambda x: x[1], reverse=True)
            for index, pic in enumerate(zip(muck_pic, sorted_pics)):
                muck_pic[index] = os.path.join(pic_path, pic[1][0])
        dict_out = {'起始桩号': Stake_start, '结束桩号': Stake_end, '掘进长度': Length, '掘进时间': Time, '起始时间': Time_start,
                    '结束时间': Time_end, '环号': '', '班组': group, '刀盘转速-实际': Rotate, '速度设定-实际': Rate_set,
                    '推进速度-实际': Rate, '刀盘推力-实际': Trust, '刀盘扭矩-实际': Torque, '刀盘贯入度-实际': Penetration,
                    '刀盘转速-建议': Recommend_Rotate, '速度设定-建议': Recommend_Rate_percent, '推进速度-建议': Recommend_Rate,
                    '刀盘推力-建议': Recommend_Trust, '刀盘扭矩-建议': Recommend_Torque, '刀盘贯入度-建议': Recommend_Penetration,
                    '预测围岩分类': Predict_rock, '风险掘进提示': Risk_state, '支护建议': Support_method, '塌方概率': Collapse,
                    '刀盘扭矩-容许': T_admit, '刀盘扭矩-脱困': T_max, '刀盘推力-容许': F_admit, '刀盘推力-脱困': F_max,
                    '推进速度-容许': V_admit, '推进速度-脱困': V_max, '刀盘转速-容许': N_admit, '刀盘转速-脱困': N_max,
                    '刀盘贯入度-容许': P_admit, '刀盘贯入度-脱困': P_max, '渣片信息1': muck_pic[0], '渣片信息2': muck_pic[1],
                    'data': copy.deepcopy(out_data)}
        return dict_out
