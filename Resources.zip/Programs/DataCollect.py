#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.1                                                      *
# * Date:  2024-11-23 20:33:50                                           *
# * Last  update: 2024-08-28 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import csv
import threading
import time
import traceback
import warnings
import os
import sys
import pickle
import socket
import pandas as pd
import psutil
from colorama import init
from datetime import datetime

warnings.filterwarnings("ignore")
init(autoreset=True)
#  程序说明部分
if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.abspath(sys.argv[0]))


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class SharedVariable(object):
    """创建共享变量并进行变量存储"""

    def __init__(self):
        """初始化存储变量"""
        global BASE_PATH
        self.log_path = os.path.join(BASE_PATH, 'Log')
        self.values = {}  # 待存储数据的变量
        self.objects = {}  # 待存储项目的变量
        self.lock = threading.Lock()  # 线程锁

    def log(self, message):
        with self.lock:  # 线程锁，确保线程安全地更新共享变量
            if not os.path.exists(self.log_path):
                os.makedirs(self.log_path)  # 创建相关文件夹
            current_date = datetime.now().strftime("%Y-%m-%d")  # 获取当前日期
            # 以追加模式打开文件并写入错误信息
            with open(os.path.join(self.log_path, f"{current_date} Background.log"), "a", encoding='utf-8') as file:
                file.write(f"=================== {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===================\n"
                           f"{message}\n\n")

    def get(self, key: str = 'all'):
        """
        获取变量内容，若指定key，则只获取指定变量内容，若不指定key，则获取整个变量内容
        :param key: 要获取的键
        :return: 要获取的键的值
        """
        if not isinstance(key, str):  # 检查key是否为str类型
            raise ValueError('input is not of type < str >')  # 若key不为str类型，则抛出错误
        else:  # 检查key是否为str类型
            if key == 'all':  # 若不指定key，则获取整个变量内容
                return self.values  # 返回整个变量内容
            else:  # 若指定key，则获取指定变量内容
                if key in list(self.values.keys()):  # 检查key是否在dict中
                    return self.values[key]  # 返回指定变量内容
                elif key in list(self.objects.keys()):  # 检查key是否在dict中
                    return self.objects[key]  # 返回指定变量内容
                else:  # 检查key是否在dict中
                    raise ValueError(f'the key does not contain < {key} >')  # 若key不在dict中，则抛出错误

    def set(self, value: dict, dtype: str = 'normal'):
        """
        添加或修改变量内容
        :param value: 要添加的变量，例如 {key: values}
        :param dtype: values的类型（str、int、float、bool）
        """
        with self.lock:  # 线程锁，确保线程安全地更新共享变量
            if dtype == 'str':  # 字符型
                self.values.update({k: str(v) for k, v in value.items()})  # 添加新数据，并改value成为字符型str
            elif dtype == 'int':  # 整型
                self.values.update({k: int(v) for k, v in value.items()})  # 添加新数据，并改value成为整型int
            elif dtype == 'float':  # 实型
                self.values.update({k: float(v) for k, v in value.items()})  # 添加新数据，并改value成为实型float
            elif dtype == 'bool':  # 布尔型
                self.values.update({k: bool(v) for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'dataframe':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'list':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'dict':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'normal':  # 默认，即系统自动判断
                warnings.warn("tpye not specified", Warning)  # 抛出警告，未指定变量类型
                self.values.update({k: v for k, v in value.items()})  # 添加新数据，并改value类型
            else:  # 不支持指定类型或指定类型错误
                raise KeyError(f'type < {dtype} > is not support')  # 抛出异常，指定类型不支持

    def clear(self, key: str = 'all'):
        """
        清除变量内容，若指定key，则只清除指定变量内容，若不指定key，则清除整个变量内容
        :param key: 要清除的键
        """
        with self.lock:  # 线程锁，确保线程安全地更新共享变量
            if not isinstance(key, str):  # 检查key是否为str类型
                raise ValueError('input is not of type < str >')  # 若key不为str类型，则抛出错误
            else:  # 检查key是否为str类型
                if key == 'all':  # 若不指定key，则清除整个变量内容
                    self.values.clear()  # 清除整个变量
                    self.objects.clear()  # 清除整个变量
                else:  # 若指定key，则清除指定变量内容
                    if key in copy.copy(list(self.values.keys())):  # 检查key是否在dict中
                        del self.values[key]  # 清除指定变量内容
                    elif key in copy.copy(list(self.objects.keys())):  # 检查key是否在dict中
                        del self.objects[key]  # 清除指定变量内容
                    else:  # 检查key是否在dict中
                        raise ValueError(f'the key does not contain < {key} >')  # 若key不在dict中，则抛出错误


class DataCollect(object):

    def __init__(self):
        global BASE_PATH
        self._shared_var = SharedVariable()  # 实例化共享变量库
        self._is_running = True  # 程序是否运行
        self.assist_drive = False
        self._base_path = BASE_PATH  # 获取根目录路径
        self.programs = []
        self.threads = []  # 存储即将运行的线程句柄
        self._temp_path = self._creative_folder_(os.path.join(self._base_path, 'temp'))  # 临时文件夹路径

    def __str__(self):
        """程序说明信息"""
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self):
        self._default_var_()
        self._shared_var.set(value={'real-data': pd.DataFrame()}, dtype='dataframe')
        self._shared_var.set(value={'key-data': pd.DataFrame()}, dtype='dataframe')
        self._shared_var.set(value={'rock-index': pd.DataFrame()}, dtype='dataframe')
        self._shared_var.set(value={'passed-data':[]}, dtype='list')
        threading.Thread(target=self.monitor_performance).start()  # 启动界面数据发送模块
        while True:
            self._start_thread_()  # 启动子线程
            try:
                self.main()
            except BaseException as e:
                self._shared_var.log(message=traceback.format_exc())
                print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                      f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
            finally:
                time.sleep(60)

    def main(self):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建服务器套接字
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 设置重用地址选项，允许端口复用
        server_socket.bind(('localhost', 8888))  # 绑定IP地址和端口
        server_socket.listen(1)  # 监听连接
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
              f'[Info] Wait for connection...\033[0m')
        while True:
            client_socket, address = server_socket.accept()  # 接受客户端连接
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
                  f'[Info] Connection successful, port: {address}!!!\033[0m')
            # noinspection PyBroadException
            try:
                while True:
                    request = client_socket.recv(1024).decode()  # 接收客户端请求
                    if request == 'get_variable':
                        real_display = self._shared_var.get().copy()
                        real_display["渣土级配曲线"] = self._shared_var.get(key="渣土级配曲线")
                        client_socket.send(pickle.dumps(real_display))
                    elif request == 'assist_drive':
                        self.assist_drive = False if self.assist_drive else True
                        self._shared_var.set(value={'辅助掘进': self.assist_drive}, dtype='bool')
                    elif request == 'apply_setting':
                        threading.Thread(target=self._apply_setting_).start()  # 启动界面数据发送模块
                    else:
                        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                              f'{self.__class__.__name__} -> [Info] Connection closed !!!\033[0m')
                        break
            except Exception:
                self._shared_var.log(message=traceback.format_exc())
                print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
                      f'[Error] The client has a problem, please try again later !!!\033[0m')
            finally:
                client_socket.close()  # 关闭客户端连接

    def set_program(self, programs):
        """"""
        self.programs = programs

    def monitor_performance(self):
        while True:
            try:
                pid = os.getpid()
                process = psutil.Process(pid)  # 获取进程对象
                index_path = self._creative_folder_(os.path.join(self._base_path, 'Log'))
                while True:
                    now = datetime.now()
                    info = {"Timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
                            'thread-count': process.num_threads(),
                            "CPU_Usage(%)": process.cpu_percent(interval=1),
                            "Memory_Usage(MB)": process.memory_info().rss / (1024 * 1024)}
                    current_date = now.strftime("%Y-%m-%d")
                    index_path_file = os.path.join(index_path, f'{current_date} Monitor.csv')
                    with open(index_path_file, 'a', newline='') as csv_file:
                        writer = csv.writer(csv_file)  # 实例化写入数据功能
                        if os.stat(index_path_file).st_size == 0:  # 如果csv文件是空的，写入列名
                            writer_header = csv.DictWriter(csv_file, fieldnames=list(info.keys()))
                            writer_header.writeheader()
                        writer.writerow(info.values())
                    time.sleep(60)
            except Exception as e:
                self._shared_var.log(message=traceback.format_exc())
                print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                      f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
            finally:
                time.sleep(60)

    @staticmethod
    def _creative_folder_(path):
        """创建文件夹"""
        if not os.path.exists(path):
            os.makedirs(path)  # 创建相关文件夹
        return path

    def _default_var_(self):
        variable = {'日期': '2008-08-08 12:12:12', '里程': 0.0, '辅助掘进': False, '计数时间戳': -1,  '数据获取方式': '--',
                    '刀盘转速-容许': 1.0, '推进速度-容许': 1.0, '刀盘扭矩-容许': 1.0, '刀盘推力-容许': 1.0, '刀盘贯入度-容许': 1.0,
                    '刀盘转速-脱困': 1, '推进速度-脱困': 1.0, '刀盘扭矩-脱困': 1.0, '刀盘推力-脱困': 1.0, '刀盘贯入度-脱困': 1.0,
                    '施工状态': '停机中', 'PLC状态': False, '班组': '--', '刀盘转速-当前': 0.0, '推进速度-当前': 0.0,
                    '刀盘扭矩-当前': 0.0, '刀盘推力-当前': 0.0, '刀盘贯入度-当前': 0.0, '推进位移-当前': 0.0,
                    '刀盘转速设定值-当前': 0.0, '推进速度设定值-当前': 0.0, '掘进比能-当前': 0.0, '刀盘转速-之前': 0.0,
                    '推进速度-之前': 0.0, '刀盘扭矩-之前': 0.0, '刀盘推力-之前': 0.0, '刀盘贯入度-之前': 0.0, 'PLC超时计数': 0,
                    '刀盘转速-预测': 0.0, '推进速度-预测': 0.0, '刀盘贯入度-预测': 0.0, '刀盘扭矩-预测': 0.0, '刀盘推力-预测': 0.0,
                    '刀盘扭矩最大值-预测': 0.0, '刀盘推力最大值-预测': 0.0, '推荐刀盘转速-经济': 0.0, '推荐推进速度-经济': 0.0,
                    '推荐刀盘转速-均衡': 0.0, '推荐推进速度-均衡': 0.0, '推荐刀盘转速-高效': 0.0, '推荐推进速度-高效': 0.0,
                    '渣片系统状态': '连接失败', '渣土系统资源': '', '渣土大块异常': '否', '出渣体积异常': '否', '最大粒径': 0.0,
                    '全尺寸系数': 0.0, '均匀系数': 0.0, '曲线系数': 0.0, '推荐加水量': 0.0, '泡沫混合液流量': 0.0,
                    'TPI-平均': 0.0, 'FPIa-平均': 0.0, 'FPIb-平均': 0.0, '预测围岩类别（二分类）': '--', 'Ⅱ类Ⅲ类围岩概率': 0.0,
                    'Ⅳ类Ⅴ类围岩概率': 0.0, '预测围岩类别（四分类）': '--', 'Ⅰ类围岩概率': 0.0, 'Ⅱ类围岩概率': 0.0,
                    'Ⅲ类围岩概率': 0.0, 'Ⅳ类围岩概率': 0.0, 'Ⅴ类围岩概率': 0.0, '岩性': '--', '岩体抗压强度': 0.0,
                    '岩体完整系数': 0.0, '预测塌方风险': '低', '预测塌方概率': 0.0, '预测卡机风险': '低', '预测卡机概率': 0.0,
                    '锚杆型号': '--', '锚杆长度': '--', '锚杆环向间距': '--', '锚杆纵向间距': '--', '布设范围': '--',
                    '拱架型号': '--', '拱架间距': '--', '钢筋网型号': '--', '钢筋网范围': '--', '喷混凝土强度': '--',
                    '喷混凝土厚度': '--', '衬砌强度': '--', '衬砌厚度': '--', '风险状态': '安全掘进', '建议支护方式': '--'}
        for local in ['顶护盾', '刀盘']:
            for direct in ['X方向', 'Y方向', 'Z方向']:
                variable.update({f'{local}-{direct}-系统状态': False, f'{local}-{direct}-时域': 0.0,
                                 f'{local}-{direct}-频域': 0.0, f'{local}-{direct}-均方幅值': 0.0,
                                 f'{local}-{direct}-峰值': 0.0, f'{local}-{direct}-有效值': 0.0,
                                 f'{local}-{direct}-峰峰值': 0.0, f'{local}-{direct}-裕度指标': 0.0,
                                 f'{local}-{direct}-歪度指标': 0.0, f'{local}-{direct}-峭度指标': 0.0,
                                 f'{local}-{direct}-分析结果': '暂无信息!'})
        for key, value in variable.items():
            self._shared_var.set({key: value})

    def _start_thread_(self) -> None:
        """创建多个线程，并启动多线程"""
        self.threads = [None for _ in range(len(self.programs))]  # 存储即将运行的线程句柄
        for index, (thread, fuc) in enumerate(zip(self.threads, self.programs)):  # 添加子线程至dict中
            if thread is None or not thread.is_alive():
                thread = fuc(self._shared_var)
                thread.start()  # 启动子线程
                self.threads[index] = thread
                time.sleep(1)
        if self.threads.count(None) == len(self.programs):
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] No program has been started, please go to < config.ini > and open module !!!\033[0m')

    def _apply_setting_(self):
        for thread in self.threads:
            if thread is not None:
                thread.update()
