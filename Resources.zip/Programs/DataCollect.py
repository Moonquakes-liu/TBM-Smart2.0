#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.0                                                      *
# * Date:  2024-09-03 16:06:54                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import threading
import time
import warnings
import os
import io
import sys
import pickle
import socket
import subprocess
import configparser
import pandas as pd
import numpy as np
from WrapperTools import suppress_errors, retry
from colorama import init
from datetime import datetime
from DataPreProcess import DataPreProcess
from DataSave import DataSave
from DataSend import DataSend
from SoilImageAcquisition import SoilImageAcquisition
from HobWearRate import HobWearRate
from SoilConditionAnalysis import SoilConditionAnalysis
from RockMassPredict import RockMassPredict
from ControlParmRecommend import ControlParmRecommend
from ResponseParmPredict import ResponseParmPredict

warnings.filterwarnings("ignore")
init(autoreset=True)
#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于数据收集
说明：无

===================================================================================
     """


class SharedVariable(object):
    """创建共享变量并进行变量存储"""

    def __init__(self):
        """初始化存储变量"""
        self.values = {}  # 待存储数据的变量
        self.objects = {}  # 待存储项目的变量
        self.lock = threading.Lock()  # 线程锁

    def get(self, key: str = 'all'):
        """
        获取变量内容，若指定key，则只获取指定变量内容，若不指定key，则获取整个变量内容
        :param key: 要获取的键
        :return: 要获取的键的值
        """
        if not isinstance(key, str):  # 检查key是否为str类型
            raise ValueError('input is not of type < str >')  # 若key不为str类型，则抛出错误
        else:  # 检查key是否为str类型
            if key == 'all':  # 若不指定key，则获取整个变量内容
                return copy.deepcopy(self.values)  # 返回整个变量内容
            else:  # 若指定key，则获取指定变量内容
                if key in copy.deepcopy(list(self.values.keys())):  # 检查key是否在dict中
                    return copy.deepcopy(self.values[key])  # 返回指定变量内容
                elif key in copy.deepcopy(list(self.objects.keys())):  # 检查key是否在dict中
                    return copy.deepcopy(self.objects[key])  # 返回指定变量内容
                else:  # 检查key是否在dict中
                    raise ValueError(f'the key does not contain < {key} >')  # 若key不在dict中，则抛出错误

    def set(self, value: dict, dtype: str = 'normal'):
        """
        添加或修改变量内容
        :param value: 要添加的变量，例如 {key: values}
        :param dtype: values的类型（str、int、float、bool）
        """
        with self.lock:  # 线程锁，确保线程安全地更新共享变量
            if dtype == 'str':  # 字符型
                self.values.update({k: str(v) for k, v in value.items()})  # 添加新数据，并改value成为字符型str
            elif dtype == 'int':  # 整型
                self.values.update({k: int(v) for k, v in value.items()})  # 添加新数据，并改value成为整型int
            elif dtype == 'float':  # 实型
                self.values.update({k: float(v) for k, v in value.items()})  # 添加新数据，并改value成为实型float
            elif dtype == 'bool':  # 布尔型
                self.values.update({k: bool(v) for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'dataframe':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'list':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'dict':  # 布尔型
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value成为布尔型bool
            elif dtype == 'bytes':  # 项目
                self.objects.update({k: v for k, v in value.items()})  # 添加新数据，并改value类型
            elif dtype == 'normal':  # 默认，即系统自动判断
                warnings.warn("tpye not specified", Warning)  # 抛出警告，未指定变量类型
                self.values.update({k: v for k, v in value.items()})  # 添加新数据，并改value类型
            else:  # 不支持指定类型或指定类型错误
                raise KeyError(f'type < {dtype} > is not support')  # 抛出异常，指定类型不支持

    def getBytes(self, key: str = 'all'):
        if key in copy.deepcopy(list(self.objects.keys())):  # 检查key是否在dict中
            return copy.deepcopy(self.objects[key])  # 返回指定变量内容
        else:  # 检查key是否在dict中
            raise ValueError(f'the key does not contain < {key} >')  # 若key不在dict中，则抛出错误

    def clear(self, key: str = 'all'):
        """
        清除变量内容，若指定key，则只清除指定变量内容，若不指定key，则清除整个变量内容
        :param key: 要清除的键
        """
        with self.lock:  # 线程锁，确保线程安全地更新共享变量
            if not isinstance(key, str):  # 检查key是否为str类型
                raise ValueError('input is not of type < str >')  # 若key不为str类型，则抛出错误
            else:  # 检查key是否为str类型
                if key == 'all':  # 若不指定key，则清除整个变量内容
                    self.values.clear()  # 清除整个变量
                    self.objects.clear()  # 清除整个变量
                else:  # 若指定key，则清除指定变量内容
                    if key in copy.deepcopy(list(self.values.keys())):  # 检查key是否在dict中
                        del self.values[key]  # 清除指定变量内容
                    elif key in copy.deepcopy(list(self.objects.keys())):  # 检查key是否在dict中
                        del self.objects[key]  # 清除指定变量内容
                    else:  # 检查key是否在dict中
                        raise ValueError(f'the key does not contain < {key} >')  # 若key不在dict中，则抛出错误


class DataCollect(object):
    programs = [DataPreProcess, DataSave, DataSend, SoilImageAcquisition, HobWearRate,
                SoilConditionAnalysis, RockMassPredict, ControlParmRecommend, ResponseParmPredict]
    threads = [None for _ in range(len(programs))]  # 存储即将运行的线程句柄

    def __init__(self):
        self._shared_var = SharedVariable()  # 实例化共享变量库
        self._is_running = True  # 程序是否运行
        self._base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取根目录路径
        self._temp_path = os.path.join(self._base_path, 'temp')  # 临时文件夹路径
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.timeout = 30  # 执行时间间隔
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self):
        self._creative_dir_()  # 创建相关文件夹
        self._shared_var.set(value={'real-data': pd.DataFrame()}, dtype='dataframe')
        Dict = self._default_var_()
        for key in Dict.keys():
            self._shared_var.set({key: Dict[key]})
        threading.Thread(target=self.backend_port).start()  # 启动界面数据发送模块
        self.StartWindows()  # 启动TBM Smart界面
        while True:
            if self._shared_var.get(key='计数时间戳') == -1:
                self.StartThread()  # 启动子线程
            time.sleep(60)

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.timeout = config.getint('Windows', 'timeout')  # 执行时间间隔
            self._is_running = config.getboolean('Windows', 'run')  # 程序是否执行

    def _creative_dir_(self) -> None:
        """创建文件夹"""
        # >>>>>>>>>>>>>>>>>> 创建临时文件夹 <<<<<<<<<<<<<<<<<<<<<<<
        if not os.path.exists(self._temp_path):  # 判断文件夹是否存在
            os.mkdir(self._temp_path)  # 创建相关文件夹
        # >>>>>>>>>>>>>>>>>> 创建临时文件夹 <<<<<<<<<<<<<<<<<<<<<<<

    @staticmethod  # 不强制要求传递参数
    def _default_var_():
        variable = {'施工状态': '停机中', '计数时间戳': -1, '刀盘转速-容许': 12, '推进速度-容许': 120,
                    '刀盘扭矩-容许': 3000, '刀盘推力-容许': 15000, '刀盘贯入度-容许': 20, '刀盘转速-脱困': 15, '推进速度-脱困': 150,
                    '刀盘扭矩-脱困': 4000, '刀盘推力-脱困': 20000, '刀盘贯入度-脱困': 25, '滚刀磨损速率-function1': '--',
                    '滚刀磨损速率-function2': '--', '滚刀磨损速率-use': 'function1', '滚刀磨损速率-timeout': 60,
                    '渣土状况分析-function1': '--', '渣土状况分析-function2': '--', '渣土状况分析-use': 'function1',
                    '渣土状况分析-timeout': 60, '当前围岩类型(二分类)-function1': '--', 'Ⅱ类Ⅲ类围岩概率-function1': 0,
                    'Ⅳ类Ⅴ类围岩概率-function1': 0, '当前围岩类型(四分类)-function1': '--', 'Ⅰ类围岩概率-function1': 0,
                    'Ⅱ类围岩概率-function1': 0, 'Ⅲ类围岩概率-function1': 0, 'Ⅳ类围岩概率-function1': 0, 'Ⅴ类围岩概率-function1': 0,
                    '建议支护方式-function1': '--', '风险状态-function1': '--', '软弱破碎概率-function1': 0.0,
                    '当前围岩类型(二分类)-function2': '--', 'Ⅱ类Ⅲ类围岩概率-function2': 0, 'Ⅳ类Ⅴ类围岩概率-function2': 0,
                    '当前围岩类型(四分类)-function2': '--', 'Ⅰ类围岩概率-function2': 0, 'Ⅱ类围岩概率-function2': 0,
                    'Ⅲ类围岩概率-function2': 0, 'Ⅳ类围岩概率-function2': 0, 'Ⅴ类围岩概率-function2': 0, '建议支护方式-function2': '--',
                    '风险状态-function2': '--', '软弱破碎概率-function2': 0.0, '岩体破碎概率预测-use': 'function1',
                    '岩体破碎概率预测-timeout': 60, '推荐刀盘转速-function1': 0, '推荐推进速度-function1': 0, '刀盘转速-预测-function1': 0.0,
                    '推进速度-预测-function1': 0.0, '刀盘贯入度-预测-function1': 0.0, '推荐刀盘转速-function2': 0, '推荐推进速度-function2': 0,
                    '刀盘转速-预测-function2': 0.0, '推进速度-预测-function2': 0.0, '刀盘贯入度-预测-function2': 0.0,
                    '控制参数推荐-use': 'function1', '控制参数推荐-timeout': 3, '刀盘扭矩-预测-function1': 0.0, '刀盘推力-预测-function1': 0.0,
                    '刀盘扭矩-预测-function2': 0.0, '刀盘推力-预测-function2': 0.0, '刀盘扭矩-预测-function3': 0.0,
                    '刀盘推力-预测-function3': 0.0, '响应参数预测-use': 'function2', '响应参数预测-timeout': 3, '数据获取方式': 'YC',
                    'PLC状态': True, '运行时间': '2023-06-29 00:00:02', '里程': 0.0, '刀盘转速-当前': 0.0, '推进速度-当前': 0.0,
                    '刀盘扭矩-当前': 0.0, '刀盘推力-当前': 0.0, '刀盘贯入度-当前': 0.0, '刀盘转速-之前': 0.0, '推进速度-之前': 0.0,
                    '刀盘扭矩-之前': 0.0, '刀盘推力-之前': 0.0, '刀盘贯入度-之前': 0.0, '推进位移-当前': 0.0, '刀盘转速设定值-当前': 0.0,
                    '推进速度设定值-当前': 0.0, 'TPI-平均': 0.0, 'FPIa-平均': 0.0, 'FPIb-平均': 0.0, 'PLC超时计数': 0,
                    '渣土图片信息-timeout': 60, '渣土图片信息': None, '渣片系统状态': '连接失败',
                    '刀盘扭矩最大值-function1': 0.0, '刀盘推力最大值-function1': 0.0}
        return variable

    def StartThread(self) -> None:
        """创建多个线程，并启动多线程"""
        for index, (thread, fuc) in enumerate(zip(self.threads, self.programs)):  # 添加子线程至dict中
            if thread is None or not thread.is_alive():
                thread = fuc(self._shared_var)
                thread.start()  # 启动子线程
                self.threads[index] = thread
        if self.threads.count(None) == len(self.programs):
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] No program has been started, please go to < config.ini > and open module !!!\033[0m')

    def StartWindows(self) -> None:
        if self._is_running:
            time.sleep(self.timeout)
            subprocess.Popen(os.path.join(self._base_path, 'TBM-Smart2.0-windows.bat'), shell=True)

    @suppress_errors  # 处理异常并继续执行
    def backend_port(self):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建服务器套接字
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 设置重用地址选项，允许端口复用
        server_socket.bind(('localhost', 8888))  # 绑定IP地址和端口
        server_socket.listen(1)  # 监听连接
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
              f'[Info] Wait for connection...\033[0m')
        while True:
            client_socket, address = server_socket.accept()  # 接受客户端连接
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
                  f'[Info] Connection successful, port: {address}!!!\033[0m')
            # noinspection PyBroadException
            try:
                while True:
                    request = client_socket.recv(1024).decode()  # 接收客户端请求
                    if request == 'get_variable':
                        real_display = self._shared_var.get()
                        if '渣土图片信息' in real_display.keys():
                            del real_display['渣土图片信息']
                        real_display['渣土图片路径-在线'] = os.path.join(self._temp_path, 'temp.jpg')
                        real_display['渣土图片路径-本地'] = os.path.join(self._base_path, 'pictures')
                        real_display['界面历史信息'] = os.path.join(self._temp_path, 'history-data')
                        real_display.update({'预测塌方概率': np.random.random(), '预测卡机概率': np.random.random(),
                                             '预测围岩类别': "Ⅳ", '顶护盾-X方向-时域': np.random.randint(-15, 15)/10,
                                             '顶护盾-X方向-频域': np.random.randint(-15, 15)/10, '顶护盾-X方向-系统状态': True,
                                             '渣片系统状态': '连接成功', '推荐加水量': np.random.randint(0, 500)})
                        client_socket.send(pickle.dumps(real_display))
                    else:
                        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                              f'{self.__class__.__name__} -> [Info] Connection closed !!!\033[0m')
                        break
            except Exception:
                print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} -> '
                      f'[Error] The client has a problem, please try again later !!!\033[0m')
            finally:
                client_socket.close()  # 关闭客户端连接


if __name__ == '__main__':
    DataCollect().run()
