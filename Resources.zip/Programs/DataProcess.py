#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Smart Windows                                         *
# * Version:  2.0.1                                                      *
# * Date:  2024-11-23 20:33:50                                           *
# * Last  update: 2024-08-28 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1rRajVg5Ex06q4ouDKpZSGw  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************
import gc
import time
import json
import os
import sys
import copy
import joblib
import threading
import traceback
import configparser
import numpy as np
import urllib.request
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from sklearn.neighbors import KernelDensity


if getattr(sys, 'frozen', False):
    BASE_PATH = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
else:
    BASE_PATH = os.path.dirname(os.path.abspath(sys.argv[0]))


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator


class DataAcquire(object):
    """
    读入数据源，转化成程序内部通用的DataFrame数据结果，读取频率为1Hz
    ->引松工程存储的原始数据作为程序输入(开发及测试阶段)；
    ->引绰工程存储的原始数据作为程序输入(开发及测试阶段)；
    ->模拟PLC实时数据流作为程序输入(测试阶段)；
    ->收现场实时PLC数据流作为程序输入(应用阶段)；
    """

    def __init__(self):
        """初始化各参量"""
        global BASE_PATH
        self._base_path = BASE_PATH  # 获取根目录路径
        self.Key = {}  # 对获取到的实际数据流进行解码

    def __set_key__(self, key):
        """设置关键数据"""
        self.Key = key

    def run(self, URL, acquire_mode='S-PLC') -> [DataFrame, bool]:
        """
        选择原始数据获取方式
        :return: 每秒数据（per_data）, PLC状态（True/False）
        """
        if acquire_mode == 'S-PLC':  # 模拟PLC实时数据流作为程序输入
            return self.Read_Simulate_PLC_Data(URL)  # 返回每秒数据，请勿修改，数据格式为 DataFrame
        elif acquire_mode == 'P-PLC':  # 接收现场实时PLC数据流作为程序输入
            return self.Read_Practical_PLC_Data(URL)  # 返回每秒数据，请勿修改，数据格式为 DataFrame
        else:
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Error] Option < {self.acquire_mode} > does not exist !!!\033[0m')  # 输出相关提示信息
            return DataFrame(), False

    def Read_Simulate_PLC_Data(self, URL) -> [DataFrame, bool]:
        """
        读取模拟PLC实时数据流
        :return: 每秒数据（per_data）, PLC状态（True/False）
        """
        # noinspection PyBroadException
        try:
            html = urllib.request.urlopen(URL, timeout=0.5)  # 向指定的URL发送一个HTTP(S)请求，并获取响应结果
            data = json.loads(html.read())  # json格式数据解析，结果为dict格式
            per_data = pd.DataFrame(data)  # 将dict转化为DataFrame格式
            per_data.rename(columns=self.Key, inplace=True)  # 对列名进行标准化，即重新修改列名
            out_data = per_data.iloc[[0]].reset_index(drop=True)
            out_data['日期'] = pd.to_datetime(out_data['日期'])
            return out_data, True  # 返回每秒数据（per_data）和PLC状态（True）
        except Exception:  # 若HTTP(S)请求失败
            return DataFrame(), False  # 返回每秒数据（per_data）和PLC状态（False）

    def Read_Practical_PLC_Data(self, URL) -> [DataFrame, bool]:
        """
        读取现场实际PLC实时数据流
        :return: 每秒数据（per_data）, PLC状态（True/False）
        """
        # noinspection PyBroadException
        try:
            html = urllib.request.urlopen(URL, timeout=0.5)  # 向指定的URL发送一个HTTP(S)请求，并获取响应结果
            data = json.loads(html.read())  # json格式数据解析，结果为dict格式
            per_data = pd.DataFrame([data["items"]])  # 将dict转化为DataFrame格式
            per_data["time_str"] = data["time_str"]  # 向DataFrame内添加时间戳
            per_data = per_data[self.Key.keys()]  # 提取出Key_Practical中涉及到的参数
            per_data.rename(columns=self.Key, inplace=True)  # 对列名进行标准化，即重新修改列名
            out_data = per_data.iloc[[0]].reset_index(drop=True)
            out_data['日期'] = pd.to_datetime(out_data['日期'])
            return out_data, True  # 返回每秒数据（per_data）和PLC状态（True）
        except Exception:  # 若HTTP(S)请求失败
            return DataFrame(), False  # 返回每秒数据（per_data）和PLC状态（False）


class DataProcess(threading.Thread):
    """数据预处理"""
    Machine_Info = {'刀盘转速-容许': 1, '推进速度-容许': 1, '刀盘扭矩-容许': 1, '刀盘推力-容许': 1, '贯入度-容许': 1,
                    '刀盘转速-脱困': 2, '推进速度-脱困': 2, '刀盘扭矩-脱困': 2, '刀盘推力-脱困': 2, '贯入度-脱困': 2}
    Rock_Index = {'TPI-mean': 0, "TPI-std": 0, "FPIa-mean": 0, "FPIa-std": 0, "FPIb-mean": 0, "FPIb-std": 0,
                  "WR-mean": 0, "WR-std": 0, "F-V-std": 0, "F-V-mean": 0, "T-V-std": 0, "T-V-mean": 0}  # 将结果放入dict中
    Key_Name = ['里程', '日期', '刀盘转速', '刀盘转速设定值', '推进速度', '推进速度设定值',
                '刀盘推力', '刀盘扭矩', '刀盘贯入度', '推进位移']  # 待提取的关键数据列

    def __init__(self, _shared_var):
        """
        初始化各参量，请勿修改
        :param _shared_var: 共享变量
        """
        global BASE_PATH
        super(DataProcess, self).__init__()  # 调用父类（或超类）的构造函数
        self._is_running = True  # 程序是否运行
        self._stop_event = threading.Event()  # 用于同步线程之间的事件
        self._shared_var = _shared_var  # 引入共享，使其变为可编辑状态
        self._base_path = BASE_PATH  # 获取根目录路径
        self.data_acquire_module = DataAcquire()  # 实例化数据获取模块
        self.machine_information = self.Machine_Info
        self.keyname_information = self.Key_Name
        self.data_acquire_mode = 'S-PLC'
        self.acquire_URL = None
        self.stage = '停机中'  # 掘进状态
        self.time_count = -1  # 计数时间戳
        self.PLC_timeout = 0  # PLC超时计数
        self.FPI_b = None
        self.temp_data = DataFrame()  # 临时保存关键数据
        self.key_data = DataFrame()  # 保存历史循环段数据
        self.history_data = _shared_var.get(key='passed-data')  # 保存历史循环段数据
        self._get_config_()

    def __str__(self):
        """程序说明信息"""
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    @retry(max_attempts=5, delay=30)  # 遇到异常时重新尝试执行（重新尝试5次，时间间隔30s）
    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        self._get_information_()
        if self._is_running:
            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Info] Thread started successfully !!!\033[0m')  # 输出相关提示信息
            self._shared_var.set(value={'数据获取方式': self.data_acquire_mode}, dtype='str')  # 数据获取方式上载至共享变量
            self._shared_var.set(value={'刀盘转速-容许': self.machine_information['刀盘转速-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'推进速度-容许': self.machine_information['推进速度-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘扭矩-容许': self.machine_information['刀盘扭矩-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘推力-容许': self.machine_information['刀盘推力-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘贯入度-容许': self.machine_information['贯入度-容许']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘转速-脱困': self.machine_information['刀盘转速-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'推进速度-脱困': self.machine_information['推进速度-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘扭矩-脱困': self.machine_information['刀盘扭矩-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘推力-脱困': self.machine_information['刀盘推力-脱困']}, dtype='float')  # 上载至共享变量中
            self._shared_var.set(value={'刀盘贯入度-脱困': self.machine_information['贯入度-脱困']}, dtype='float')  # 上载至共享变量中
            while not self._stop_event.is_set():  # 若未接收到停止指令，则一直循环运行
                try:
                    self.main()  # 运行主程序
                except BaseException as e:
                    self._shared_var.log(message=traceback.format_exc())
                    print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                          f' -> [Error] function has error in: {e} !!!\033[0m')  # 提示信息
                finally:
                    time.sleep(1)  # 每次运行的时间间隔（1s）

    def stop(self) -> None:
        """线程停止运行，请勿修改"""
        self._stop_event.set()  # 通知线程停止运行
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] Thread stopped successfully !!!\033[0m')  # 输出相关提示信息

    def main(self):
        """数据获取和数据处理"""
        real_data, plc_status = self.data_acquire_module.run(URL=self.acquire_URL, acquire_mode='S-PLC')  # 调用数据获取模块, 返回实时数据（1行）、plc状态（True/False）
        construct_status = self._stage_judge_(data=real_data)  # 调用施工状态判断模块，返回施工状态（停机中、等待掘进、正在掘进）
        self._shared_var.set(value={'施工状态': construct_status}, dtype='str')  # 施工状态上载至共享变量
        self._shared_var.set(value={'real-data': real_data}, dtype='dataframe')  # 实时数据上载至共享变量
        self._shared_var.set(value={'PLC状态': plc_status}, dtype='bool')  # PLC状态上载至共享变量
        if plc_status:  # 若PLC状态为True，则运行以下代码
            real_time = real_data['日期'][0]  # 当前时刻时间戳
            start_time = real_time.replace(hour=7, minute=0, second=0, microsecond=0)  # 白班开始时间
            end_time = real_time.replace(hour=19, minute=0, second=0, microsecond=0)  # 白班结束时间
            group = "白  班" if start_time <= real_time <= end_time else "夜  班"
            self._shared_var.set(value={'班组': group}, dtype='str')  # 班组上载至共享变量
            self._shared_var.set(value={'日期': real_time}, dtype='str')  # 日期上载至共享变量
            self._shared_var.set(value={'里程': round(real_data['里程'][0], 2)}, dtype='float')  # 里程上载至共享变量
            self._shared_var.set(value={'刀盘转速-当前': round(real_data['刀盘转速'][0], 2)}, dtype='float')  # 刀盘转速上载至共享变量
            self._shared_var.set(value={'推进速度-当前': round(real_data['推进速度'][0], 2)}, dtype='float')  # 推进速度上载至共享变量
            self._shared_var.set(value={'刀盘扭矩-当前': round(real_data['刀盘扭矩'][0], 2)}, dtype='float')  # 刀盘扭矩上载至共享变量
            self._shared_var.set(value={'刀盘推力-当前': round(real_data['刀盘推力'][0], 2)}, dtype='float')  # 刀盘推力上载至共享变量
            self._shared_var.set(value={'刀盘贯入度-当前': round(real_data['刀盘贯入度'][0], 2)}, dtype='float')  # 贯入度上载至共享变量
            self._shared_var.set(value={'推进位移-当前': round(real_data['推进位移'][0], 2)}, dtype='float')  # 推进位移上载至共享变量
            self._shared_var.set(value={'刀盘转速设定值-当前': round(real_data['刀盘转速设定值'][0], 2)}, dtype='float')  # 转速设定值上载至共享变量
            self._shared_var.set(value={'推进速度设定值-当前': round(real_data['推进速度设定值'][0], 2)}, dtype='float')  # 速度设定值上载至共享变量
            Es = ((real_data['刀盘推力'][0] * real_data['刀盘贯入度'][0] * 0.001 + 2 * 3.14 * real_data['刀盘扭矩'][0]) /
                  (3.14 * 2.6 * 2.6 * real_data['刀盘贯入度'][0] * 0.001)) if real_data['刀盘贯入度'][0] > 0 else 0
            self._shared_var.set(value={'掘进比能-当前': Es}, dtype='float')  # 速度设定值上载至共享变量
            # 调用数据提取模块，返回关键掘进参数(≥30s)、历史循环段数据(≤10个)、历史循环段均值, 界面历史信息(≤10个)
            self._shared_var.set(value={'key-data': self.key_data}, dtype='dataframe')  # 关键掘进参数上载至共享变量
            self.time_count = self.time_count + 1 if construct_status == '正在掘进' else -1  # 若设备处于正在掘进状态，则运行以下代码
            self._shared_var.set(value={'计数时间戳': self.time_count}, dtype='int')  # 计数时间戳上载至共享变量
            self.PLC_timeout = 0  # PLC超时计数
        else:
            self.PLC_timeout += 1  # PLC超时计数
        self._shared_var.set(value={'PLC超时计数': self.PLC_timeout}, dtype='int')  # PLC超时计数上载至共享变量

    def update(self):
        """更新模型和应用设置"""
        self._get_config_()
        self._load_model_()

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'Setting', 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.data_acquire_modes = config.get('DataProcess', 'acquire-mode')
            self.acquire_URL = config.get('DataProcess', 'online-url')

    def _load_model_(self):
        pass
    
    def _get_information_(self):
        """"""
        folder_path_transform = os.path.join(self._base_path, 'Setting', 'transform-information.csv')
        # noinspection PyBroadException
        try:
            transform_information = pd.read_csv(folder_path_transform, encoding='gb2312')
            result_dict = dict(zip(transform_information['PLC点位(可修改)'], transform_information['对应列名(无需修改)']))
            self.data_acquire_module.__set_key__(key=result_dict)
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                  f' -> [Error] File < {os.path.basename(folder_path_transform)} > load failed, '
                  f'the module has stopped running!!!\033[0m')  # 提示信息
            sys.exit()
        folder_path_machine = os.path.join(self._base_path, 'Setting', 'machine-information.csv')
        # noinspection PyBroadException
        try:
            machine_information = pd.read_csv(folder_path_machine, encoding='gb2312')
            result_dict = {}
            for _, row in machine_information.iterrows():
                result_dict[f"{row['参数']}-容许"] = row['容许值']
                result_dict[f"{row['参数']}-脱困"] = row['脱困值']
            self.machine_information = result_dict
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                  f' -> [Error] File < {os.path.basename(folder_path_machine)} > load failed, '
                  f'the module has stopped running!!!\033[0m')  # 提示信息
            sys.exit()
        folder_path_keyname = os.path.join(self._base_path, 'Setting', 'keyname-information.csv')
        # noinspection PyBroadException
        try:
            keyname_information = pd.read_csv(folder_path_keyname, encoding='gb2312')
            self.keyname_information = keyname_information['关键破岩数据'].tolist()
        except Exception:
            self._shared_var.log(message=traceback.format_exc())
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__}'
                  f' -> [Error] File < {os.path.basename(folder_path_keyname)} > load failed, '
                  f'the module has stopped running!!!\033[0m')  # 提示信息
            sys.exit()

    def _stage_judge_(self, data: DataFrame) -> str:
        """
        掘进状态判断
        :param data: 每秒实时数据(DataFrame)
        :return: 当前状态 ('停机中', '等待掘进', '空推中', '正在掘进')
        """
        if not data.empty:
            new_data = data[self.Key_Name]  # 关键数据提取，24列
            if new_data['刀盘转速'][0] >= 0.1:
                if new_data['刀盘贯入度'][0] >= 1 and len(self.key_data) >= 30:
                    self.stage = '正在掘进'
                else:
                    self.stage = '空推中'
            else:
                self.stage = '停机中'
            self._key_data_extract_(data=new_data)  # 调用关键数据提取模块
        else:
            self.stage = '停机中'
        return self.stage  # 返回每秒机械状态，请勿修改，数据格式为 str

    def _previous_state_(self, option='get') -> None:
        """保存历史索引，便于在下次启动时继续输出"""
        folder_path = os.path.join(self._base_path, 'temp')  # 文件夹路径
        if not os.path.exists(folder_path):  # 判断文件夹是否存在
            os.mkdir(folder_path)  # 创建相关文件夹
        local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_path = os.path.join(folder_path, 'passed-data')  # 保存历史索引
        if option == 'get':  # 获取历史索引
            # noinspection PyBroadException
            try:
                self.history_data = joblib.load(save_path)['passed-data']
                passed_data_mean = self._remove_outliers_(self.history_data[-1], option='kernel').mean()
                self._shared_var.set(value={'刀盘转速-之前': round(passed_data_mean['刀盘转速'], 2)}, dtype='float')  # 刀盘转速上载
                self._shared_var.set(value={'推进速度-之前': round(passed_data_mean['推进速度'], 2)}, dtype='float')  # 推进速度上载
                self._shared_var.set(value={'刀盘扭矩-之前': round(passed_data_mean['刀盘扭矩'], 2)}, dtype='float')  # 刀盘扭矩上载
                self._shared_var.set(value={'刀盘推力-之前': round(passed_data_mean['刀盘推力'], 2)}, dtype='float')  # 刀盘推力上载
                self._shared_var.set(value={'刀盘贯入度-之前': round(passed_data_mean['刀盘贯入度'], 2)}, dtype='float')
            except Exception:
                self._shared_var.log(message=traceback.format_exc())
                print(f'\033[0;33m[{local_time}] {self.__class__.__name__} -> '
                      f'[Warning] Error getting information from < {os.path.basename(save_path)} > '
                      f', The history information will be set to empty !!!\033[0m')
        elif option == 'set':  # 设置历史索引
            _temp_passed_data = {'date': local_time, 'passed-data': self.history_data}  # 保存历史索引的文件
            joblib.dump(_temp_passed_data, save_path)  # 保存历史索引(pkl)

    def _key_data_extract_(self, data: DataFrame) -> None:
        """
        破岩数据提取
        :param data: 每秒实时数据（DataFrame格式）
        """
        if self.stage in ['正在掘进', '空推中']:  # 若设备处于正在掘进状态和空推状态时运行以下数据
            self.temp_data = pd.concat([self.temp_data, data], ignore_index=True, axis=0)  # 开始保存数据（拼接）
            temp_data_len = len(self.temp_data)
            if temp_data_len >= 30:
                if temp_data_len % 10 == 0:
                    self.key_data = self._remove_outliers_(copy.copy(self.temp_data), option='3sigma')
                    self._calculate_rock_index_()
                else:
                    self.key_data = pd.concat([self.key_data, data], ignore_index=True, axis=0)  # 开始保存数据（拼接）
        else:
            if not self.temp_data.empty:  # 为了避免刚开始pd.DataFrame为空时代码报错问题
                Length = self.temp_data['推进位移'].max() - self.temp_data['推进位移'].min()  # 获取该循环段的掘进长度
                V_max = self.temp_data['推进速度'].max()  # 获取该循环段的推荐速度最小值
                if Length > 10 and V_max > 1 and len(self.temp_data) >= 200:  # 判断推荐速度、掘进长度、数据量是否满足要求
                    self.history_data.append(copy.deepcopy(self.temp_data))  # 将该循环段数据进行保存
                    if len(self.history_data) > 10:  # 检查历史信息是否大于10个
                        del self.history_data[0]  # 若大于10个，则删除最先添加进来的数据
                    passed_data_mean = self._remove_outliers_(self.temp_data, option='kernel').mean()
                    self._shared_var.set(value={'passed-data': self.history_data}, dtype='list')  # 历史循环段数据上载至共享变量
                    self._shared_var.set(value={'刀盘转速-之前': round(passed_data_mean['刀盘转速'], 2)}, dtype='float')  # 刀盘转速上载
                    self._shared_var.set(value={'推进速度-之前': round(passed_data_mean['推进速度'], 2)}, dtype='float')  # 推进速度上载
                    self._shared_var.set(value={'刀盘扭矩-之前': round(passed_data_mean['刀盘扭矩'], 2)}, dtype='float')  # 刀盘扭矩上载
                    self._shared_var.set(value={'刀盘推力-之前': round(passed_data_mean['刀盘推力'], 2)}, dtype='float')  # 刀盘推力上载
                    self._shared_var.set(value={'刀盘贯入度-之前': round(passed_data_mean['刀盘贯入度'], 2)}, dtype='float')
                self._previous_state_(option='set')  # 保存历史状态信息
            if not self.temp_data.empty:
                self.temp_data.drop(self.temp_data.index, inplace=True)
                gc.collect()
            if not self.key_data.empty:
                self.key_data.drop(self.key_data.index, inplace=True)  # 清空数据，并重新开始填写数据
                gc.collect()

    def _calculate_rock_index_(self):
        """破岩指标计算TPI, FPI, WR, F=a*P+b"""
        if not self.key_data.empty:  # 若data不为空，则继续执行以下代码
            if self.FPI_b is None:
                self.FPI_b = self.key_data['刀盘推力'][0]
            TPI = (self.key_data['刀盘扭矩'] / self.key_data['刀盘贯入度'])  # 计算TPI
            FPI_a = ((self.key_data['刀盘推力'] - self.FPI_b) / self.key_data['刀盘贯入度'])  # 计算FPI
            F_V_a = ((self.key_data['刀盘推力'] - self.FPI_b) / self.key_data['推进速度'])  # 计算FPI
            T_V = (self.key_data['刀盘扭矩'] / self.key_data['推进速度'])  # 计算TPI
            WR = (2000 * np.pi * self.key_data['刀盘扭矩'] * self.key_data['刀盘转速']) / (self.key_data['推进速度'] * self.key_data['刀盘推力'])  # 计算WR
            results = {'TPI-mean': TPI.mean(), "TPI-std": TPI.std(),
                       "FPIa-mean": FPI_a.mean(), "FPIa-std": FPI_a.std(),
                       "FPIb-mean": self.FPI_b, "FPIb-std": 0,
                       "WR-mean": WR.mean(), "WR-std": WR.std(),
                       "F-V-mean": F_V_a.mean(), "F-V-std": F_V_a.std(),
                       "T-V-mean": T_V.mean(), "T-V-std": T_V.std()}  # 将结果放入dict中
            self._shared_var.set(value={'rock-index': pd.DataFrame([results])}, dtype='dataframe')  # 破岩参数上载至共享变量
            self._shared_var.set(value={'TPI-平均': round(results['TPI-mean'], 2)}, dtype='float')  # TPI上载至共享变量
            self._shared_var.set(value={'FPIa-平均': round(results['FPIa-mean'], 2)}, dtype='float')  # FPIa上载至共享变量
            self._shared_var.set(value={'FPIb-平均': round(results['FPIb-mean'], 2)}, dtype='float')  # FPIb上载至共享变量
        else:  # 若data为空，则所有破岩关键数据均为0
            self.FPI_b = None

    def _remove_outliers_(self, data: DataFrame, option='3sigma') -> DataFrame:
        """
        :param data: DataFrame格式数据
        :param option: 此函数包括，3σ方法、4分位法，默认采用3σ
        :return: 去除异常值后的数组
        """
        data = data[(data['刀盘扭矩'] > 100) & (data['刀盘推力'] >= 1000) &
                    (data['推进速度'] <= 120) & (data['刀盘贯入度'] > 1)]  # 只选取刀刀盘推力 > 3000的数据
        if option == '3sigma':
            for col in ['刀盘扭矩', '刀盘贯入度', '刀盘转速', '推进速度', '刀盘推力']:  # 分别对这五个参数去除异常值
                mean, std = data[col].mean(), data[col].std()  # 计算均值、方差
                lower_limit, upper_limit = mean - 3 * std, mean + 3 * std  # 剔除3sigma范围外的异常值
                data = data[(data[col] >= lower_limit) & (data[col] <= upper_limit)]  # 去除异常值后的数据
        elif option == 'kernel':
            V = data['推进速度'].to_numpy()[:, np.newaxis]  # '推进速度'转换为NumPy数组，并增加一个新的维度
            kde_V = KernelDensity(kernel="gaussian", bandwidth=10.0).fit(V)
            V_MaxDensity_index = np.argmax(np.exp(kde_V.score_samples(V)))  # 找到概率密度最大值时 推进速度的索引
            V_MaxDensity = V[V_MaxDensity_index, 0]
            data = data[0.75 * V_MaxDensity < data['推进速度']]
        else:
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] Option < {option} > does not exist, please check !!!\033[0m')  # 输出相关提示信息
        return data.reset_index(drop=True)  # 返回处理后的数据
