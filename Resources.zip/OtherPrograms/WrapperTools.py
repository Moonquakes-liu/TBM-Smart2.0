#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  WrapperTools  for  Python                                 *
# * Version:  2.0.0                                                      *
# * Date:  2023-10-02 20:00:00                                           *
# * Last  update: 2023-09-16 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1qSr2pfXLR3Yf9IrGtpOokQ  *
# * Maintain  code:  STBM                                                *
# ************************************************************************

from datetime import datetime
import time


def suppress_errors(func):
    """装饰器：错误处理, 仅支持class内部使用"""
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except BaseException as e:
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            function_name = func.__name__
            print(f'\033[0;31m[{local_time}] {class_name} -> '
                  f'[Error] function < {function_name} > has error in: {e} !!!\033[0m')  # 提示信息
            return None
    return wrapper


def timer(func):
    """装饰器：测量执行时间"""
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        time_use = time.time() - start_time
        print(f"\033[0;33mfunction < {func.__name__} > took {time_use:.2f} seconds to execute.\033[0m")
        return result
    return wrapper


def log_results(func):
    """装饰器：记录函数的结果，并写入日志"""
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        with open("results.log", "a") as log_file:
            log_file.write(f"{func.__name__} - Result: {result}\n")
        return result
    return wrapper


def retry(max_attempts, delay):
    """装饰器：遇到异常时重试函数执行，确保更大的弹性"""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            attempts = 1
            local_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            class_name = type(self).__name__
            while attempts <= max_attempts:
                try:
                    return func(self, *args, **kwargs)
                except Exception as e:
                    print(f"\033[0;33m[{local_time}] {class_name} -> [Warning] Attempt {attempts} failed, "
                          f"Error in: < {e} >, Retrying in {delay} seconds.\033[0m")
                    attempts += 1
                    time.sleep(delay)
            print(f"\033[0;31m[{local_time}] {class_name} -> [Error] Max retry attempts exceeded, "
                  f"please troublehoot the error manually.")
        return wrapper
    return decorator
