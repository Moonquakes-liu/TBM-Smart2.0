# -*- coding: utf-8 -*-
import tarfile
import pickle
from datetime import datetime
import os
import hashlib
import glob


def create_tar_file(tar_Filename, Files):
    with tarfile.open(tar_Filename, 'w') as tar:
        for file in Files:
            tar.add(file, arcname=os.path.basename(file))  # 添加文件到tar文件中


def calculate_file_checksum(file_path, algorithm):
    # 使用指定的哈希算法初始化哈希对象
    hasher = hashlib.new(algorithm)
    # 打开文件并逐块更新哈希对象
    with open(file_path, 'rb') as file:
        for chunk in iter(lambda: file.read(4096), b''):  # 每次读取4KB数据
            hasher.update(chunk)
    # 获取最终的校验码
    checksum = hasher.hexdigest()
    return checksum


# 添加模型最优阈值相关信息
key_name = ['暖水箱液位', '进水温度', '减速机进水压力', '刀盘喷水压力', '减速机冷却水出口流量', '冷水泵压力', '刀盘喷水泵压力',
            'EP2出口压力', 'EP2次数', '内密封前腔压力', '外密封迷宫腔压力', '内密封迷宫腔压力', '齿轮油泵1压力', '齿轮油泵2压力',
            '推进油缸前部铰接', '推进油缸后部铰接', '小轴承润滑', '提升油缸十字铰接次数', '护盾铰接次数', '喷浆泵压力', '刀盘转速',
            '刹车释放压力', '变频柜进口水压力', '刀盘贯入度', '推进压力', '推进位移', '推进泵电机电流', '撑靴泵电机电流', '左撑靴位移',
            '右撑靴位移', '循环冷却泵压力', '撑靴泵压力', '钢拱架泵压力', '主皮带机泵压力', '主机皮带机速度', '后配套皮带机速度',
            'C1皮带机泵电机电流', '主皮带机正转压力', '主皮带机反转压力', 'C2皮带机电机电流', '左侧护盾压力', '右侧护盾压力', '顶护盾压力',
            '左侧楔形油缸压力', '右侧楔形油缸压力', '左扭矩油缸回收压力', '右扭矩油缸伸出压力', '右扭矩油缸回收压力', '左后支撑压力',
            '右后支撑压力', '左小腔撑靴压力', '右小腔撑靴压力', '撑紧压力', '左后支撑位移', '左侧护盾位移', '右侧护盾位移', '左扭矩油缸位移',
            '右扭矩油缸位移', '顶护盾位移', '前部拖拉油缸压力', '后部拖拉油缸压力', '后左拖拉油缸位移', 'T1_L3相电压', 'T3_L2相电流']
# with open('./Resources/rock-class4-cols.pkl', 'wb') as f:  # 将字节流写入硬盘文件
#     f.write(pickle.dumps(key_name))
# with open('./Resources/weak-probability-cols.pkl', 'wb') as f:  # 将字节流写入硬盘文件
#     f.write(pickle.dumps(key_name))


# 打开文本文件以写入文件信息
folder_path = "./Resources"
with open("./Resources/readme", "w", encoding='gb2312') as file:
    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 将时间格式化为字符串
    file.write(f"time: {time_str}\n")
    file.write(f"apply: TBM Smart v2.0\n")
    file.write(f"\n")
    for root, dirs, files in os.walk(folder_path):  # 遍历文件夹中的所有文件
        for filename in files:
            file_path = os.path.join(root, filename)  # 获取文件的完整路径
            file_size = os.path.getsize(file_path)  # 获取文件的大小（以字节为单位）
            file_creation_time = os.path.getctime(file_path)  # 获取文件的创建时间
            file_creation_time = datetime.fromtimestamp(file_creation_time).strftime('%Y-%m-%d %H:%M:%S')
            file_modified_time = os.path.getmtime(file_path)  # 获取文件的修改时间
            file_modified_time = datetime.fromtimestamp(file_modified_time).strftime('%Y-%m-%d %H:%M:%S')
            checksum = calculate_file_checksum(file_path, "md5")
            # 写入文件信息到文本文件
            file.write(f"文件名: {filename}\n")
            file.write(f"文件位置: {file_path.replace(folder_path, '')}\n")
            file.write(f"文件大小: {file_size} 字节\n")
            file.write(f"创建时间: {file_creation_time}\n")
            file.write(f"修改时间: {file_modified_time}\n")
            file.write(f"MD5: {checksum}\n")
            file.write("\n")  # 每个文件之间换行

# 使用示例
tar_filename = 'SoilConditionAnalysis.tar'  # 设置要创建的tar文件名
files = glob.glob(os.path.join(folder_path, '*'))  # 要添加到tar文件中的文件列表

create_tar_file(tar_filename, files)
