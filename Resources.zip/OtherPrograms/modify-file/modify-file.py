# -*- coding: utf-8 -*-
import os
import joblib

base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 获取根目录路径
print(os.path.join(base_path, 'temp'))
if os.path.exists(os.path.join(base_path, 'temp')):
    print('============================================')
    history = os.path.join(base_path, 'temp', 'history-data')
    if os.path.exists(history):
        _temp_history = joblib.load(history)
        print(f'cycle-num: {_temp_history["number"]}')
        _temp_history['number'] = int(input('modify-num：'))
        print(f'after-cycle-num: {_temp_history["number"]}')
        joblib.dump(_temp_history, history)
    else:
        print('-> File < history > does not exist!')
    print('============================================')
else:
    print('-> Folder < temp > does not exist!')
