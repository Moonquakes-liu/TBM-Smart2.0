# -*- coding: utf-8 -*-
import tarfile
import pickle
from datetime import datetime
import os
import hashlib
import glob
from tkinter import messagebox
from tkinter import Tk
from tkinter.filedialog import askdirectory


class Verification(object):
    def __init__(self):
        pass

    def main(self):
        folder = self.select_dir()
        if os.path.exists(os.path.join(folder, "md5")):  # 检查文件是否存在
            os.remove(os.path.join(folder, "md5"))  # 删除文件
        with open(os.path.join(folder, "md5"), "w", encoding='gb2312') as f:
            time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 将时间格式化为字符串
            f.write(f"time: {time_str}\n")
            f.write(f"apply: TBM Smart v2.0\n")
            f.write(f"\n")
            for root, dirs, files in os.walk(folder):  # 遍历文件夹中的所有文件
                for filename in files:
                    file_path = os.path.join(root, filename)  # 获取文件的完整路径
                    file_size = os.path.getsize(file_path)  # 获取文件的大小（以字节为单位）
                    file_creation_time = os.path.getctime(file_path)  # 获取文件的创建时间
                    file_creation_time = datetime.fromtimestamp(file_creation_time).strftime('%Y-%m-%d %H:%M:%S')
                    file_modified_time = os.path.getmtime(file_path)  # 获取文件的修改时间
                    file_modified_time = datetime.fromtimestamp(file_modified_time).strftime('%Y-%m-%d %H:%M:%S')
                    # 写入文件信息到文本文件
                    f.write(f"文件名: {filename}\n")
                    f.write(f"文件位置: {file_path.replace(folder, '')}\n")
                    f.write(f"文件大小: {file_size} 字节\n")
                    f.write(f"创建时间: {file_creation_time}\n")
                    f.write(f"修改时间: {file_modified_time}\n")
                    f.write(f"MD5: {self.calculate_file_checksum(file=file_path)}\n")
                    f.write("\n")  # 每个文件之间换行
        # 弹出一个信息提示框
        messagebox.showinfo("提示", "文件校验完成！")

    @staticmethod
    def calculate_file_checksum(file, algorithm="md5"):
        ha_sher = hashlib.new(algorithm)  # 使用指定的哈希算法初始化哈希对象
        with open(file, 'rb') as f:  # 打开文件并逐块更新哈希对象
            for chunk in iter(lambda: f.read(4096), b''):  # 每次读取4KB数据
                ha_sher.update(chunk)
        check_sum = ha_sher.hexdigest()  # 获取最终的校验码
        return check_sum

    @staticmethod
    def select_dir():
        root = Tk()  # 创建一个 Tkinter 根窗口
        root.withdraw()  # 隐藏根窗口，只显示文件夹选择对话框
        folder_path = askdirectory()  # 打开文件夹选择对话框
        return folder_path

Verification().main()