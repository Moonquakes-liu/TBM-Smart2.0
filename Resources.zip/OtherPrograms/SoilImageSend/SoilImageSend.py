#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  SoilImageSend  for  Python                                *
# * Version:  2.0.0                                                      *
# * Date:  2023-10-02 20:00:00                                           *
# * Last  update: 2023-09-16 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1qSr2pfXLR3Yf9IrGtpOokQ  *
# * Maintain  code:  STBM                                                *
# ************************************************************************

import os
import socket
import time
import math
import sys
import pickle
import configparser
from io import BytesIO
import pandas as pd
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from datetime import datetime, timedelta

#  程序说明部分
with open(os.path.abspath(sys.argv[0]), 'r', encoding="utf-8") as F:
    Info = ''.join(F.readlines()[2:11]).replace('#', '    ')
program_help = '\n' + Info + \
    """
===================================== 程序说明 =====================================

功能：该模块用于碴土图片发送
说明：无

===================================================================================
     """


class SoilImageSend(object):
    server_socket, client_socket, if_connect = None, None, False

    def __init__(self):
        self._base_path = os.path.dirname(os.path.abspath(__file__))  # 获取根目录路径
        self.Image_data = BytesIO()
        # >>>>>>>>>>>>>>>>>>>> 以下为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self.resource_path = ''  # 资源路径
        self.server_ip = '192.168.1.110'  # 替换为服务器IP地址
        self.server_port = 8888  # 替换为服务器端口号
        # >>>>>>>>>>>>>>>>>>>> 以上为自定义修改区域（默认值，实际值以config.ini文件中内容为主） <<<<<<<<<<<<<<<<<<<<<<<<<<
        self._get_config_()  # 获取配置文件并加载信息

    def __str__(self):
        """程序说明信息"""
        global program_help
        try:
            return program_help
        except NameError:
            return '\n未找到说明信息\n'

    def run(self) -> None:
        """运行线程内的代码，请勿修改"""
        print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
              f'-> [Info] TBM Smart v2.0 software for send soil image!!!\033[0m')  # 输出相关提示信息
        while True:  # 若未接收到停止指令，则一直循环运行
            self.backend_port()  # 运行主程序

    def _get_config_(self) -> None:
        """获取配置文件"""
        config_path = os.path.join(self._base_path, 'config.ini')  # INI文件位置
        if not os.path.exists(config_path):  # 判断配置文件是否存在
            print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] {self.__class__.__name__} '
                  f'-> [Warning] The < config.ini > does not exist, The default configuration is used !!!\033[0m')
        else:
            config = configparser.ConfigParser()  # 创建 ConfigParser 对象
            config.read(config_path, encoding='gb2312')  # 读取INI文件
            self.server_ip = config.get('SoilImageSend', 'server-ip').split(',')  # 替换为服务器IP地址
            self.resource_path = config.get('SoilImageSend', 'resource_path')
            self.server_port = config.getint('SoilImageSend', 'server-port')  # 替换为服务器端口号

    def backend_port(self):
        # noinspection PyBroadException
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建服务器套接字
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 设置重用地址选项，允许端口复用
            for ip in self.server_ip:
                # noinspection PyBroadException
                try:
                    self.server_socket.bind((ip, self.server_port))  # 绑定IP地址和端口
                    self.server_socket.listen(1)  # 监听连接
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                          f'[Info] {ip} Waiting for connection...\033[0m')
                    self.server_socket.settimeout(3600)  # 设置超时时间为60分钟（3600秒）
                    self.client_socket, address = self.server_socket.accept()  # 接受客户端连接
                    print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                          f'[Info] Connection successful, port: {address}!!!\033[0m')
                    while True:
                        request = self.client_socket.recv(1024).decode()  # 接收客户端请求
                        if request == 'get_variable':
                            while True:
                                # noinspection PyBroadException
                                try:
                                    self.function()
                                    self.client_socket.sendall(self.Image_data.getvalue())
                                    # 清空字节流内容
                                    self.Image_data.seek(0)
                                    self.Image_data.truncate(0)
                                    break
                                except Exception:
                                    time.sleep(1)
                        else:
                            print(f'\033[0;32m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                                  f'[Info] Connection closed !!!\033[0m')
                            break
                except socket.timeout:
                    print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                          f'[Warning] No device connection for more than 1 hour, restart the program!!!\033[0m')
                except OSError:
                    print(f'\033[0;33m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                          f'[Warning] {ip} unavailable!!!\033[0m')
                finally:
                    time.sleep(1)
        except Exception as e:
            print(f'\033[0;31m[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] '
                  f'[Error] The client has a problem: {e}, Please try again in 120s. !!!\033[0m')
            time.sleep(120)
        finally:
            # noinspection PyBroadException
            try:
                self.client_socket.close()  # 关闭客户端连接
                self.server_socket.close()
            except Exception:
                pass

    def function(self):
        if os.path.exists(self.resource_path):  # 判断文件夹是否存在
            for file in os.listdir(self.resource_path)[::-1]:
                modified_time = datetime.fromtimestamp(os.path.getmtime(os.path.join(self.resource_path, file)))  # 修改时间
                time_difference = datetime.now() - modified_time  # 计算时间差
                if time_difference < timedelta(minutes=1) and os.path.splitext(file)[-1] == '.png':  # 判断时间差是否小于一分钟
                    print(f'New file: {file} - {modified_time.strftime("%Y-%m-%d %H:%M:%S")}')
                    image_raw = Image.open(os.path.join(self.resource_path, file))
                    image_raw = image_raw.crop((200, 150, 3600, 2650))
                    image_raw.thumbnail((2000, 1500))
                    image_raw = image_raw.filter(ImageFilter.SHARPEN)  # 锐化滤波器
                    image_raw = Image.fromarray(
                        (np.power(np.array(image_raw) / 255.0, 1.8) * 255).astype(np.uint8))  # 伽马矫正
                    image_raw = ImageEnhance.Contrast(image_raw).enhance(1.5)  # 减少对比度
                    image_raw = ImageEnhance.Sharpness(image_raw).enhance(1.5)  # 增强锐化效果
                    raw_light, process_light, differ, light, image, count = 0, 0, 50, 0, None, 1
                    while count <= 20 and process_light - raw_light < differ and process_light <= 100:
                        image = ImageEnhance.Brightness(image_raw).enhance(light)  # 增加亮度
                        pixel_data = list(image.convert("L").getdata())  # 获取图像数据
                        process_light = sum(pixel_data) / len(pixel_data)  # 计算平均亮度
                        if raw_light == 0:
                            raw_light = process_light
                            light += 1
                        else:
                            light = (raw_light + differ + 10) / (process_light - raw_light)
                        count += 1
                    if image is not None:
                        X = image.size[0] // 2
                        image_array = np.array(image)
                        enhancement_left = ((1.8 - 1) / int(X / 2) * (np.arange(0, int(X / 2), 10)) + 1)[::-1]
                        enhancement_right = ((3 - 1) / int(X / 2) * (np.arange(0, int(X / 2), 10)) + 1)
                        for i in range(len(enhancement_left)):
                            a_left, b_left = i * 10, i * 10 + 10
                            enhancer_left = ImageEnhance.Brightness(Image.fromarray(image_array[:, a_left:b_left]))
                            image_array[:, a_left:b_left] = enhancer_left.enhance(enhancement_left[i])
                            a_right, b_right = int(X * 3 / 2) + i * 10, int(X * 3 / 2) + i * 10 + 10
                            enhancer_right = ImageEnhance.Brightness(Image.fromarray(image_array[:, a_right:b_right]))
                            image_array[:, a_right:b_right] = enhancer_right.enhance(enhancement_right[i])
                        Image.fromarray(image_array).save(self.Image_data, format='JPEG')


if __name__ == '__main__':
    SoilImageSend().run()
