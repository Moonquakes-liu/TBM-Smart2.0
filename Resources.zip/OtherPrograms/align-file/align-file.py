# -*- coding: utf-8 -*-
import os
import shutil
import csv
import pandas as pd


base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 获取根目录路径
index = os.path.join(base_path, 'SaveData', 'index.csv')
raw_display = os.path.join(base_path, 'SaveData', 'Display')
raw_cycle = os.path.join(base_path, 'SaveData', 'Cycle')
raw_picture = os.path.join(base_path, 'SaveData', 'Picture')


def _write_index_(info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
    """
    向索引文件写入数据
    :param info: 待写入的信息
    """
    with open(index, 'a', newline='') as csv_file:
        writer = csv.writer(csv_file)  # 实例化写入数据功能
        if os.stat(index).st_size == 0:  # 如果csv文件是空的，写入列名
            writer_header = csv.DictWriter(csv_file, fieldnames=list(info.keys()))
            writer_header.writeheader()
        writer.writerow(info.values())


raw_display_list = os.listdir(raw_display)
raw_cycle_list = os.listdir(raw_cycle)
raw_picture_list = os.listdir(raw_picture)
index_num = 1
if os.path.exists(index):  # 检查文件是否存在
    os.remove(index)  # 删除文件
for file in raw_display_list:
    for cycle in raw_cycle_list:
        if file[6:-4] in cycle:
            os.rename(os.path.join(raw_cycle, cycle),
                      os.path.join(raw_cycle, '%00005d ' % index_num + file[6:-4] + '.csv'))
    for picture in raw_picture_list:
        if file[6:-4] in picture:
            os.rename(os.path.join(raw_picture, picture),
                      os.path.join(raw_picture, '%00005d ' % index_num + file[6:-4]))
    os.rename(os.path.join(raw_display, file),
              os.path.join(raw_display, '%00005d ' % index_num + file[6:-4] + '.csv'))
    data = pd.read_csv(os.path.join(raw_display,
                                    os.path.join(raw_display, '%00005d ' % index_num + file[6:-4] + '.csv')),
                       encoding='gb2312')
    start_mileage = round(data['里程'][0], 2)  # 获取每个掘进段的起始桩号
    start_time = pd.to_datetime(data['运行时间'][0])  # 获取每个掘进段的时间记录
    end_time = pd.to_datetime(data['运行时间'].iloc[-1])  # 获取每个掘进段的时间记录
    length = data['推进位移-当前'].max() - data['推进位移-当前'].min()  # 掘进长度
    _write_index_({'文件名': '%00005d ' % index_num + file[6:-4] + '.csv', '当前里程': start_mileage, '开始时间': start_time,
                   '结束时间': end_time, '掘进时间': int((end_time - start_time).total_seconds()),
                   '掘进长度': length})  # 写入索引文件
    index_num += 1
    print(file)
print('finish!')
