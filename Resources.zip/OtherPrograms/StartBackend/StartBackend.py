# -*- coding: utf-8 -*-
import os
import sys
import pickle
import _pickle
import socket
import threading
import time
import traceback
import configparser
import tarfile
import joblib
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.neighbors import KernelDensity
import random
import numpy as np
import torch
import copy
import re
import smtplib
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
from io import BytesIO
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Table
from reportlab.lib.utils import ImageReader
import matplotlib
import gc
import shutil
import csv
import json
import urllib.request
import warnings
import psutil
from colorama import init

if getattr(sys, 'frozen', False):
    # 如果是打包成可执行文件
    current_path = os.path.dirname(sys.executable)  # 获取可执行文件路径
else:
    current_path = os.path.dirname(os.path.abspath(sys.argv[0]))
Program_DataProcess = {}
with open(os.path.join(current_path, 'Programs', 'DataProcess.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_DataProcess)
Program_DataSend = {}
with open(os.path.join(current_path, 'Programs', 'DataSend.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_DataSend)
Program_DataSave = {}
with open(os.path.join(current_path, 'Programs', 'DataSave.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_DataSave)
Program_ParameterOptimization = {}
with open(os.path.join(current_path, 'Programs', 'ParameterOptimization.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_ParameterOptimization)
Program_RockMassAnalysis = {}
with open(os.path.join(current_path, 'Programs', 'RockMassAnalysis.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_RockMassAnalysis)
Program_SoilConditionAnalysis = {}
with open(os.path.join(current_path, 'Programs', 'SoilConditionAnalysis.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_SoilConditionAnalysis)
Program_VibrationSignalAnalysis = {}
with open(os.path.join(current_path, 'Programs', 'VibrationSignalAnalysis.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_VibrationSignalAnalysis)
Program_DataCollect = {}
with open(os.path.join(current_path, 'Programs', 'DataCollect.py'), 'r', encoding="utf-8") as file:
    exec(file.read(), Program_DataCollect)
Program = Program_DataCollect['DataCollect']()
Program.__set_program__(programs=[Program_DataProcess['DataProcess'],
                                  Program_DataSave['DataSave'],
                                  Program_DataSend['DataSend'],
                                  Program_ParameterOptimization['ParameterOptimization'],
                                  Program_SoilConditionAnalysis['SlagConditionAnalysis'],
                                  Program_RockMassAnalysis['RockMassAnalysis'],
                                  Program_VibrationSignalAnalysis['VibrationSignalAnalysis']])
Program.run()