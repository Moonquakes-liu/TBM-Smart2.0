import random
import socket
import pickle
import os
import time
from datetime import datetime


def get_random_image(folder_path):
    # 获取文件夹中所有图片文件名称
    images = [file for file in os.listdir(folder_path) if
              file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp'))]

    # 检查是否有图片文件
    if not images:
        print("文件夹中没有找到图片文件")
        return None

    # 随机选择一张图片
    random_image = random.choice(images)
    return random_image


while True:
    try:
        # 创建 socket 对象
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 绑定 IP 地址和端口
        server_socket.bind(('192.168.1.105', 950))  # 在所有网络接口上监听
        server_socket.listen(1)  # 最多允许一个客户端连接
        print("服务器正在等待客户端连接...")
        # 等待客户端连接
        conn, addr = server_socket.accept()
        print(f"客户端已连接，地址：{addr}")
        while True:
            folder_path = 'pictures'  # 替换为目标文件夹路径
            image_name = get_random_image(folder_path)
            # 打开图片并读取为字节流
            with open(os.path.join(folder_path, image_name), 'rb') as image_file:
                image_data = image_file.read()
            # 序列化字典
            dict_data = pickle.dumps(
                {'渣土大块异常': '否', '出渣体积异常': '否', '最大粒径': random.uniform(0, 10), '全尺寸系数': random.uniform(0, 10),
                 '均匀系数': random.uniform(0, 10), '曲线系数': random.uniform(0, 10), '推荐加水量': random.uniform(0, 1000),
                 '泡沫混合液流量': random.uniform(0, 10),
                 '渣土级配曲线': {0: 0, 25: random.uniform(0, 1000), 50: 1}})
            conn.sendall((len(image_data) + len(dict_data)).to_bytes(4, 'big'))  # 发送4字节的图片大小信息
            # 发送图片大小
            conn.sendall(len(image_data).to_bytes(4, 'big'))  # 发送4字节的图片大小信息
            # 发送图片字节流
            conn.sendall(image_data)
            # 发送字典数据的大小
            conn.sendall(len(dict_data).to_bytes(4, 'big'))
            # 发送字典字节流
            conn.sendall(dict_data)
            print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] dict数据大小：{len(dict_data)}bytes   图片数据大小：{len(image_data)}bytes')
            time.sleep(60)
    except Exception as e:
        print(e)
    finally:
        try:
            # 使用 shutdown() 方法通知对方关闭连接
            conn.shutdown(socket.SHUT_RDWR)  # 关闭读写
            conn.close()  # 关闭套接字连接
            # 关闭服务器套接字
            server_socket.close()
            print("Server socket closed.")
        except Exception as e:
            pass
        time.sleep(1)